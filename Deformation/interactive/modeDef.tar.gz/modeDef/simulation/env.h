//this file holds declarations for some option variables

extern const char* scene_file;
extern int verbose;
extern bool draw_penetration;
extern bool draw_animation;
extern bool draw_constraints;
