#include <iostream>
#include "ParseArgs.h"
#include "File.h"
#include "IsfFluidEulerDriver.h"
#include "IsfFluidEulerFreeSurfaceDriver.h"

#ifndef __Main_cpp__
#define __Main_cpp__

template<int d> 
void Run_Program(const ParseArgs& parse_args, const std::string & input_command)
{
    std::string output_dir=parse_args.Get_String_Value("-o");
    const int scale=parse_args.Get_Integer_Value("-s");
	const int driver=parse_args.Get_Integer_Value("-driver");
	const int test=parse_args.Get_Integer_Value("-test");
	const int last_frame=parse_args.Get_Integer_Value("-lf");
	const int frame_rate=parse_args.Get_Integer_Value("-fr");
	const real cfl=parse_args.Get_Double_Value("-cfl");
	//const int cof=parse_args.Get_Integer_Value("-cof");
	//const real delta=parse_args.Get_Double_Value("-delta");

	//////////////////////////////////////////////////////////////////////////
	////simulation args
	bool set_frame_rate=(frame_rate>0);

	//const real dif=parse_args.Get_Double_Value("-dif");
	//bool set_imp_dif=(dif>=0.); 

	//const real reinit_a=parse_args.Get_Double_Value("-reinit_a");
	//bool set_reinit_a=(reinit_a>=0.); 

	//bool vb_output=parse_args.Get_Option_Value("-vbo");
	//bool vb_print=parse_args.Get_Option_Value("-vbp");
	//bool resume=parse_args.Get_Option_Value("-rsm");

	const real surface_tension=parse_args.Get_Double_Value("-st");
	bool set_surface_tension=(surface_tension>=0.);

	bool use_euler=parse_args.Get_Option_Value("-euler");

	real input_alpha=parse_args.Get_Double_Value("-alpha"); 
	real input_beta=parse_args.Get_Double_Value("-beta");

	//////////////////////////////////////////////////////////////////////////

	switch(driver){
	case 1:{ ////smoke
		IsfFluidEulerDriver<d> driver;
		driver.scale=scale;
		driver.output_dir=output_dir;
		driver.test=test;
		driver.last_frame=last_frame;
		driver.cfl=cfl;
		driver.fluid.use_euler = use_euler;
		driver.input_command=input_command;
		driver.input_alpha = input_alpha;
		driver.input_beta = input_beta;
		driver.Initialize();
		driver.Run();
	}break;	
	case 2:{ ////water
		IsfFluidEulerFreeSurfaceDriver<d> driver;
		driver.scale=scale;
		driver.output_dir=output_dir;
		driver.test=test;
		driver.last_frame=last_frame;
		driver.cfl=cfl;
		driver.input_command=input_command;
		driver.fluid.use_euler = use_euler;
		if(set_surface_tension)driver.fluid.surface_tension=surface_tension;
		driver.input_alpha = input_alpha;
		driver.input_beta = input_beta;
		driver.Initialize();
		driver.Run();		
	}break;
	} 
}

// void Set_Threads(const ParseArgs& parse_args) {
// 	int number_threads = parse_args.Get_Integer_Value("-tnum");
// 	omp_set_num_threads(number_threads);
// 	int max_threads = omp_get_max_threads();
// 	std::cout << "Set " << number_threads << " threads, run with " << max_threads << " cores\n";
// }

//.\quantized_gauge.exe -driver 1 -d 2 -test 20 -s 128 -o test_leapfrpg -lf 1000

int main(int argc,char* argv[])
{
    ParseArgs parse_args;
	parse_args.Add_Integer_Argument("-d",2,"dimension");
	parse_args.Add_String_Argument("-o","output","output path");
    parse_args.Add_Integer_Argument("-s",64,"resolution");
    parse_args.Add_Integer_Argument("-test",1,"test");
	parse_args.Add_Integer_Argument("-driver",2,"driver");
	parse_args.Add_Integer_Argument("-lf",100,"last frame");
	parse_args.Add_Integer_Argument("-fr",-1,"frame rate");
	parse_args.Add_Double_Argument("-cfl",1,"cfl");
	//parse_args.Add_Integer_Argument("-cof",1,"cutoff function");
	//parse_args.Add_Double_Argument("-delta",0.3, "delta");
	
	//parse_args.Add_Double_Argument("-s_damp",-1.,"stretching damp");
	//parse_args.Add_Double_Argument("-dif",-1.,"diffusion");
	//parse_args.Add_Double_Argument("-reinit_a",-1.,"reinit a");
	parse_args.Add_Double_Argument("-st",-1.,"surface tension");
	//parse_args.Add_Option_Argument("-vbo", "use verbose output");
	//parse_args.Add_Option_Argument("-vbp", "use verbose print");
	//parse_args.Add_Option_Argument("-rsm", "resume from previous run");
	parse_args.Add_Option_Argument("-euler", "use euler solver");
	//parse_args.Add_Option_Argument("-flip", "use flip solver");
	//parse_args.Add_Double_Argument("-flip_coef",-1.,"flip coef");
	parse_args.Add_Integer_Argument("-tnum", 4, "Number of Threads");

	parse_args.Add_Double_Argument("-alpha", -1., "Choose of different alpha values");
	parse_args.Add_Double_Argument("-beta", -1., "Choose of different beta values");

    parse_args.Parse(argc,argv);

	//std::string output_dir=parse_args.Get_String_Value("-o");
	//if(!File::Directory_Exists(output_dir.c_str()))File::Create_Directory(output_dir);
	//std::string command_file=output_dir+"\\command.txt";
	//File::Write_Text_To_File(command_file,*argv);

	std::string input_str = "";
	while( --argc ){input_str+=(*(++argv));input_str+=" ";}

	int d=parse_args.Get_Integer_Value("-d");
	if(d==2)Run_Program<2>(parse_args, input_str);
	else Run_Program<3>(parse_args, input_str);
}

#endif