//////////////////////////////////////////////////////////////////////////
// Euler fluid simulator
// Author: Anonymous authors
// This file is part of XXX, whose distribution is governed by the LICENSE file.
//////////////////////////////////////////////////////////////////////////

#pragma once

#include <complex>
#include <cmath>
#include "Common.h"
#include "FluidEuler.h"
#include "Vorticity.h"
#include "AuxFunc.h"
#include "MacGrid.h"
#include "Projection.h"
#include "BoundaryCondition.h"
#include "Advection.h"
#include "Particles.h"
#include "Interpolation.h"
#include "RandomNumber.h"
#include "SpatialHashing.h"
#include "Timer.h"
#include "IsfFluidHelpers.h"
#include "FluidFunc.h"
#include "PrintHelpers.h"
#include <cfloat>
#include "LevelSet.h"


using namespace AuxFunc;
using namespace std::complex_literals;

template<int d> class IsfFluidEuler : public FluidEuler<d>, public PrintParamHelpers
{Typedef_VectorDii(d);using Base=FluidEuler<d>;
public:
	using Base::mac_grid;
	using Base::velocity;
	using Base::alpha;
	using Base::type;							////type is initialized in Update_Cell_Types and used in projection
	using Base::bc;								////velocity and impulse share bc
	using Base::use_body_force;					////default false
	using Base::g;
	using Base::projection;
	using Base::Update_Cell_Types;
	using Base::Max_Abs;
	__Declare_PrintParamHelpers 

	Field<real,d> q;
	Field<real,d> p;
	FaceField<real,d> grad_q;
	FaceField<real,d> grad_p;

	////IO FLAGS
	bool verbose_output=true;						////turn this off to save file IO time. You can set "-no_vb" in the main arg list.
	bool verbose_print=false;						////print on screen

	////data
	FaceField<real,d> impulse;
	Field<Vector4, d> psi;		////NOT normalized by default
	Field<Vector4, d> psi2;		////save the normalized psi
	std::function<Vector4(const VectorD&)> initial_psi;
	Hashtable<int,std::pair<Vector4,real> > psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))

	////callbacks
	std::function<real(const VectorD&)> Solid_Boundary_Phi=nullptr;

	////solid boundary
	real solid_boundary_nb_width;
	LevelSet<d> solid_boundary_levelset; 
	
	////
	VectorD source_velocity = VectorD::Zero();
	real current_time=(real)0;
		
	real h_bar=(real).05;
	int cal_impulse_option = 0;
	
	bool use_static_solid=true;						////not update the projection matrix and solid phi if true		
	bool use_q_projection=true;						////apply q or not. NOW in smoke simulations we typically turn this option off.
	bool use_nonzero_neumann_q_proj=true;			////use div solver for q if false
	bool use_delta_q_proj=true;						////whether to use SOLId PHI delta when doing q proj

	bool projection_p_psi = false;					////apply p on psi or not.
	real projection_psi_s_damp = 1.;				////apply p/projection_psi_s_damp on psi
	
	bool use_fixed_dt = false;

	bool use_enforce_bc = true;
	bool use_single_source=true;
	
	bool normalize_after_advection = false;
	bool use_semi_lagrangian_psi = false;			////using the customized semi_lagrangian_psi method
	bool use_zero_extrapolation=false;				////assuming a constant outside advection value		
	real blend_coef = 0.;
	
	bool use_psi_diffusion = false;
	real psi_dif_coef=(real).0;

	bool use_euler = false;

	//////////////////////////////////////////////////////////////////////////
	////initialization
	void Allocate_Data_Base(const VectorDi& cell_counts,const real _dx,const VectorD& domain_min=VectorD::Zero()) 
	{
		mac_grid.Initialize(cell_counts,_dx,domain_min);
		impulse.Resize(cell_counts,(real)0);
		velocity.Resize(cell_counts,(real)0);
		alpha.Resize(cell_counts,(real)1);	
		type.Resize(cell_counts,(ushort)CellType::Fluid);

		if(verbose_output){
			q.Resize(cell_counts,(real)0);
			p.Resize(cell_counts,(real)0);
			grad_q.Resize(cell_counts,(real)0);
			grad_p.Resize(cell_counts,(real)0);}
	}
	void Initialize_Base()
	{
		////callback functions

		////initialize impulse
		Enforce_Boundary_Conditions(velocity);
		impulse=velocity;

		if(use_static_solid){
			////initialize solid boundary
			solid_boundary_nb_width=mac_grid.grid.dx*(real)4;
			solid_boundary_levelset.Initialize(mac_grid.grid);
			Update_Solid_Boundary_Level_Set();
			////initialize projection
			Update_Cell_Types();
			projection.update_A=false;
			projection.Allocate_System();
			projection.Update_A();
			bc.Build_Acceleration_Arrays();}
	}

	virtual void Allocate_Data(const VectorDi& cell_counts,const real _dx,const VectorD& domain_min=VectorD::Zero()) 
	{
		Allocate_Data_Base(cell_counts, _dx, domain_min);
		psi.Resize(mac_grid.grid.cell_counts);
		psi2.Resize(mac_grid.grid.cell_counts);
	}
	virtual void Add_All_Params() {
		Add_Params(__Param(h_bar), __Param(cal_impulse_option), __Param(projection_p_psi), __Param(projection_psi_s_damp), 
			 __Param(use_static_solid), __Param(use_q_projection), __Param(use_nonzero_neumann_q_proj), __Param(use_delta_q_proj),
			 __Param(normalize_after_advection), __Param(use_semi_lagrangian_psi), __Param(use_zero_extrapolation), __Param(blend_coef),
			 __Param(use_enforce_bc), __Param(use_single_source), __Param(use_psi_diffusion), __Param(psi_dif_coef), __Param(use_fixed_dt),
			 __Param(use_euler));
	}
	virtual void Initialize()
	{
		Initialize_Base();			////call this function *after* setting up the bc in the driver
		Initialize_Wave_Func();		////initialize vel from psi: psi->vel && projection
		Update_Cell_Types();

		Add_All_Params();
	}

	void Initialize_Wave_Func()
	{
		int cell_num=mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			VectorDi cell=mac_grid.grid.Cell_Coord(i);
			psi(cell) = initial_psi(mac_grid.grid.Center(cell));
			psi(cell).normalize();}
		Psi_To_Impulse(); Projection_Q(0.); Projection_P();
	}

	virtual void Update_Cell_Types()
	{
		int cell_num=mac_grid.grid.cell_counts.prod();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){VectorDi cell=mac_grid.grid.Cell_Coord(i);
			if(bc.Is_Psi_D(cell)){type(cell)=bc.Psi_D_Type(cell);}
			else type(cell)=(ushort)CellType::Fluid;}
	}

	//////////////////////////////////////////////////////////////////////////
	//// timestep 

	virtual void Advance(const real dt,const real _time=0)
	{
		if (use_euler) { Advance_Euler(dt,_time); }////switch to the Euler solver
		else { Advance_Psi(dt,_time); }
	}

	virtual void Advance_Psi(const real dt,const real _time=0)
	{
		current_time=_time; 

		bool verbose_print=false;

		Timer<real> timer; timer.Reset(); 
		////advect psi
		Advection(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Advection:");
		if(normalize_after_advection) {Normalize(psi,psi);}

		////diffuse psi
		Diffusion(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Diffusion:");

		////psi to um(impulse)
		Psi_To_Impulse(); if(verbose_print)timer.Elapse_And_Output_And_Reset("Psi_To_Impulse:");
		
		////blend imp and vel
		Reinitialization(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Reinitialization:");

		////project Q on impulse and psi
		Projection_Q(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Projection_Q:");		

		////incompressibility projection on velocity (and on psi if flag is on)
		Projection_P(); if(verbose_print)timer.Elapse_And_Output_And_Reset("Projection_P:");	
	}

	virtual void Advance_Euler(const real dt,const real _time=0)
	{
		current_time=_time; 
		
		FaceField<real,d> ghost_vel=velocity; 
		Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity,use_zero_extrapolation);
		impulse=velocity;
		Projection_P();			////velocity = impulse, then project P on velocity (and on psi if flag is on)
	}

	//////////////////////////////////////////////////////////////////////////
	//// advection

	virtual void Advection(const real dt)
	{
		////advect psi
		if (use_semi_lagrangian_psi) {
			Semi_Lagrangian_Psi(psi,dt); }
		else {
			Field<Vector4,d> ghost_psi=psi;
			Advection::Semi_Lagrangian(dt,velocity,mac_grid,ghost_psi,mac_grid,psi); } //use_zero_extrapolation
		
		//////advect vel. NOW WE NEED THIS! 
		FaceField<real,d> ghost_vel=velocity;
		Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity,use_zero_extrapolation);

		////normalize psi for each cell. NOT normalizing at this moment.
	}

	void Semi_Lagrangian_Psi(Field<Vector4,d>& psi,const real dt)
	{
		Enforce_Boundary_Conditions(psi);

		Field<Vector4,d> ghost_psi=psi;
		Interpolation<d> intp(mac_grid.grid);
		int cell_num=mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			VectorDi cell=mac_grid.grid.Cell_Coord(i);
			if(Is_Source_Cell(cell)||Is_Solid_Cell(cell))continue;	////skip the source or solid cells

			VectorD pos=mac_grid.grid.Center(cell);
			VectorD vel=intp.Interpolate_Face_Vectors(velocity,pos);
			VectorD mid_pos=pos-vel*(real).5*dt;
			vel=intp.Interpolate_Face_Vectors(velocity,mid_pos);
			VectorD backtraced_pos=pos-vel*dt;
			Vector4 advected_psi;
			
			////if the backtraced point falls into the source, use the analytical source psi
			VectorDi backtraced_cell=mac_grid.grid.Cell_Coord(backtraced_pos);
			if (use_single_source) {
				if(Is_Source_Cell(backtraced_cell)){
					advected_psi=Get_Source_Psi_By_Pos(backtraced_pos,current_time);}
				else if(Is_Solid_Cell(backtraced_cell)){advected_psi=psi(cell);}	////need a better treatment here
				else {advected_psi=intp.Interpolate_Centers(ghost_psi,backtraced_pos);}
			}
			else {
				if(Is_Solid_Cell(backtraced_cell)){advected_psi=psi(cell);}	////need a better treatment here
				else {advected_psi=intp.Interpolate_Centers(ghost_psi,backtraced_pos);}
			}
			
			
			psi(cell)=advected_psi;}	

		Enforce_Boundary_Conditions(psi);
	}

	//////////////////////////////////////////////////////////////////////////
	//// reinitialization

	//// blend the advected imp and converted imp
	void Reinitialization(const real dt)
	{
		real coef=blend_coef;
		for (int axis = 0; axis < d; axis++) {int face_num = mac_grid.face_grids[axis].Number_Of_Nodes();
			#pragma omp parallel for
			for(int i = 0; i < face_num; i++) {VectorDi face = mac_grid.face_grids[axis].Node_Coord(i);
				impulse(axis,face)=((real)1-coef)*impulse(axis,face)+coef*velocity(axis,face);}}
		Enforce_Boundary_Conditions(impulse);	
	}

	//////////////////////////////////////////////////////////////////////////
	//// boundary
	virtual void Enforce_Boundary_Conditions(Field<Vector4,d>& psi)
	{
		for(auto& pD:psi_D_psi_values){
			VectorDi cell=mac_grid.grid.Cell_Coord(pD.first);
			psi(cell)=Get_Source_Psi_By_Cell(cell,current_time);
		}
	}
	////enforce Neumann boundary values for velocity or impulse
	virtual void Enforce_Boundary_Conditions(FaceField<real,d>& field_q)
	{
		if(bc.acc_arrays_init){
			int psi_N_n=(int)bc.psi_N_key_array.size();
			#pragma omp parallel for
			for(int i=0;i<psi_N_n;i++){
				int axis=bc.psi_N_key_array[i][0];int face_index=bc.psi_N_key_array[i][1];real value=bc.psi_N_val_array[i];
				field_q.face_fields[axis].array[face_index]=value;}
		}else{
			for(auto p:bc.psi_N_values){int axis=p.first[0];int face_index=p.first[1];real value=p.second;
				field_q.face_fields[axis].array[face_index]=value;}}
	}


	//////////////////////////////////////////////////////////////////////////
	//// psi -> m

	void Psi_To_Impulse() 
	{
		if(use_enforce_bc){
			Enforce_Boundary_Conditions(psi);
			Enforce_Boundary_Conditions(velocity);}

		Normalize(psi,psi2);	////use psi2 as the the normalized psi get velocity
		impulse=velocity;		////first copy vel to imp to setup the default bc values
		Grid_Psi_To_Grid_Vel(psi2,impulse);
	}

	void Grid_Psi_To_Grid_Vel(const Field<Vector4,d>& psi,FaceField<real,d>& imp)
	{
		switch (cal_impulse_option) {
		case 0: ////v=h_bar*arg<psi_0,psi_1>		////THE ONE BEING USED!
			for (int axis = 0; axis < d; axis++) {
				int face_num = mac_grid.face_grids[axis].Number_Of_Nodes();
				#pragma omp parallel for
				for(int i = 0; i < face_num; i++) {
					VectorDi face = mac_grid.face_grids[axis].Node_Coord(i);

					if(bc.Is_Psi_N(axis,face)) { continue; } 

					const VectorDi cell_0 = mac_grid.Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1 = mac_grid.Face_Incident_Cell(axis,face,1);

					if (!mac_grid.grid.Valid_Cell(cell_0) || !mac_grid.grid.Valid_Cell(cell_1)) { continue; }

					Vector<C,2> psi_0 = V2C(psi(cell_0));
					Vector<C,2> psi_1 = V2C(psi(cell_1));
					C q = psi_0.dot(psi_1);
					imp(axis,face) = std::arg(q) * h_bar / mac_grid.grid.dx;}} break;

		case 1: ////v=h_bar*sum(ak*grad bk-bk*grad ak)	
			for (int axis = 0; axis < d; axis++) {
				int face_num = mac_grid.face_grids[axis].Number_Of_Nodes();
				#pragma omp parallel for
				for (int i = 0; i < face_num; i++) {
					VectorDi face = mac_grid.face_grids[axis].Node_Coord(i);

					if(bc.Is_Psi_N(axis,face)) { continue; } 

					const VectorDi cell_0 = mac_grid.Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1 = mac_grid.Face_Incident_Cell(axis,face,1);

					if (!mac_grid.grid.Valid_Cell(cell_0) || !mac_grid.grid.Valid_Cell(cell_1)) { continue; }

					////Bo: this part did not consider source.
					Vector<C,2> psi_0=V2C(psi(cell_0));
					Vector<C,2> psi_1=V2C(psi(cell_1));
					real u=(real)0;
					for(int j=0;j<2;j++){
						real a = (real).5*(psi_0[j].real()+psi_1[j].real());
						real grad_a = (psi_1[j].real()-psi_0[j].real())/mac_grid.grid.dx;
						real b = (real).5*(psi_0[j].imag()+psi_1[j].imag());
						real grad_b = (psi_1[j].imag()-psi_0[j].imag())/mac_grid.grid.dx;
						u += h_bar*(a*grad_b-b*grad_a);}

					imp(axis,face) = u; }}}
	}

	//////////////////////////////////////////////////////////////////////////
	//// diffusion

	virtual void Diffusion(const real dt)
	{
		real imp_dif_coef = psi_dif_coef;
		if(!use_psi_diffusion||imp_dif_coef==(real)0)return;
		int iter_num=4;real a=imp_dif_coef;

		////parallelize G-S (two colors for cell grid)
		int cell_num=mac_grid.grid.cell_counts.prod();
		auto& grid=mac_grid.grid;
		Field<Vector4,d> psi0=psi;
		for(int k=0;k<iter_num;k++){
			for(int color=0;color<2;color++){
				#pragma omp parallel for
				for(int i=0;i<cell_num;i++){
					VectorDi cell=grid.Cell_Coord(i);
					int tmp=0; for(int tmp_i=0;tmp_i<d;tmp_i++){tmp+=cell[tmp_i];}
					bool is_red = ((tmp&2)==0);
					if ((color==0&&!is_red)||(color==1&&is_red)){continue;}
					Vector4 delta=Zero<Vector4>();int nb_n=0;
					for(int j=0;j<grid.Number_Of_Nb_C();j++){
						VectorDi nb_cell=grid.Nb_C(cell,j);
						if(!grid.Valid_Cell(nb_cell))continue;
						delta+=psi0(nb_cell);nb_n++;}
					psi(cell)=(psi0(cell)+a*delta)/((real)1+(nb_n)*a);}}}
	}

	//////////////////////////////////////////////////////////////////////////
	//// projection
	virtual void Update_Projection_Q_rhs(const real dt)
	{
		if(!use_nonzero_neumann_q_proj){
			//OPTION 1: solve lap q=div u
			Enforce_Boundary_Conditions(impulse);
			int b_size=(int)projection.matrix_to_grid.size();
			#pragma omp parallel for
			for(int r=0;r<b_size;r++){
				const VectorDi& cell=mac_grid.grid.Cell_Coord(projection.matrix_to_grid[r]);
				VectorD pos=mac_grid.grid.Center(cell);
				real div=(real)0;
				////calculate the cell divergence
				for(int axis=0;axis<d;axis++){div+=(impulse(axis,cell+VectorDi::Unit(axis))-impulse(axis,cell));}
				////let the solid phi to affect the rhs
				if(use_delta_q_proj){ 
					real solid_phi=solid_boundary_levelset.Phi(pos);
					real delta=Delta(abs(solid_phi),solid_boundary_nb_width);
					div*=delta;}

				projection.div_u[r]=-div;}	////negative div here to solve -lap p=-div u		
		}else{
			////OPTION 2: solve lap q=0 with non-zero Neumann
			auto& b=projection.div_u;
			auto& A=projection.A;
			auto& grid_to_matrix=projection.grid_to_matrix;
			auto& alpha=(*projection.alpha);
			auto& bc=(*projection.bc);
			auto& vel=(*projection.velocity);
			real dx=mac_grid.grid.dx;
			b.fill((real)0);

			if(bc.acc_arrays_init){
				//std::cout<<"parallel set Dirichlet boundary rhs"<<std::endl;
				int psi_D_n=(int)bc.psi_D_key_array.size();
				#pragma omp parallel for
				for(int i=0;i<psi_D_n;i++){
					int cell_index=bc.psi_D_key_array[i]; VectorDi face=mac_grid.grid.Cell_Coord(cell_index);
					const ushort pD_type=bc.psi_D_val_array[i].first;
					real val=bc.psi_D_val_array[i].second;
					//////psi_D's rhs
					const VectorDi cell=mac_grid.grid.Cell_Coord(cell_index);
					////psi_D nbs' rhs
					for(int i=0;i<Grid<d>::Number_Of_Nb_C();i++){VectorDi nb_cell=Grid<d>::Nb_C(cell,i);
					if(mac_grid.grid.Valid_Cell(nb_cell)&&projection.Is_Fluid_Cell(nb_cell)){int r=grid_to_matrix(nb_cell);
					int axis=0;int side=0;mac_grid.grid.Nb_C_Axis_And_Side(i,axis,side);
					VectorDi face=cell+VectorDi::Unit(axis)*side;real a=alpha(axis,face);b[r]+=a*val/dx;}}}

				//std::cout<<"parallel set Neumann boundary rhs"<<std::endl;
				int psi_N_n=(int)bc.psi_N_key_array.size();
				#pragma omp parallel for
				for(int i=0;i<psi_N_n;i++){int axis=bc.psi_N_key_array[i][0];
					int face_index=bc.psi_N_key_array[i][1]; VectorDi face=mac_grid.Face_Coord(axis,face_index);
					real value=bc.psi_N_val_array[i];
					const VectorDi cell_0=MacGrid<d>::Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1=MacGrid<d>::Face_Incident_Cell(axis,face,1);
					real psi_N_val=(vel(axis,face)-value);
					if(mac_grid.grid.Valid_Cell(cell_0)){
						int r0=grid_to_matrix(cell_0);
						if(r0!=-1)b[r0]+=alpha(axis,face)*psi_N_val;}
					if(mac_grid.grid.Valid_Cell(cell_1)){
						int r1=grid_to_matrix(cell_1);
						if(r1!=-1)b[r1]-=alpha(axis,face)*psi_N_val;}}
			}else{
				////set Dirichlet boundary rhs
				for(const auto& pD:bc.psi_D_values){const int cell_index=pD.first;
				const ushort pD_type=pD.second.first;
				const real val=pD.second.second;
				//////psi_D's rhs
				const VectorDi cell=mac_grid.grid.Cell_Coord(cell_index);
				////psi_D nbs' rhs
				for(int i=0;i<Grid<d>::Number_Of_Nb_C();i++){VectorDi nb_cell=Grid<d>::Nb_C(cell,i);
				if(mac_grid.grid.Valid_Cell(nb_cell)&&projection.Is_Fluid_Cell(nb_cell)){int r=grid_to_matrix(nb_cell);
				int axis=0;int side=0;mac_grid.grid.Nb_C_Axis_And_Side(i,axis,side);
				VectorDi face=cell+VectorDi::Unit(axis)*side;real a=alpha(axis,face);b[r]+=a*val/dx;}}}

				for(const auto& pN:bc.psi_N_values){
					int axis=pN.first[0];VectorDi face=mac_grid.face_grids[axis].Node_Coord(pN.first[1]);real value=pN.second;
					const VectorDi cell_0=MacGrid<d>::Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1=MacGrid<d>::Face_Incident_Cell(axis,face,1);
					real psi_N_val=(vel(axis,face)-value);
					if(mac_grid.grid.Valid_Cell(cell_0)){
						int r0=grid_to_matrix(cell_0);
						if(r0!=-1)b[r0]+=alpha(axis,face)*psi_N_val;}
					if(mac_grid.grid.Valid_Cell(cell_1)){
						int r1=grid_to_matrix(cell_1);
						if(r1!=-1)b[r1]-=alpha(axis,face)*psi_N_val;}}}
		}
	}

	virtual void Projection_Q(const real dt)
	{
		if(!use_q_projection) {return;}

		////solve q and projection on impulse
		projection.Set_Velocity(impulse);
		Update_Projection_Q_rhs(dt);
		projection.Clear();
		projection.Solve();
		//////apply dt: dt was absorbed in p. We don't need to apply it if we did not set its value for bc
		projection.Correction();	////m-=dt*grad q
		Enforce_Boundary_Conditions(impulse);
		projection.Pressure(q);
		////projection on psi
		////psi = psi * exp(-i * q_hat / h_bar)
		Projection_Psi(psi,q);
	}

	virtual void Projection_P()
	{
		velocity=impulse;

		Enforce_Boundary_Conditions(velocity);
		projection.Set_Velocity(velocity);
		projection.Update_b();	////calculate div of velocity
		projection.Clear();
		projection.Solve();
		////project impulse
		projection.Correction(); 
		projection.Pressure(p);
		////projection on psi  ////[?] need this?
		if (projection_p_psi) {Projection_Psi(psi,p);}
	}

	void Projection_Psi(Field<Vector4,d>& psi,Field<real,d>& p)
	{
		real s_damp=projection_psi_s_damp;
		int cell_num = mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for (int i = 0; i < cell_num; i++) {
			VectorDi cell = mac_grid.grid.Cell_Coord(i);
			C c = std::exp(-1i * p(cell)*mac_grid.grid.dx / (h_bar*s_damp));
			Vector<C,2> psi_c = V2C(psi(cell));
			for (int i = 0; i < 2; i++) { psi_c[i]*=c; }
			psi(cell)=C2V(psi_c);}
	}

	//////////////////////////////////////////////////////////////////////////
	//// helper functions

	void Normalize(const Field<Vector4,d>& input,Field<Vector4,d>& output)
	{
		int cell_num = mac_grid.grid.Number_Of_Cells();
			#pragma omp parallel for
			for (int i = 0; i < cell_num; i++) {
				VectorDi cell = mac_grid.grid.Cell_Coord(i);
				output(cell)=input(cell).normalized();}	
	}

	//// cell helpers
	inline bool Is_Fluid_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Fluid;}
	inline bool Is_Solid_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Solid;}
	inline bool Is_Source_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Source;}

	//// source helpers
	//kvec = jet_velocity/isf.hbar;
	//omega = sum(jet_velocity.^2)/(2*isf.hbar); //why /2 ?
	//(init)phase = kvec(1).*isf.px + kvec(2).*isf.py + kvec(3).*isf.pz; (Vel_To_Psi_C(kvec,pos))
	//phase = kvec(1).*isf.px + kvec(2).*isf.py + kvec(3).*isf.pz -omega*t;
	//amp1 = abs(psi1);
    //psi1(isJet) = amp1(isJet).*exp(1i*phase(isJet));
	inline Vector4 Get_Source_Psi_By_Cell(const VectorDi& cell,const real time) 
	{
		int cell_idx=mac_grid.grid.Cell_Index(cell);
		////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
		Vector4 psi_v=psi_D_psi_values[cell_idx].first;
		Vector<C,2> psi=V2C(psi_v);
		real phase_u=psi_D_psi_values[cell_idx].second;
		for(int i=0;i<2;i++)psi[i]*=exp(-1i*phase_u*time);
		return C2V(psi);
	}

	inline Vector4 Get_Source_Psi_By_Pos(const VectorD& pos,const real time) 
	{
		Vector4 psi_v=initial_psi(pos);
		Vector<C,2> psi=V2C(psi_v);
		real phase_u=source_velocity.dot(source_velocity)/h_bar;
		for(int i=0;i<2;i++)psi[i]*=exp(-1i*phase_u*time);
		return C2V(psi);
	}

	//////////////////////////////////////////////////////////////////////////
	//// NOT USED: solid boundary, used only when use_nonzero_neumann_q_proj=false
	void Update_Solid_Boundary_Level_Set()
	{
		if(Solid_Boundary_Phi==nullptr){std::cerr<<"[Error] Solid_Boundary_Phi is not set"<<std::endl;return;}

		int cell_num=mac_grid.grid.cell_counts.prod();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			VectorDi cell=mac_grid.grid.Cell_Coord(i);
			VectorD pos=mac_grid.grid.Center(cell);
			real phi=Solid_Boundary_Phi(pos);
			solid_boundary_levelset.phi(cell)=phi;}
	}

	real Delta(const real phi_abs,const real epsilon)
	{
		if(phi_abs>epsilon)return (real)0;
		else{
			real coef=(phi_abs/epsilon)*(real)2;
			if(coef>(real)1) return (real).5*((real)1+cos((coef-(real)1)*pi));
			else return (real)1;}
	}

	////cfl
	real CFL() const
	{
		if(use_fixed_dt) { return (real)1; }
		else {
			real epsilon=(real)1e-5;
			return mac_grid.grid.dx/(Max_Abs(velocity)+epsilon);}
	}
};