## Command line:
```
.\quantized_gauge.exe -driver 1 -d 2 -test 20 -s 128 -o test_leapfrpg -lf 1000
```

-driver: 1 or 2. 1: smoke, 2: water

-d: dimension, 2 or 3

-test: test case
- for smoke (-driver 1):
    - 20 leap frogging
    - 21 smoke ring collision
    - 22 trefoil knot
    - 30 smoke and a sphere
    - 31 smoke and a bunny
    - 32 smoke and multiple obstacles
- water (-driver 2):
    - 1 droplet falling into water
    - 2 a droplet
    - 3 droplet falling to floor
    - 4 stream and a sphere
    - 5 stream and multiple obstacles

-s: resolution

-st: surface tension (only for water)

-o: output path (will also write parameters in output_path/0/parameters)

-lf: last frame

## viewer:
use mode imp  
(.\opengl_viewer.exe -o .\test_20\ -m imp -scale 0.1)

