//////////////////////////////////////////////////////////////////////////
// Euler fluid driver
// Author: Anonymous authors
// This file is part of XXX, whose distribution is governed by the LICENSE file.
//////////////////////////////////////////////////////////////////////////

#pragma once

#include "Common.h"
#include "AuxFunc.h"
#include "File.h"
#include "GeometryPrimitives.h"
#include "IsfFluidEuler.h"
#include "IsfFluidHelpers.h"
#include "Particles.h"
#include "MarchingCubes.h"
#include "Driver.h"
#include "Poisson.h"
#include "PrintHelpers.h"
#include "MeshToLevelSet_Copy.h"  
#include <cfloat>

template<int d> class IsfFluidEulerDriver : public Driver
{Typedef_VectorDii(d);using Base=Driver;
public:
	//FluidVortexEta<d> fluid;		////dbg
	IsfFluidEuler<d> fluid;
	Array<std::shared_ptr<ImplicitGeometry<d> > > solid_boundary_primitives;
	Field<real,2> vorticity;
	Field<Vector3,3> vorticity3d;
	bool min_io=false;
	std::string input_command = "";
	real input_alpha = -1.;
	real input_beta = -1.;

	virtual real CFL() const
	{
		return cfl*fluid.CFL();
	}

	virtual void Advance_One_Time_Step(const real dt,const real time)
	{
		fluid.Advance(dt,time);
	}

	virtual void Write_Output_Files(const int frame)
	{	
		int io_level=1;
		Base::Write_Output_Files(frame);
		
		// if(!min_io)fluid.Sync_Output();

		if(frame==0){
			std::string file_name=frame_dir+"/grid";
			fluid.mac_grid.grid.Write_To_File_3d(file_name);
			std::cout<<"Write to file "<<file_name<<std::endl;
			std::string command_file=frame_dir+"/parameters";
			std::ofstream out_file(command_file);
			out_file<<"Command line input: \n" <<input_command<<"\n"<<std::endl;
			fluid.Print_Param(out_file);
			std::cout<<"Write the parameters to file "<<command_file<<std::endl;
		}
		
		////Write velocity
		{std::string file_name=frame_dir+"/velocity";
		fluid.velocity.Write_To_File_3d(file_name);}
		
		if (io_level>=1) {
			////Write psi
			//std::string file_name=frame_dir+"/s";
			//fluid.s.Write_To_File_3d(file_name);
			{std::string file_name=frame_dir+"/psi";
			Field<Vector3,d> q(fluid.psi.counts,Vector3::Zero());
			for(int i=0;i<q.array.size();i++){
				real _tmp = fluid.psi.array[i].norm();
				for (int _ = 0; _ < 3; _++) { q.array[i][_] = fluid.psi.array[i][_]/_tmp; }
				//AngleAxis a=AngleAxis(fluid.psi.array[i]);
				//q.array[i]=a.axis()*a.angle();
			}
			q.Write_To_File_3d(file_name);}

			////Write bc
			if(frame==0||!fluid.use_static_solid)
			{std::string file_name=frame_dir+"/psi_D";
			Particles<d> particles;
			for(auto p:fluid.bc.psi_D_values){
				VectorDi cell=fluid.mac_grid.grid.Cell_Coord(p.first);
				VectorD pos=fluid.mac_grid.grid.Center(cell);
				int i=particles.Add_Element();particles.X(i)=pos;}
			particles.Write_To_File_3d(file_name);}

			if(frame==0||!fluid.use_static_solid)
			{std::string file_name=frame_dir+"/psi_N";
			Particles<d> particles;
			for(auto p:fluid.bc.psi_N_values){int axis=p.first[0];
				VectorDi face=fluid.mac_grid.Face_Coord(axis,p.first[1]);
				VectorD pos=fluid.mac_grid.Face_Center(axis,face);
				int i=particles.Add_Element();particles.X(i)=pos;}
			File::Write_Binary_To_File(file_name,particles);
			particles.Write_To_File_3d(file_name);}
		}

		if(io_level>=2){
		//////Write vorticity
			{ if constexpr (d == 2) {
				std::string file_name=frame_dir+"/vor";
				FluidFunc::Curl_On_Cell(fluid.mac_grid,fluid.velocity,vorticity);
				vorticity.Write_To_File_3d(file_name);}
			if constexpr (d == 3) {
				std::string file_name=frame_dir+"/vor3d";
				FluidFunc::Curl_On_Cell(fluid.mac_grid,fluid.velocity,vorticity3d);
				vorticity3d.Write_To_File_3d(file_name); 
			} }
		////Write impulse
			{std::string file_name=frame_dir+"/impulse";
			fluid.impulse.Write_To_File_3d(file_name); }
		
		////Write solid boundary phi
			if(frame==0||!fluid.use_static_solid)
			{std::string file_name=frame_dir+"/solid_phi";
			fluid.solid_boundary_levelset.phi.Write_To_File_3d(file_name);}

		//////Write q
			{std::string file_name=frame_dir+"/q";
			fluid.q.Write_To_File_3d(file_name);}

		//////Write p
			{std::string file_name=frame_dir+"/p"; 
			fluid.p.Write_To_File_3d(file_name);}

		////Write fluid type
			if(frame==0||!fluid.use_static_solid)
			{std::string file_name=frame_dir+"/fluid_type";
			Field<real,d> fluid_type;fluid_type.Resize(fluid.mac_grid.grid.cell_counts);
			iterate_cell(iter,fluid.mac_grid.grid){const VectorDi& cell=iter.Coord();
				if(fluid.type(cell)==(ushort)CellType::Fluid)fluid_type(cell)=(real)0;
				else fluid_type(cell)=(real)1;}
			fluid_type.Write_To_File_3d(file_name);
			
			}

			{std::string file_name=frame_dir+"/velocity_face";
			Write_Face_Vectors_To_File_3d_Fast<d>(fluid.velocity,fluid.mac_grid,file_name);}
		}


		std::cout<<"Write to frame "<<frame<<std::endl;
	}
	
	virtual void Initialize()
	{
		//default frame_rate=50 in Drive.h  

		switch(test){		
////VORTEX CASES
		case 20:{	////leap frog  
			frame_rate = 25;
			int s=scale; real length=(real)10; VectorDi cell_counts=VectorDi::Ones()*s; 
			//cell_counts[0]/=4;cell_counts[0]*=5; 
			// cell_counts[0] *= 2;
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);

			fluid.h_bar = .5; 
			fluid.projection_p_psi = true; 
			fluid.use_enforce_bc = true;
			fluid.use_q_projection = false;
			fluid.use_nonzero_neumann_q_proj = false;
			fluid.use_delta_q_proj = true;
			fluid.use_semi_lagrangian_psi = false;
			fluid.use_psi_diffusion = false;
			fluid.psi_dif_coef=(real).0;
			fluid.blend_coef = .0;
			fluid.normalize_after_advection = true;
			fluid.cal_impulse_option = 1;
			fluid.projection_psi_s_damp = 2.5; //10000.; // 5.; // 1.
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			VectorD bdry_v=VectorD::Unit(0)*(real)-1.; //fluid.velocity.Fill(bdry_v);
			if (d==2) {bdry_v=VectorD::Unit(0)*(real)-.2;}
			VectorD bdry_v_hbar = bdry_v / fluid.h_bar; 
			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Psi_Leap_Frog,this,std::placeholders::_1, bdry_v_hbar, length);

			for(int axis=0;axis<d;axis++){int face_num=fluid.mac_grid.Number_Of_Faces(axis);
				#pragma omp parallel for
				for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
					if(!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face))continue;
					#pragma omp critical
					{fluid.bc.Set_Psi_N(axis,face,bdry_v[axis]);}}}
		
			//for (int i = 0; i < d; i++) {
			//	solid_boundary_primitives.push_back(std::make_shared<Plane<d> >(Plane<d>(VectorD::Unit(i),fluid.mac_grid.grid.domain_min)));		////bottom wall
			//	solid_boundary_primitives.push_back(std::make_shared<Plane<d> >(Plane<d>(-VectorD::Unit(i),fluid.mac_grid.grid.domain_max)));		////top wall
			//}			
			//fluid.Solid_Boundary_Phi=std::bind(&IsfFluidEulerDriver<d>::Solid_Boundary_Phi,this,std::placeholders::_1);
			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		}break;


		case 21:{	////smoke ring collision 
			frame_rate = 25;
			int s=scale; real length=(real)12.5; //10; 
			VectorDi cell_counts=VectorDi::Ones()*s; 
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);

			fluid.h_bar = .5; 
			fluid.projection_p_psi = true; 
			fluid.use_q_projection = false;
			fluid.use_nonzero_neumann_q_proj = false;
			fluid.use_delta_q_proj = true;
			fluid.use_psi_diffusion = false;
			fluid.psi_dif_coef=(real).0;
			fluid.blend_coef = 0.;
			fluid.normalize_after_advection = true;
			fluid.cal_impulse_option = 1;
			fluid.projection_psi_s_damp = 4;
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			VectorD bdry_v=VectorD::Zero(); 
			VectorD bdry_v_hbar = bdry_v / fluid.h_bar; 
			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Smoke_Ring_Collision,this,std::placeholders::_1, bdry_v_hbar);

			//for(int axis=0;axis<d;axis++){int face_num=fluid.mac_grid.Number_Of_Faces(axis);
			//	#pragma omp parallel for
			//	for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
			//		if(!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face))continue;
			//		#pragma omp critical
			//		{fluid.bc.Set_Psi_N(axis,face,bdry_v[axis]);}}}
		
			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		}break;

		case 22:{	////trefoil knot
			frame_rate = 50;
			int s=scale; real length=(real)5; VectorDi cell_counts=VectorDi::Ones()*s; 
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);

			fluid.h_bar = .1; 
			fluid.projection_p_psi = true;  
			fluid.use_q_projection = false;
			fluid.use_nonzero_neumann_q_proj = false;
			fluid.use_delta_q_proj = true;
			fluid.use_psi_diffusion = false; ////////////
			fluid.psi_dif_coef=(real).01;  ////////////
			fluid.blend_coef = 0.;
			fluid.normalize_after_advection = true;
			fluid.cal_impulse_option = 1;
			fluid.projection_psi_s_damp = 20;
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			VectorD bdry_v=VectorD::Unit(2)*.0;  
			fluid.velocity.Fill(bdry_v);
			VectorD bdry_v_hbar = bdry_v / fluid.h_bar; 
			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Trefoil_Knot,this,std::placeholders::_1,length);

			//for(int axis=0;axis<d;axis++){
			////int axis = 2;
			//int face_num=fluid.mac_grid.Number_Of_Faces(axis);
			//	#pragma omp parallel for
			//	for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
			//		if(!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face))continue;
			//		#pragma omp critical
			//		{fluid.bc.Set_Psi_N(axis,face,bdry_v[axis]);}}
			//}
		
			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		}break;


		////SMOKE CASES
		case 30: {   ////smoke and sphere
			frame_rate = 10;
			int s=scale; 
			real length=(real)10; 
			VectorDi cell_counts=VectorDi::Ones()*s; cell_counts[0] *= 2;
			std::cout << cell_counts.transpose() << std::endl;
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);
			
			fluid.projection_p_psi=true; 
			fluid.use_q_projection=false;				//no big difference between true and false  
			fluid.use_enforce_bc=true;
			fluid.use_psi_diffusion=false;
			fluid.psi_dif_coef=(real)0.; //.01;
			fluid.blend_coef=0.98;
			fluid.h_bar=1.; 
			fluid.use_zero_extrapolation=true;
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			VectorD ghost_v=VectorD::Unit(0)*(real).5;
			fluid.velocity.Fill(ghost_v);
			VectorD ghost_v_hbar = ghost_v/fluid.h_bar; 

			VectorD source_velocity=VectorD::Unit(0)*(real)5;
			VectorD source_v_hbar = source_velocity/fluid.h_bar; 
			
			VectorD box_center=fluid.mac_grid.grid.Position(V<d>((real).05,(real).5,(real).5));
			VectorD box_size=V<d>((real).05,(real).075,(real).075)*length;
			Box<d> box(box_center-box_size,box_center+box_size);

			std::function<bool(const VectorD& pos)> in_source = [&](const VectorD& pos)->bool{
				auto rx=pos-box_center; 
				real r2=rx[1]*rx[1]; if(d==3){r2+=rx[2]*rx[2];}
				return (rx[0]<=box_size[0]); //(r2<=box_size[1]*box_size[1]);// && std::abs(rx[0])<=box_size[0]); //
			};

							
			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Plume_Ghost,this,std::placeholders::_1, source_v_hbar, in_source,ghost_v_hbar);
			fluid.source_velocity = source_velocity;

			////source
			iterate_cell(iter,fluid.mac_grid.grid){
				const VectorDi& cell=iter.Coord();
				const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(in_source(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Source);  
					//psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] 
						= std::make_pair(fluid.initial_psi(pos), source_velocity.dot(source_velocity)/fluid.h_bar);		
					for(int axis=0;axis<d;axis++)
						for(int side=0;side<2;side++) {
							VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
							fluid.bc.Set_Psi_N(axis,face,source_velocity[axis]);
							fluid.velocity(axis,face) = source_velocity[axis];}}}

			////obstacle
			VectorD ob_center=fluid.mac_grid.grid.Position(V<d>((real).4,(real).5,(real).5));
			real r=(real)1.0; Sphere<d> obstacle(ob_center,r);
			iterate_cell(iter,fluid.mac_grid.grid) {
				const VectorDi& cell=iter.Coord(); const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(obstacle.Inside(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Solid);
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] = std::make_pair(Vector4::Zero(),(real)0);
					for(int axis=0;axis<d;axis++) for(int side=0;side<2;side++){
						VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
						fluid.bc.Set_Psi_N(axis,face,(real)0);}}}
			solid_boundary_primitives.push_back(std::make_shared<Sphere<d> >(obstacle));
			fluid.Solid_Boundary_Phi=std::bind(&IsfFluidEulerDriver<d>::Solid_Boundary_Phi,this,std::placeholders::_1);

			// for(int axis=0;axis<d;axis++){int face_num=fluid.mac_grid.Number_Of_Faces(axis);
			// 	for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
			// 		if(!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face)||
			// 			(axis==0&&face[0]==fluid.mac_grid.face_grids[0].node_counts[0]-1))continue;
			// 		{fluid.bc.Set_Psi_N(axis,face,ghost_v[axis]);}}}

			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		} break;

		case 31: {   ////smoke and bunny
			frame_rate = 10;
			int s=scale; 
			real length=(real)10; 
			VectorDi cell_counts=VectorDi::Ones()*s; cell_counts[0] *= 2;
			std::cout << cell_counts.transpose() << std::endl;
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);
			
			fluid.projection_p_psi=true; 
			fluid.use_q_projection=false;				//no big difference between true and false  
			fluid.use_enforce_bc=true;
			fluid.use_psi_diffusion=false;
			fluid.psi_dif_coef=0.; //(real).01;
			fluid.blend_coef=0.98;
			fluid.h_bar=1.; 
			fluid.use_zero_extrapolation=true;
			fluid.cal_impulse_option=1;
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			fluid.velocity.Fill(VectorD::Zero());
			VectorD bdry_v=VectorD::Unit(0)*(real).1;
			fluid.velocity.Fill(bdry_v);

			VectorD source_velocity=VectorD::Unit(0)*(real)4;
			VectorD source_v_hbar = source_velocity/fluid.h_bar; 
			
			VectorD box_center=fluid.mac_grid.grid.Position(V<d>((real).05,(real).5,(real).5));
			VectorD box_size=V<d>((real).05,(real).075,(real).075)*length;
			Box<d> box(box_center-box_size,box_center+box_size);

			std::function<bool(const VectorD& pos)> in_source = [&](const VectorD& pos)->bool{
				auto rx=pos-box_center; 
				real r2=rx[1]*rx[1]; if(d==3){r2+=rx[2]*rx[2];}
				return (r2<=box_size[1]*box_size[1] && std::abs(rx[0])<=box_size[0]); //
			};

			VectorD ghost_v=VectorD::Unit(0)*(real)2.;
			VectorD ghost_v_hbar = ghost_v/fluid.h_bar; 

			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Plume_Ghost,this,std::placeholders::_1, source_v_hbar, in_source, ghost_v);
			fluid.source_velocity = source_velocity;

			////source
			iterate_cell(iter,fluid.mac_grid.grid){
				const VectorDi& cell=iter.Coord();
				const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(in_source(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Source);  
					//psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] 
						= std::make_pair(fluid.initial_psi(pos), source_velocity.dot(source_velocity)/fluid.h_bar);	
					for(int axis=0;axis<d;axis++)
						for(int side=0;side<2;side++) {
							VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
							fluid.bc.Set_Psi_N(axis,face,source_velocity[axis]);
							fluid.velocity(axis,face) = source_velocity[axis];}}}

			////bunny obstacle
			real ob_scale=.3; 
			VectorDi ob_position=VectorDi::Ones()*(int)(s*(.5-ob_scale/2.)); 
			ob_position[0]*=1.6; ob_position[1]*=1.08; ob_position[2]*=1.03;
			VectorDi ob_cell_counts = VectorDi::Ones(); ob_cell_counts = ob_cell_counts*(int)(s*ob_scale);
			Grid<d> ob_grid;
			ob_grid.Initialize(ob_cell_counts,1./ob_cell_counts[0]);
			LevelSet<d> ob_level_set;
			ob_level_set.Initialize(ob_grid);
			SurfaceMesh<d> ob_mesh;
			std::string input_path = "../../../../simplex/data/meshes/rabbit_scaled_complete.txt";
			std::ifstream input(input_path.c_str());
			File::Read_Text(input,ob_mesh);
			MeshFunc::Mesh_To_Level_Set(ob_mesh,ob_grid,ob_level_set);

			iterate_cell(iter,fluid.mac_grid.grid) {
				const VectorDi& cell=iter.Coord(); const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				const VectorDi& ob_cell = cell - ob_position;
				if(ob_grid.Valid_Cell(ob_cell) && ob_level_set.phi(ob_cell)<0) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Solid);
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] = std::make_pair(Vector4::Zero(),(real)0);
					for(int axis=0;axis<d;axis++) for(int side=0;side<2;side++){
						VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
						fluid.bc.Set_Psi_N(axis,face,(real)0);}}}

			fluid.Solid_Boundary_Phi=std::bind(&IsfFluidEulerDriver<d>::Solid_Boundary_Phi,this,std::placeholders::_1);

			for(int axis=0;axis<d;axis++){int face_num=fluid.mac_grid.Number_Of_Faces(axis);
				for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
					if(!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face)||
						(axis==0&&face[0]==fluid.mac_grid.face_grids[0].node_counts[0]-1))continue;
					{fluid.bc.Set_Psi_N(axis,face,ghost_v[axis]);}}}

			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		} break;

		case 32: {   ////smoke and multiple obstacles
			frame_rate = 10;
			int s=scale; 
			real length=(real)10; 
			VectorDi cell_counts=VectorDi::Ones()*s; cell_counts[0] *= 2;
			std::cout << cell_counts.transpose() << std::endl;
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[1]);
			
			fluid.projection_p_psi=true; 
			fluid.use_q_projection=false;				//no big difference between true and false  
			fluid.use_enforce_bc=true;
			fluid.use_psi_diffusion=false;
			fluid.psi_dif_coef=0.; //(real).01;
			fluid.blend_coef=0.98;
			fluid.h_bar=1.; 
			fluid.use_zero_extrapolation=true;
			if (input_alpha >= 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta >= 0) { fluid.blend_coef = 1. - input_beta; }

			VectorD source_velocity=VectorD::Unit(0)*(real)5.;
			VectorD source_v_hbar = source_velocity/fluid.h_bar; 
			
			// VectorD box_center=fluid.mac_grid.grid.Position(V<d>((real).05,(real).5,(real).5));
			// VectorD box_size=V<d>((real).05,(real).05,(real).05)*length;
			// Box<d> box(box_center-box_size,box_center+box_size);
			real src_height = 0.15*length; real src_length = 0.025*length;
			std::function<bool(const VectorD& pos)> in_source = [&](const VectorD& pos)->bool{
				bool flag = (pos[0]<src_length);
				if (d==3) {flag = (flag & (pos[2]<src_height));}
				return flag;};							
			fluid.initial_psi=std::bind(&IsfFluidEulerDriver<d>::Initial_Plume,this,std::placeholders::_1, source_v_hbar, in_source);
			fluid.source_velocity = source_velocity;
			////source
			iterate_cell(iter,fluid.mac_grid.grid){
				const VectorDi& cell=iter.Coord();
				const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(in_source(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Source);  
					//psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] 
						= std::make_pair(fluid.initial_psi(pos), source_velocity.dot(source_velocity)/fluid.h_bar);	
					for(int axis=0;axis<d;axis++)
						for(int side=0;side<2;side++) {
							VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
							fluid.bc.Set_Psi_N(axis,face,source_velocity[axis]);
							fluid.velocity(axis,face) = source_velocity[axis];}}}
			
			std::vector<real> ob_size = {1.,.8,.8,.8,1.25,.8}; 
			std::vector<VectorD> ob_centers = {
				fluid.mac_grid.grid.Position(V<d>((real).3,(real).35,(real).0)),
				fluid.mac_grid.grid.Position(V<d>((real).4,(real).65,(real).0)),
				fluid.mac_grid.grid.Position(V<d>((real).6,(real).6,(real).0)),
				fluid.mac_grid.grid.Position(V<d>((real).5,(real).325,(real).0)),
				fluid.mac_grid.grid.Position(V<d>((real).75,(real).3,(real).0)),
				fluid.mac_grid.grid.Position(V<d>((real).8,(real).7,(real).0))
			};
			if (d==3) {
			for (int i = 0; i < ob_size.size(); i++) {
				ob_centers[i][2] = ob_size[i];
			}}
			std::function<bool(const VectorD& pos)> in_obstacle = [&](const VectorD& pos)->bool{
				for (int i = 0; i < ob_size.size(); i++) {
					VectorD dx = ob_centers[i] - pos;
					real dis = std::sqrt(dx[0]*dx[0]+dx[1]*dx[1]);
					if (d==3) {
						if (i%2 == 0) { 
							dis = std::sqrt(dis*dis + dx[2]*dx[2]); 
							if (dis <= ob_size[i]) { return true; }
						}  //sphere && 3d 
						else { 
							if (dis <= ob_size[i] /*&& pos[2] < length/2.*/) {return true;}
						} 
					} else {
						if (dis <= ob_size[i]) { return true; }
					}
				} 
				return false; };	

			////obstacle
			iterate_cell(iter,fluid.mac_grid.grid) {
				const VectorDi& cell=iter.Coord(); const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(in_obstacle(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Solid);
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] = std::make_pair(Vector4::Zero(),(real)0);
					for(int axis=0;axis<d;axis++) for(int side=0;side<2;side++){
						VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
						fluid.bc.Set_Psi_N(axis,face,(real)0);}}}
			//solid_boundary_primitives.push_back(std::make_shared<Sphere<d> >(obstacle));
			fluid.Solid_Boundary_Phi=std::bind(&IsfFluidEulerDriver<d>::Solid_Boundary_Phi,this,std::placeholders::_1);

			////ghost velocity
			VectorD ghost_v=source_velocity/2.5;
			for(int axis=0;axis<d;axis++){int face_num=fluid.mac_grid.Number_Of_Faces(axis);
				for(int i=0;i<face_num;i++){VectorDi face=fluid.mac_grid.Face_Coord(axis,i);
					if(	in_source(fluid.mac_grid.Face_Center(axis,face))	||
						!fluid.mac_grid.Is_Axial_Boundary_Face(axis,face)	||
						(axis==0&&face[0]==fluid.mac_grid.face_grids[0].node_counts[0]-1)) continue;
					{fluid.bc.Set_Psi_N(axis,face,ghost_v[axis]);}}}
			
			fluid.velocity.Fill(ghost_v);
			fluid.Initialize();	
			if constexpr(d==2){vorticity.Resize(cell_counts);} if constexpr(d==3){vorticity3d.Resize(cell_counts);} 
		} break;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	////initial psi conditions
	Vector4 Initial_Psi_Leap_Frog(const VectorD& pos, const VectorD& bdry_v, const real length)
	{
		////leap frog with flow boundary
		Vector<C,2> psi=Vel_To_Psi_C<d>(bdry_v,pos);
		Array<VectorD> c={V<d>((real)length*.5,(real)length/2,(real)length/2),V<d>((real)length*.5,(real)length/2,(real)length/2)};
		Array<real> r={1.6,1.0};	////{2.0,1.0}
		if (d==2) {r[0] = 2.0; }
		int n=(int)c.size();
		for(int i=0;i<n;i++){
			real rx=(pos[0]-c[i][0])/r[i];
			real r2=(pos-c[i]).squaredNorm()/pow(r[i],2);
			real D=exp(-pow(r2/(real)9,(real)4));
			C q(2.*rx*D/(r2+1),(r2+1.-2.*D)/(r2+1));
			psi[0]*=q;}
		return C2V(psi);	 	
	}

	Vector4 Initial_Smoke_Ring_Collision(const VectorD& pos, const VectorD& bdry_v = VectorD::Zero())
	{
		Vector<C,2> psi=Vel_To_Psi_C<d>(bdry_v,pos);
		Array<VectorD> c={V<d>((real)2.5,(real)8,(real)6.25),V<d>((real)4.5,(real)10,(real)6.25)};
		Array<real> r={1.6,1.6};	
		for(int i=0;i<2;i++){
			real r2=(pos-c[i]).squaredNorm()/pow(r[i],2);
			real D=exp(-pow(r2/(real)9,(real)4));
			if (i == 0) {  
				real rx=(pos[0]-c[i][0])/r[i];
				C q(2.*rx*D/(r2+1),(r2+1.-2.*D)/(r2+1));
				psi[0]*=q;
			} else if (i == 1) {
				real rx=((pos[0]-c[i][0])*0.0 + (pos[1]-c[i][1])*1)/r[i];
				C q(2.*rx*D/(r2+1),-(r2+1.-2.*D)/(r2+1));
				psi[0]*=q;
			}
		}
		return C2V(psi);	
	}

	Vector4 Initial_Trefoil_Knot(const VectorD& pos, real length)
	{
		VectorD lambda = AuxFunc::V<d>(1.2,1.2,3.); // lambda_z: larger
		VectorD center = AuxFunc::V<d>(length/2,length/2,length/2*0.5);
		VectorD XYZ = pos - center; for (int i=0; i<d; i++) {XYZ[i] *= lambda[i];}
		real R = XYZ.norm();

		real fR = exp(-pow(R,8)/pow(9,4));
		C alpha = C(XYZ[0], XYZ[1])*2.*fR/(1+R*R);
		//C beta = C(2.*(XYZ[2]-1)*fR, (1+R*R))/(1+R*R);
		C beta = C(2.*XYZ[2]*fR, (1+R*R-2*fR))/(1+R*R);
		C P = alpha*alpha*alpha*alpha*alpha;
		C Q = alpha*alpha*alpha + beta*beta;
		//P: psi1; Q: psi2
		Vector<C,2> psi;
		psi[0] = P;
		psi[1] = Q;
		return C2V(psi).normalized();
	}
	

	//////////////////////////////////////////////////////////////////////////
	////initial psi conditions (smoke)

	Vector4 Initial_Psi_Karman(const VectorD& pos, const VectorD& v, const Sphere<d>& sph) {
		Vector<C,2> psi;
		if (sph.Inside(pos)) {   ////zero speed inside obstacle
			psi = Vel_To_Psi_C<d>(v, sph.center); //(VectorD::Zero(),pos);
		} else {
			psi = Vel_To_Psi_C<d>(v,pos);
		}
		return C2V(psi);	
	}
	
	Vector4 Initial_Plume(const VectorD& pos, const VectorD& v, std::function<bool(const VectorD& pos)> in_source) {
		Vector<C,2> psi;
		if (in_source(pos)) {   
			psi = Vel_To_Psi_C<d>(v,pos);
		} else { //// zero speed outside box
			psi = Vel_To_Psi_C<d>(v/10,pos);
		}
		return C2V(psi);	
	}
	Vector4 Initial_Plume_Ghost(const VectorD& pos, const VectorD& v, std::function<bool(const VectorD& pos)> in_source, const VectorD& ghost_v) {
		Vector<C,2> psi;
		if (in_source(pos)) {   
			psi = Vel_To_Psi_C<d>(v,pos);
		} else { //// zero speed outside box
			psi = Vel_To_Psi_C<d>(ghost_v,pos);
		}
		return C2V(psi);	
	}

	Vector4 Initial_Two_Plume(const VectorD& pos, 
		const VectorD& v1, std::function<bool(const VectorD& pos)> in_source1,
		const VectorD& v2, std::function<bool(const VectorD& pos)> in_source2
		) {
		Vector<C,2> psi;
		if (in_source1(pos)) {   
			psi = Vel_To_Psi_C<d>(v1,pos);
		} else if (in_source2(pos)) {
			psi = Vel_To_Psi_C<d>(v2,pos);
		} else { //// zero speed outside box
			psi = Vel_To_Psi_C<d>((v1+v2)/10,pos);
		}
		return C2V(psi);	
	}

	Vector4 Initial_Psi_Const_Vel(const VectorD& pos,const VectorD& v)
	{
		Vector<C,2> psi=Vel_To_Psi_C<d>(v,pos);
		return C2V(psi);	
	}
	
	//////////////////////////////////////////////////////////////////////////
	////solid boundary
	real Solid_Boundary_Phi(const VectorD& pos)
	{
		real phi=(real)FLT_MAX;
		for(auto& obj:solid_boundary_primitives){
			real p0=obj->Phi(pos);if(p0<phi)phi=p0;}
		return phi;
	}
};