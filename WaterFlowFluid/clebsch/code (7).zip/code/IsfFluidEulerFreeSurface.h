//////////////////////////////////////////////////////////////////////////
// Euler fluid freesurface simulator
// Author: Anonymous authors
// This file is part of XXX, whose distribution is governed by the LICENSE file.
//////////////////////////////////////////////////////////////////////////
#pragma once
#include <complex>
#include <cmath>
#include "Common.h"
#include "FluidEuler.h"
#include "Vorticity.h"
#include "AuxFunc.h"
#include "MacGrid.h"
#include "Projection.h"
#include "BoundaryCondition.h"
#include "Advection.h"
#include "Particles.h"
#include "Interpolation.h"
#include "RandomNumber.h"
#include "SpatialHashing.h"
#include "Timer.h"
#include "IsfFluidHelpers.h"
#include "FluidFunc.h"
#include "PrintHelpers.h"
#include "ProjectionIrregular.h"

using namespace AuxFunc;
using namespace std::complex_literals;

template<int d> class IsfFluidEulerFreeSurface : public IsfFluidEuler<d>
{Typedef_VectorDii(d);using Base=IsfFluidEuler<d>;
public:
	using Base::mac_grid;
	using Base::velocity;
	using Base::alpha;
	using Base::type;							////type is initialized inDiffusion Update_Cell_Types and used in projection
	using Base::bc;								////velocity and impulse share bc
	using Base::use_body_force;					////default false
	using Base::g;
	using Base::Max_Abs;
	using Base::Enforce_Boundary_Conditions;
	using Base::impulse;
	using Base::Solid_Boundary_Phi;
	using Base::solid_boundary_nb_width;
	using Base::solid_boundary_levelset; 
	using Base::psi;
	using Base::psi2;
	using Base::initial_psi;
	using Base::psi_D_psi_values;
	using Base::current_time;
	using Base::h_bar;
	using Base::projection_p_psi;
	using Base::cal_impulse_option;
	using Base::use_fixed_dt;
	using Base::use_enforce_bc;
	using Base::blend_coef;
	using Base::use_psi_diffusion;
	using Base::psi_dif_coef;
	using Base::normalize_after_advection;
	using Base::use_semi_lagrangian_psi;
	using Base::projection_psi_s_damp;
	using Base::use_zero_extrapolation;
	using Base::q;
	using Base::p;
	using Base::grad_q;
	using Base::grad_p;
	using Base::use_static_solid;
	using Base::use_q_projection;
	using Base::use_nonzero_neumann_q_proj;
	using Base::verbose_output;
	using Base::use_delta_q_proj;
	using Base::Delta;
	using Base::Is_Fluid_Cell;
	using Base::Is_Source_Cell;
	using Base::verbose_print;
	using Base::Update_Solid_Boundary_Level_Set;
	using Base::source_velocity;
	using Base::use_euler;

	__Declare_PrintParamHelpers 

	using Base::Initialize_Wave_Func;
	using Base::Reinitialization;
	using Base::Diffusion;

	////irregular projection
	ProjectionIrregular<d> projection;

	////free surface
	LevelSet<d> levelset;
	int narrow_band_cell_num=4;
	real narrow_band_width;

	////interfacial forces
	real surface_tension=(real)1e-1;		
	real current_dt=(real)1;
	bool use_marangoni_force=false;
	bool use_friction_force=false;

	bool use_external_pressure_jump=false;
	std::function<real(const VectorD&)> External_Pressure_Jump=nullptr;
	std::function<void(const real)> Apply_External_Force=nullptr;

	////stream source
	bool use_stream=false;
	int stream_axis=0;
	real stream_phi=(real)0;

	//////////////////////////////////////////////////////////////////////////
	////initialization
	IsfFluidEulerFreeSurface():projection(mac_grid,velocity,levelset,bc){}

	virtual void Allocate_Data_Base(const VectorDi& cell_counts,const real _dx,const VectorD& domain_min=VectorD::Zero()) 
	{
		Base::Allocate_Data(cell_counts,_dx,domain_min);
		solid_boundary_levelset.Initialize(mac_grid.grid);
		levelset.Initialize(mac_grid.grid);
		narrow_band_width=mac_grid.grid.dx*(real)narrow_band_cell_num;
	}
	virtual void Initialize_Base()
	{
		////initialize impulse
		Enforce_Boundary_Conditions(velocity);
		impulse=velocity;
	
		////initialize solid boundary
		Update_Solid_Boundary_Level_Set(); 

		bc.Build_Acceleration_Arrays();

		////projection callback functions
		projection.Jump_Condition=std::bind(&IsfFluidEulerFreeSurface::Pressure_Jump_On_Free_Surface,this,std::placeholders::_1);
		projection.Is_Fluid_Cell=std::bind(&IsfFluidEulerFreeSurface<d>::Is_Fluid_Cell,this,std::placeholders::_1);
		projection.Is_Fluid_Cell_Index=std::bind(&IsfFluidEulerFreeSurface<d>::Is_Fluid_Cell_Index,this,std::placeholders::_1);
		projection.Is_Fluid_Interior_Cell_Index=std::bind(&IsfFluidEulerFreeSurface<d>::Is_Fluid_Interior_Cell_Index,this,std::placeholders::_1);
		projection.use_update_A_in_parallel=true;

		Update_Cell_Types();
	}
	virtual void Allocate_Data(const VectorDi& cell_counts,const real _dx,const VectorD& domain_min=VectorD::Zero()) 
	{
		Allocate_Data_Base(cell_counts, _dx, domain_min);
		psi.Resize(mac_grid.grid.cell_counts);
		psi2.Resize(mac_grid.grid.cell_counts);
	}
	virtual void Initialize_Parameters_Default()
	{
		use_q_projection=true;

		projection.use_vol_control=true;
		projection.target_vol=projection.current_vol=levelset.Total_Volume();
		projection.use_multigrid_solver=false;
		projection.verbose=verbose_print;	
	}
	virtual void Initialize_Parameters_Stream()
	{
		use_q_projection=true;

		use_zero_extrapolation=true;

		projection.use_vol_control=false;
		projection.use_multigrid_solver=false;
		projection.verbose=verbose_print;

		use_stream=true;
	}
	virtual void Add_All_Params() {
		Base::Add_All_Params();
		Add_Params(__Param(surface_tension), __Param(use_marangoni_force), __Param(use_friction_force), 
			 __Param(use_external_pressure_jump), __Param(use_stream), __Param(stream_axis));
	}
	virtual void Initialize()
	{
		Initialize_Base();			////call this function *after* setting up the bc in the driver
		Initialize_Wave_Func();		////initialize vel from psi: psi->vel && projection. using Base
		Add_All_Params();
	}

	//////////////////////////////////////////////////////////////////////////
	//// timestep 
	virtual void Advance(const real dt,const real _time=0)
	{
		current_dt=dt;
		if (use_euler) { Advance_Euler(dt,_time); } ////switch to the Euler solver
		else { Advance_Psi(dt,_time); }
	}

	virtual void Advance_Euler(const real dt,const real _time=0)
	{
		current_time=_time; current_dt=dt;

		projection.use_jump_condition=true;
		use_body_force=false; //// turn off body force to exclude it from jump_condition (body force is added in Apply_Body_Forces)

		Advection_Euler(dt);
		// Extrapolation(velocity);
		// FaceField<real,d> ghost_vel=velocity; 
		// Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity);
		
		impulse=velocity;
		Apply_Body_Forces(dt); //// apply body force on impulse
		Projection_P_Euler(dt);		////velocity = impulse, then project P on velocity 
	}
	virtual void Advection_Euler(const real dt)
	{
		Extrapolation(velocity);

		//////advect vel	
		FaceField<real,d> ghost_vel=velocity;
		Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity,use_zero_extrapolation);

		////levelset advection
		Field<real,d> ghost_phi=levelset.phi;
		std::function<bool(const VectorDi&)> valid_cell=[&](const VectorDi& cell)->bool{return Is_Fluid_Nb_Cell(cell);};
		Advection::Semi_Lagrangian(dt,velocity,mac_grid,ghost_phi,mac_grid,levelset.phi,false,valid_cell);
		levelset.Fast_Marching(narrow_band_width);

		Update_Cell_Types();
	}
	////enforce the surface tension jump condition for standard pressure projection
	virtual void Projection_P_Euler(const real dt)
	{
		current_dt=dt;
		velocity=impulse;
		projection.use_jump_condition=true;
		use_body_force=false;	////make sure to turn off the body force on jump condition

		projection.Allocate_System();
		projection.Update_A();
		Enforce_Boundary_Conditions(velocity);
		projection.Set_Velocity(velocity);
		projection.Update_b();	////calculate div of velocity
		projection.Apply_Jump_Condition_To_b();
		projection.Apply_Vol_Control_To_b();
		projection.Clear();
		projection.Solve();
		projection.Correction();
		Extrapolation(velocity);

		if(verbose_output){
			projection.Pressure(p);	////write solved pressure to p
			projection.Pressure_Gradient(grad_p);}
	}
	////apply body force on impulse. only used in Advance_Euler
	virtual void Apply_Body_Forces(const real dt)
	{
		for(int axis=0;axis<d;axis++){int face_num=mac_grid.Number_Of_Faces(axis);
			#pragma omp parallel for
			for(int i=0;i<face_num;i++){VectorDi face=mac_grid.Face_Coord(axis,i);
				VectorD pos=mac_grid.Face_Center(axis,face);
				if(Is_Fluid_Nb_Face(axis,face))
					impulse.face_fields[axis](face)+=g[axis]*dt;}}
	}

	virtual void Advance_Psi(const real dt,const real _time=0)
	{
		current_time=_time; 

		bool verbose_print=false;

		Timer<real> timer; timer.Reset(); 
		////advect psi
		Advection(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Advection:");
		if(normalize_after_advection) {Normalize(psi,psi);}

		////diffuse psi
		Diffusion(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Diffusion:");

		////psi to um(impulse)
		Psi_To_Impulse(); if(verbose_print)timer.Elapse_And_Output_And_Reset("Psi_To_Impulse:");
		
		////blend imp and vel
		Reinitialization(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Reinitialization:");

		////project Q on impulse and psi
		Projection_Q(dt); if(verbose_print)timer.Elapse_And_Output_And_Reset("Projection_Q:");		

		////incompressibility projection on velocity (and on psi if flag is on)
		Projection_P(); if(verbose_print)timer.Elapse_And_Output_And_Reset("Projection_P:");	
	}

	////TODO
	//virtual void Advance_Euler(const real dt,const real _time=0)
	//{
	//	current_time=_time; 
	//	
	//	FaceField<real,d> ghost_vel=velocity; ////[?] velocity advection not needed?
	//	Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity);
	//	impulse=velocity;
	//	Projection_P();			////velocity = impulse, then project P on velocity (and on psi if flag is on)
	//}

	//////////////////////////////////////////////////////////////////////////
	////extrapolation related
	virtual void Extrapolation(FaceField<real,d>& field_q)
	{
		Interpolation<d> intp(mac_grid);FaceField<real,d> ghost_field_q=field_q;

		////Fill ghost fields with fluid velocities
		for(int axis=0;axis<d;axis++){int face_num=mac_grid.Number_Of_Faces(axis);
			#pragma omp parallel for
			for(int i=0;i<face_num;i++){VectorDi face=mac_grid.Face_Coord(axis,i);
				if(Is_Fluid_Face(axis,face)||bc.Is_Psi_N(axis,face))continue;

				int n=0;real fluid_v=(real)0;
				for(int i=0;i<Grid<d>::Number_Of_Nb_C();i++){
					VectorDi nb_face=Grid<d>::Nb_C(face,i);
					if(!mac_grid.face_grids[axis].Valid_Node(nb_face))continue;
					if(Is_Fluid_Face(axis,nb_face)){fluid_v+=ghost_field_q(axis,nb_face);n++;}}
				if(n>0)ghost_field_q(axis,face)=fluid_v/(real)n;}}

		for(int axis=0;axis<d;axis++){int face_num=mac_grid.Number_Of_Faces(axis);
			#pragma omp parallel for
			for(int i=0;i<face_num;i++){VectorDi face=mac_grid.Face_Coord(axis,i);
				if(Is_Fluid_Face(axis,face)||bc.Is_Psi_N(axis,face))continue;

				VectorD pos=mac_grid.Face_Center(axis,face);real phi=levelset.Phi(pos);
				if(phi>(real)0){
					if(phi<narrow_band_width){
						VectorD interface_pos=levelset.Closest_Point(pos);
						field_q(axis,face)=intp.Interpolate_Faces(ghost_field_q,interface_pos,axis);}
					else field_q(axis,face)=(real)0;}}}
	}

	virtual void Extrapolation(Field<Vector4,d>& field_q)
	{
		////TODO
		Interpolation<d> intp_vel(mac_grid);
		Interpolation<d> intp_psi(mac_grid.grid);
		//Field<Vector4,d> ghost_field_q=field_q;

		////? update neigibors of boundary cells?

		int cell_num = mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for (int i = 0; i < cell_num; i++) {
			VectorDi cell = mac_grid.grid.Cell_Coord(i);
			if(Is_Fluid_Cell(cell))continue;
			VectorD pos = mac_grid.grid.Center(cell);
			real phi=levelset.Phi(pos);
			if (phi > (real)0) {
				if (phi < narrow_band_width) {
					real _eps = mac_grid.grid.dx; //narrow_band_width/2)
					VectorD interface_pos=levelset.Closest_Point(pos,_eps);
					VectorD interface_vel=intp_vel.Interpolate_Face_Vectors(velocity,interface_pos);
					Vector4 interface_psi=intp_psi.Interpolate_Centers(field_q,interface_pos);
					field_q(cell) = C2V(Vel_To_Psi_C<d>(interface_vel/h_bar,pos-interface_pos,interface_psi)); 
				}
				else {
					field_q(cell)=Vector4::Zero();
				}
			}
		}	
	}
	
	//////////////////////////////////////////////////////////////////////////
	//// advection
	virtual void Advection(const real dt)
	{
		Extrapolation(velocity);
		Extrapolation(psi);

		//////////////////////////////////////////////////////////////////////////
		////psi and vel advection, original code
		////advect psi
		if (use_semi_lagrangian_psi) {
			Semi_Lagrangian_Psi(psi,dt); }
		else {
			Field<Vector4,d> ghost_psi=psi;
			Advection::Semi_Lagrangian(dt,velocity,mac_grid,ghost_psi,mac_grid,psi); }
		//////advect vel. NOW WE NEED THIS!
		
		FaceField<real,d> ghost_vel=velocity;
		Advection::Semi_Lagrangian(dt,ghost_vel,mac_grid,ghost_vel,mac_grid,velocity,use_zero_extrapolation);

		////normalize psi for each cell. NOT normalizing at this moment.
		//////////////////////////////////////////////////////////////////////////

		////levelset advection
		Field<real,d> ghost_phi=levelset.phi;
		std::function<bool(const VectorDi&)> valid_cell=[&](const VectorDi& cell)->bool{return Is_Fluid_Nb_Cell(cell);};
		Advection::Semi_Lagrangian(dt,velocity,mac_grid,ghost_phi,mac_grid,levelset.phi,false,valid_cell);
		levelset.Fast_Marching(narrow_band_width);

		Update_Cell_Types();
	}

	void Semi_Lagrangian_Psi(Field<Vector4,d>& psi,const real dt)
	{
		Enforce_Boundary_Conditions(psi);

		Field<Vector4,d> ghost_psi=psi;
		Interpolation<d> intp(mac_grid.grid);
		int cell_num=mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			VectorDi cell=mac_grid.grid.Cell_Coord(i);
			if(Is_Source_Cell(cell)||Is_Solid_Cell(cell))continue;	////skip the source or solid cells
			if(!Is_Fluid_Nb_Cell(cell))continue;					////MODIFIED: skip non-fluid-nb cell

			VectorD pos=mac_grid.grid.Center(cell);
			VectorD vel=intp.Interpolate_Face_Vectors(velocity,pos);
			VectorD mid_pos=pos-vel*(real).5*dt;
			vel=intp.Interpolate_Face_Vectors(velocity,mid_pos);
			VectorD backtraced_pos=pos-vel*dt;
			Vector4 advected_psi;
			
			////if the backtraced point falls into the source, use the analytical source psi
			VectorDi backtraced_cell=mac_grid.grid.Cell_Coord(backtraced_pos);
			if(Is_Source_Cell(backtraced_cell)){
				advected_psi=Get_Source_Psi_By_Pos(backtraced_pos,current_time);}
			else if(Is_Solid_Cell(backtraced_cell)){advected_psi=psi(cell);}	////need a better treatment here
			else advected_psi=intp.Interpolate_Centers(ghost_psi,backtraced_pos);
			
			psi(cell)=advected_psi;}	

		Enforce_Boundary_Conditions(psi);
	}

	//////////////////////////////////////////////////////////////////////////
	//// reinitialization: using Base

	//////////////////////////////////////////////////////////////////////////
	//// boundary
	virtual void Enforce_Boundary_Conditions(Field<Vector4,d>& psi)
	{
		for(auto& pD:psi_D_psi_values){
			VectorDi cell=mac_grid.grid.Cell_Coord(pD.first);
			psi(cell)=Get_Source_Psi_By_Cell(cell,current_time);}
	}

	//////////////////////////////////////////////////////////////////////////
	//// psi -> m

	void Psi_To_Impulse() 
	{
		if(use_enforce_bc){
			Enforce_Boundary_Conditions(psi);
			Enforce_Boundary_Conditions(velocity);}

		Normalize(psi,psi2);	////use psi2 as the the normalized psi get velocity
		impulse=velocity;		////first copy vel to imp to setup the default bc values
		Grid_Psi_To_Grid_Vel(psi2,impulse);
	}

	void Grid_Psi_To_Grid_Vel(const Field<Vector4,d>& psi,FaceField<real,d>& imp)
	{
		switch (cal_impulse_option) {
		case 0: ////v=h_bar*arg<psi_0,psi_1>		////THE ONE BEING USED!
			for (int axis = 0; axis < d; axis++) {
				int face_num = mac_grid.face_grids[axis].Number_Of_Nodes();
				#pragma omp parallel for
				for(int i = 0; i < face_num; i++) {
					VectorDi face = mac_grid.face_grids[axis].Node_Coord(i);
					if(bc.Is_Psi_N(axis,face)) { continue; } 
					if(!Is_Fluid_Nb_Face(axis,face)){continue;}		////MODIFIED
					//if(!Is_Fluid_Face(axis,face)){continue;}		////MODIFIED
					const VectorDi cell_0 = mac_grid.Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1 = mac_grid.Face_Incident_Cell(axis,face,1);

					if (!Is_Fluid_Nb_Cell(cell_0) || !Is_Fluid_Nb_Cell(cell_1)) { continue; }

					Vector<C,2> psi_0 = V2C(psi(cell_0));
					Vector<C,2> psi_1 = V2C(psi(cell_1));
					C q = psi_0.dot(psi_1);
					imp(axis,face) = std::arg(q) * h_bar / mac_grid.grid.dx;}}

		case 1: ////v=h_bar*sum(ak*grad bk-bk*grad ak)	
			for (int axis = 0; axis < d; axis++) {
				int face_num = mac_grid.face_grids[axis].Number_Of_Nodes();
				#pragma omp parallel for
				for (int i = 0; i < face_num; i++) {
					VectorDi face = mac_grid.face_grids[axis].Node_Coord(i);
					if(bc.Is_Psi_N(axis,face)) { continue; } 
					if(!Is_Fluid_Nb_Face(axis,face)){continue;}		////MODIFIED
					//if(!Is_Fluid_Face(axis,face)){continue;}	
					const VectorDi cell_0 = mac_grid.Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1 = mac_grid.Face_Incident_Cell(axis,face,1);

					if (!Is_Fluid_Nb_Cell(cell_0) || !Is_Fluid_Nb_Cell(cell_1)) { continue; }

					////Bo: this part did not consider source.
					Vector<C,2> psi_0=V2C(psi(cell_0));
					Vector<C,2> psi_1=V2C(psi(cell_1));
					real u=(real)0;
					for(int j=0;j<2;j++){
						real a = (real).5*(psi_0[j].real()+psi_1[j].real());
						real grad_a = (psi_1[j].real()-psi_0[j].real())/mac_grid.grid.dx;
						real b = (real).5*(psi_0[j].imag()+psi_1[j].imag());
						real grad_b = (psi_1[j].imag()-psi_0[j].imag())/mac_grid.grid.dx;
						u += h_bar*(a*grad_b-b*grad_a);}

					imp(axis,face) = u; }}}
	}

	//////////////////////////////////////////////////////////////////////////
	//// diffusion: using Base

	//////////////////////////////////////////////////////////////////////////
	//// projection
	virtual void Update_Projection_Q_rhs(const real dt)
	{
		if(!use_nonzero_neumann_q_proj){
			Enforce_Boundary_Conditions(impulse);
			current_dt=dt;
			int b_size=(int)projection.matrix_to_grid.size();
			#pragma omp parallel for
			for(int r=0;r<b_size;r++){
				const VectorDi& cell=mac_grid.grid.Cell_Coord(projection.matrix_to_grid[r]);
				VectorD pos=mac_grid.grid.Center(cell);
				real div=(real)0;
				for(int axis=0;axis<d;axis++){div+=(impulse(axis,cell+VectorDi::Unit(axis))-impulse(axis,cell));}
				real solid_phi=solid_boundary_levelset.Phi(pos);
				real fluid_phi=levelset.Phi(pos);
				real phi=solid_phi<fluid_phi?solid_phi:fluid_phi;
				real delta=Delta(abs(phi),solid_boundary_nb_width);
				div*=delta;
				projection.div_u[r]=-div;}	////negative div here to solve -lap p=-div u
		}else{
			current_dt=dt;
			auto& b=projection.div_u;
			auto& A=projection.A;
			auto& grid_to_matrix=projection.grid_to_matrix;
			auto& bc=(*projection.bc);
			auto& vel=(*projection.velocity);	////projection.velocity is impulse in q projection
			real dx=mac_grid.grid.dx;
			b.fill((real)0);

			if(bc.acc_arrays_init){
				int psi_D_n=(int)bc.psi_D_key_array.size();
				//std::cout<<"parallel set Dirichlet boundary rhs: "<<psi_D_n<<std::endl;
				#pragma omp parallel for
				for(int i=0;i<psi_D_n;i++){
					int cell_index=bc.psi_D_key_array[i]; VectorDi face=mac_grid.grid.Cell_Coord(cell_index);
					const ushort pD_type=bc.psi_D_val_array[i].first;
					real val=bc.psi_D_val_array[i].second;
					////psi_D's rhs
					const VectorDi cell=mac_grid.grid.Cell_Coord(cell_index);
					////psi_D nbs' rhs
					for(int i=0;i<Grid<d>::Number_Of_Nb_C();i++){VectorDi nb_cell=Grid<d>::Nb_C(cell,i);
						if(mac_grid.grid.Valid_Cell(nb_cell)&&!bc.Is_Psi_D(nb_cell)){int r=grid_to_matrix(nb_cell);
							int axis=0;int side=0;mac_grid.grid.Nb_C_Axis_And_Side(i,axis,side);
							VectorDi face=cell+VectorDi::Unit(axis)*side;real a=alpha(axis,face);b[r]+=a*val/dx;}}}

				int psi_N_n=(int)bc.psi_N_key_array.size();
				//std::cout<<"parallel set Neumann boundary rhs: "<<psi_N_n<<std::endl;
				#pragma omp parallel for
				for(int i=0;i<psi_N_n;i++){int axis=bc.psi_N_key_array[i][0];
					int face_index=bc.psi_N_key_array[i][1]; VectorDi face=mac_grid.Face_Coord(axis,face_index);
					real value=bc.psi_N_val_array[i];
					const VectorDi cell_0=MacGrid<d>::Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1=MacGrid<d>::Face_Incident_Cell(axis,face,1);
					real psi_N_val=(vel(axis,face)-value);

					if(mac_grid.grid.Valid_Cell(cell_0)){
						int r0=grid_to_matrix(cell_0);
						if(r0!=-1)b[r0]+=psi_N_val;}
					if(mac_grid.grid.Valid_Cell(cell_1)){
						int r1=grid_to_matrix(cell_1);
						if(r1!=-1)b[r1]-=psi_N_val;}}
			}else{
				////set Dirichlet boundary rhs
				for(const auto& pD:bc.psi_D_values){const int cell_index=pD.first;
					const ushort pD_type=pD.second.first;
					const real val=pD.second.second;
					////psi_D's rhs
					const VectorDi cell=mac_grid.grid.Cell_Coord(cell_index);
					////psi_D nbs' rhs
					for(int i=0;i<Grid<d>::Number_Of_Nb_C();i++){VectorDi nb_cell=Grid<d>::Nb_C(cell,i);
						if(mac_grid.grid.Valid_Cell(nb_cell)&&!bc.Is_Psi_D(nb_cell)){int r=grid_to_matrix(nb_cell);
							int axis=0;int side=0;mac_grid.grid.Nb_C_Axis_And_Side(i,axis,side);
							VectorDi face=cell+VectorDi::Unit(axis)*side;real a=alpha(axis,face);b[r]+=a*val/dx;}}}

				////set Neumann boundary rhs
				for(const auto& pN:bc.psi_N_values){
					int axis=pN.first[0];VectorDi face=mac_grid.face_grids[axis].Node_Coord(pN.first[1]);real value=pN.second;
					const VectorDi cell_0=MacGrid<d>::Face_Incident_Cell(axis,face,0);
					const VectorDi cell_1=MacGrid<d>::Face_Incident_Cell(axis,face,1);
					real psi_N_val=(vel(axis,face)-value);
					if(mac_grid.grid.Valid_Cell(cell_0)){
						int r0=grid_to_matrix(cell_0);
						if(r0!=-1)b[r0]+=psi_N_val;}
					if(mac_grid.grid.Valid_Cell(cell_1)){
						int r1=grid_to_matrix(cell_1);
						if(r1!=-1)b[r1]-=psi_N_val;}}}}
	}

	virtual void Projection_Q(const real dt)
	{
		////previous code
		//if(!use_q_projection) {return;}

		//////solve q and projection on impulse
		//projection.Set_Velocity(impulse);
		//Update_Projection_Q_rhs(dt);
		//projection.Clear();
		//projection.Solve();
		////////apply dt: dt was absorbed in p. We don't need to apply it if we did not set its value for bc
		//projection.Correction();	////m-=dt*grad q
		//Enforce_Boundary_Conditions(impulse);
		//projection.Pressure(q);
		//////projection on psi
		//////psi = psi * exp(-i * q_hat / h_bar)
		//Projection_Psi(psi,q);


		if(!use_q_projection)return;

		projection.Allocate_System();
		projection.Update_A();
		projection.use_jump_condition=true;
		projection.Set_Velocity(impulse);
		Update_Projection_Q_rhs(dt);
		projection.Apply_Jump_Condition_To_b();
		projection.Clear();
		projection.Solve();
		projection.Correction();	////m-=dt*grad p
		
		Enforce_Boundary_Conditions(impulse);
		projection.Pressure(q);
		////projection on psi
		////psi = psi * exp(-i * q_hat / h_bar)
		Projection_Psi(psi,q);

		//if(verbose_output){
		//	projection.Pressure(q);	////write solved pressure to q
		//	projection.Pressure_Gradient(grad_q);}
	}

	virtual void Projection_P()
	{
		//////previous code
		//velocity=impulse;

		//Enforce_Boundary_Conditions(velocity);
		//projection.Set_Velocity(velocity);
		//projection.Update_b();	////calculate div of velocity
		//projection.Clear();
		//projection.Solve();
		//////project impulse
		//projection.Correction(); 
		//projection.Pressure(p);
		//////projection on psi  ////[?] need this?
		//if (projection_p_psi) {Projection_Psi(psi,p);}


		if(!use_q_projection){
			projection.Allocate_System();
			projection.Update_A();}

		projection.use_jump_condition=false;
		velocity=impulse;
		Enforce_Boundary_Conditions(velocity);
		projection.Set_Velocity(velocity);
		projection.Update_b();	////calculate div of velocity
		projection.Apply_Vol_Control_To_b();
		projection.Clear();
		projection.Solve();
		projection.Correction();
		projection.Pressure(p);
		////projection on psi  ////[?] need this?
		if (projection_p_psi) {Projection_Psi(psi,p,projection_psi_s_damp);}

		//if(verbose_output){
		//	projection.Pressure(p);	////write solved pressure to p
		//	projection.Pressure_Gradient(grad_p);}
	}

	void Projection_Psi(Field<Vector4,d>& psi,Field<real,d>& p,real s_damp=1.)
	{
		int cell_num = mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for (int i = 0; i < cell_num; i++) {
			VectorDi cell = mac_grid.grid.Cell_Coord(i);
			if(!Is_Fluid_Nb_Cell(cell))continue;		////MODIFIED

			C c = std::exp(-1i * p(cell)*mac_grid.grid.dx / (h_bar*s_damp));
			Vector<C,2> psi_c = V2C(psi(cell));
			for (int i = 0; i < 2; i++) { psi_c[i]*=c; }
			psi(cell)=C2V(psi_c);}
	}

	real Pressure_Jump_On_Free_Surface(const VectorD& pos) 
	{
		Interpolation<d> intp(mac_grid);
		real curvature=levelset.Curvature(pos);
		real jump=surface_tension*curvature/**(-pos[0]+(real)1)*/;
		if(use_body_force)jump+=(-g[1]*pos[1]);
		if(use_external_pressure_jump&&External_Pressure_Jump!=nullptr)jump+=External_Pressure_Jump(pos);
		return jump*current_dt;
	}

	//////////////////////////////////////////////////////////////////////////
	//// helper functions

	void Normalize(const Field<Vector4,d>& input,Field<Vector4,d>& output)
	{
		int cell_num = mac_grid.grid.Number_Of_Cells();
			#pragma omp parallel for
			for (int i = 0; i < cell_num; i++) {
				VectorDi cell = mac_grid.grid.Cell_Coord(i);
				if(!Is_Fluid_Nb_Cell(cell))continue;		////MODIFIED

				output(cell)=input(cell).normalized();}	
	}

	////cfl
	real CFL() const
	{
		if(use_fixed_dt) { return (real)1; }
		else {
			real epsilon=(real)1e-5;
			disp(Max_Abs(velocity));
			return mac_grid.grid.dx/(Max_Abs(velocity)+epsilon);}
	}

	//// source helpers
	//kvec = jet_velocity/isf.hbar;
	//omega = sum(jet_velocity.^2)/(2*isf.hbar); //why /2 ?
	//(init)phase = kvec(1).*isf.px + kvec(2).*isf.py + kvec(3).*isf.pz; (Vel_To_Psi_C(kvec,pos))
	//phase = kvec(1).*isf.px + kvec(2).*isf.py + kvec(3).*isf.pz -omega*t;
	//amp1 = abs(psi1);
    //psi1(isJet) = amp1(isJet).*exp(1i*phase(isJet));
	inline Vector4 Get_Source_Psi_By_Cell(const VectorDi& cell,const real time) 
	{
		int cell_idx=mac_grid.grid.Cell_Index(cell);
		////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
		Vector4 psi_v=psi_D_psi_values[cell_idx].first;
		Vector<C,2> psi=V2C(psi_v);
		real phase_u=psi_D_psi_values[cell_idx].second;
		for(int i=0;i<2;i++)psi[i]*=exp(-1i*phase_u*time);
		return C2V(psi);
	}

	inline Vector4 Get_Source_Psi_By_Pos(const VectorD& pos,const real time) 
	{
		Vector4 psi_v=initial_psi(pos);
		Vector<C,2> psi=V2C(psi_v);
		real phase_u=source_velocity.dot(source_velocity)/h_bar;
		for(int i=0;i<2;i++)psi[i]*=exp(-1i*phase_u*time);
		return C2V(psi);
	}

	//////////////////////////////////////////////////////////////////////////
	////helper functions copied from FluidEulerFreeSurface
	inline bool Is_Fluid_Interior_Cell(const VectorDi& cell) const 
	{return mac_grid.grid.Valid_Cell(cell)&&(type(cell)==(ushort)CellType::Fluid);}

	inline bool Is_Fluid_Interior_Cell_Index(const int cell_idx) const	////assuming index is always valid
	{return (type.array[cell_idx]==(ushort)CellType::Fluid);}

	inline bool Is_Fluid_Cell(const VectorDi& cell) const 
	{return mac_grid.grid.Valid_Cell(cell)&&(type(cell)==(ushort)CellType::Fluid||type(cell)==(ushort)CellType::BD);}

	inline bool Is_Fluid_Cell_Index(const int cell_idx) const	////assuming index is always valid
	{return (type.array[cell_idx]==(ushort)CellType::Fluid||type.array[cell_idx]==(ushort)CellType::BD);}

	inline bool Is_Fluid_Nb_Cell(const VectorDi& cell) const
	{return mac_grid.grid.Valid_Cell(cell)&&((type(cell)==(ushort)CellType::Fluid||type(cell)==(ushort)CellType::BD)||type(cell)==(ushort)CellType::NB);}

	inline bool Is_Fluid_Nb_Cell_Index(const int cell_idx) const 
	{return (type.array[cell_idx]==(ushort)CellType::Fluid||type.array[cell_idx]==(ushort)CellType::BD)||type.array[cell_idx]==(ushort)CellType::NB;}

	////a face is fluid if it is incident to a fluid cell
	inline bool Is_Fluid_Face(const int axis,const VectorDi& face) const
	{{VectorDi cell=MacGrid<d>::Face_Incident_Cell(axis,face,0);if(Is_Fluid_Cell(cell))return true;}
	{VectorDi cell=MacGrid<d>::Face_Incident_Cell(axis,face,1);if(Is_Fluid_Cell(cell))return true;}return false;}

	inline bool Is_Fluid_Nb_Face(const int axis,const VectorDi& face) const
	{{VectorDi cell=MacGrid<d>::Face_Incident_Cell(axis,face,0);if(Is_Fluid_Nb_Cell(cell))return true;}
	{VectorDi cell=MacGrid<d>::Face_Incident_Cell(axis,face,1);if(Is_Fluid_Nb_Cell(cell))return true;}return false;}

	inline bool Is_Air(const VectorD& pos) const {return levelset.Phi(pos)>=(real)0;}


	//// cell helpers
	//inline bool Is_Fluid_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Fluid;}	////use the base class one
	//inline bool Is_Solid_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Solid;}
	//inline bool Is_Source_Cell(const VectorDi& cell) const {return type(cell)==(ushort)CellType::Source;}

	inline bool Is_Solid_Cell(const VectorDi& cell) const
	{return type(cell)==(ushort)CellType::Solid;}

	inline bool Is_Solid_Cell_Index(const int cell_idx) const
	{return type.array[cell_idx]==(ushort)CellType::Solid;}

	////copied from FluidEulerFreeSurface
	virtual void Update_Cell_Types()
	{
		int cell_num=mac_grid.grid.Number_Of_Cells();
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			const VectorDi& cell=mac_grid.grid.Cell_Coord(i);
			if(bc.Is_Psi_D(cell))type.array[i]=(ushort)CellType::Solid;
			else if(levelset.phi.array[i]<(real)0)type.array[i]=(ushort)CellType::Fluid;
			else if(levelset.phi.array[i]<narrow_band_width)type.array[i]=(ushort)CellType::NB;
			else type.array[i]=(ushort)CellType::Air;}

		////update boundary cell types
		#pragma omp parallel for
		for(int i=0;i<cell_num;i++){
			////update BD cells
			if(type.array[i]==(ushort)CellType::Fluid){
				const VectorDi& cell=mac_grid.grid.Cell_Coord(i);
				for(int j=0;j<mac_grid.grid.Number_Of_Nb_C();j++){
					const VectorDi& nb=mac_grid.grid.Nb_C(cell,j);
					if(!mac_grid.grid.Valid_Cell(nb)||!(type(nb)==(ushort)CellType::Fluid||type(nb)==(ushort)CellType::BD)){
						type.array[i]=(ushort)CellType::BD;}}}}

		//////remove isolated air cells
		//#pragma omp parallel for
		//for(int i=0;i<cell_num;i++){
		//	if(type.array[i]==(ushort)CellType::NB||type.array[i]==(ushort)CellType::Air){
		//		const VectorDi& cell=mac_grid.grid.Cell_Coord(i);
		//		bool all_af=true;
		//		for(int j=0;j<mac_grid.grid.Number_Of_Nb_C();j++){
		//			const VectorDi& nb=mac_grid.grid.Nb_C(cell,j);
		//			if(mac_grid.grid.Valid_Cell(nb)&&
		//				(type(nb)!=(ushort)CellType::Fluid&&type(nb)!=(ushort)CellType::BD&&type(nb)!=(ushort)CellType::Solid)){
		//				all_af=false;break;}}
		//		if(all_af)type.array[i]=(ushort)CellType::BD;}}
	}

};