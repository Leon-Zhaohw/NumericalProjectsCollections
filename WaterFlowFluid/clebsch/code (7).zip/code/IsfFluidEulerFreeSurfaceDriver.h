//////////////////////////////////////////////////////////////////////////
// Euler fluid freesurface driver 
// Author: Anonymous authors
// This file is part of XXX, whose distribution is governed by the LICENSE file.
//////////////////////////////////////////////////////////////////////////
#pragma once

#include "Common.h"
#include "File.h"
#include "GeometryPrimitives.h"
#include "IsfFluidEulerFreeSurface.h"
#include "Particles.h"
#include "MarchingCubes.h"
#include "Driver.h"
#include "PrintHelpers.h"

template<int d> class IsfFluidEulerFreeSurfaceDriver : public Driver
{Typedef_VectorDii(d);using Base=Driver;
public:
	IsfFluidEulerFreeSurface<d> fluid;
	Array<std::shared_ptr<ImplicitGeometry<d> > > solid_boundary_primitives;
	bool verbose_output=true;
	std::string input_command = "";
	real input_alpha = -1.;
	real input_beta = -1.;

	void Set_Verbose(bool _verbose=true){verbose_output=_verbose;fluid.verbose_output=_verbose;}

	real CFL() const
	{
		return cfl*fluid.CFL();
		//real epsilon=(real)1e-5;
		//return cfl*fluid.mac_grid.grid.dx/(fluid.Max_Abs(fluid.velocity)+epsilon);
	}

	virtual void Advance_One_Time_Step(const real dt,const real time)
	{
		fluid.Advance(dt,time);
	}

	virtual void Write_Output_Files(const int frame)
	{	
		Base::Write_Output_Files(frame);
		if(frame==0){
			std::string file_name=frame_dir+"/grid";
			fluid.mac_grid.grid.Write_To_File_3d(file_name);
			std::cout<<"Write to file "<<file_name<<std::endl;
			std::string command_file=frame_dir+"/parameters";
			std::ofstream out_file(command_file);
			out_file<<"Command line input: \n" <<input_command<<"\n"<<std::endl;
			fluid.Print_Param(out_file);
			std::cout<<"Write the parameters to file "<<command_file<<std::endl;
		}
		
		////Write velocity
		{std::string file_name=frame_dir+"/velocity";
		fluid.velocity.Write_To_File_3d(file_name);}
		
		////Write psi
		{std::string file_name=frame_dir+"/psi";
		Field<Vector3,d> q(fluid.psi.counts,Vector3::Zero());
		for(int i=0;i<q.array.size();i++){
			AngleAxis a=AngleAxis(fluid.psi.array[i]);
			q.array[i]=a.axis()*a.angle();}
		q.Write_To_File_3d(file_name);}

		////Write BC
		if(frame==0||!fluid.use_static_solid)
		{std::string file_name=frame_dir+"/psi_D";
		Particles<d> particles;
		for(auto p:fluid.bc.psi_D_values){
			VectorDi cell=fluid.mac_grid.grid.Cell_Coord(p.first);
			VectorD pos=fluid.mac_grid.grid.Center(cell);
			int i=particles.Add_Element();particles.X(i)=pos;}
		particles.Write_To_File_3d(file_name);}

		//if(frame==0||!fluid.use_static_solid)
		{std::string file_name=frame_dir+"/psi_N";
		Particles<d> particles;
		for(auto p:fluid.bc.psi_N_values){int axis=p.first[0];
			VectorDi face=fluid.mac_grid.Face_Coord(axis,p.first[1]);
			VectorD pos=fluid.mac_grid.Face_Center(axis,face);
			int i=particles.Add_Element();particles.X(i)=pos;}
		File::Write_Binary_To_File(file_name,particles);
		particles.Write_To_File_3d(file_name);}

		MarchingCubes<d> marching_cubes(fluid.levelset);
		marching_cubes.Marching();
		if(d==2){
			std::string file_name=frame_dir+"/segment_mesh";
			(*marching_cubes.mesh).Write_To_File_3d(file_name);}
		else{
			std::string file_name=frame_dir+"/triangle_mesh";
			(*marching_cubes.mesh).Write_To_File_3d(file_name);}

		std::cout<<"Write to frame "<<frame;AuxFunc::Seperation_Line(2);
	}
	
	virtual void Initialize()
	{
		int s=scale;real length=(real)1;VectorDi cell_counts=VectorDi::Ones();cell_counts[0]=s;
		cell_counts[1]=cell_counts[0]/2;if(d>2)cell_counts[2]=cell_counts[0]/2;

		switch(test){
		case 1: {	////Droplet falling into water
			std::cout << "isf Droplet falling into water" << std::endl;
			
			cell_counts = VectorDi::Ones() * scale;
			fluid.Allocate_Data(cell_counts, (real)length / cell_counts[0]);
			fluid.use_body_force = true;
			frame_rate = 100;

			////Droplet
			VectorD center = fluid.mac_grid.grid.Center();
			center[1] = fluid.mac_grid.grid.domain_min[1] + fluid.mac_grid.grid.Length()[1] * (real).8;
			real r = fluid.mac_grid.grid.Length()[1] * (real).1;
			Sphere<d> sphere(center, r);
			//Box<d> sphere(center-VectorD::Ones()*r,center+VectorD::Ones()*r);

			////Water bulk
			Plane<d> plane(VectorD::Unit(1), fluid.mac_grid.grid.Center()/* - VectorD::Unit(1) * (real)1*/);
			////Initialize phi
			iterate_cell(iter, fluid.mac_grid.grid) {
				const VectorDi& cell = iter.Coord();
				VectorD pos = fluid.mac_grid.grid.Center(cell);
				fluid.levelset.phi(cell) = std::min(plane.Phi(pos), sphere.Phi(pos));}

			////Wall boundary
			for (int axis = 0; axis < d; axis++)iterate_face_in_one_dim(axis, iter, fluid.mac_grid) {
				const VectorDi& face = iter.Coord();
				if (face[axis] == 0 || face[axis] == fluid.mac_grid.face_grids[axis].node_counts[axis] - 1) {
					fluid.bc.Set_Psi_N(axis, face, (real)0);}}

			////initialize solid boundary phi
			NegativeBox<d> tank(fluid.mac_grid.grid.domain_min, fluid.mac_grid.grid.domain_max);
			solid_boundary_primitives.push_back(std::make_shared<NegativeBox<d> >(tank));		////source box
			fluid.Solid_Boundary_Phi = std::bind(&IsfFluidEulerFreeSurfaceDriver<d>::Solid_Boundary_Phi, this, std::placeholders::_1);

			////initialize droplet velocity, needs to be called after initializing narrow_band_width
			VectorD init_droplet_vel = VectorD::Unit(1) * (real)-2;
			iterate_face(axis, iter, fluid.mac_grid) {
				const VectorDi& face = iter.Coord();
				VectorD pos = fluid.mac_grid.Face_Center(axis, face);
				real phi = sphere.Phi(pos);
				if (phi < fluid.narrow_band_width)fluid.velocity(axis, face) = init_droplet_vel[axis];}

			////initialize isf related parameters
			fluid.h_bar = .1;
			fluid.projection_p_psi = true;
			fluid.projection_psi_s_damp = 1.;
			fluid.use_q_projection = true;
			//fluid.use_nonzero_neumann_q_proj = false;
			//fluid.use_enforce_bc=true;
			//fluid.use_psi_diffusion=false;
			//fluid.imp_dif_coef=(real).0;
			fluid.blend_coef=0.;
			fluid.normalize_after_advection = true;

			////initialize droplet and water bulk psi
			VectorD vel_h_bar = init_droplet_vel/fluid.h_bar; 
			fluid.initial_psi = [&](const VectorD& pos)->Vector4{
				Vector<C,2> psi;
				real phi = sphere.Phi(pos);
				if (phi < fluid.narrow_band_width) { //inside droplet or narrow band
					psi = Vel_To_Psi_C<d>(vel_h_bar,pos);
				} else { //// zero speed outside droplet
					psi = Vel_To_Psi_C<d>(VectorD::Zero(),pos);
				}
				return C2V(psi);	
			};

			fluid.Initialize();
			fluid.Initialize_Parameters_Default();
		}break;
		case 2: {	////Surface tension 
			std::cout << "isf Surface tension " << std::endl;
			
			cell_counts = VectorDi::Ones() * scale;
			fluid.Allocate_Data(cell_counts, (real)length / cell_counts[0]);
			fluid.use_body_force = false;
			frame_rate = 100;

			// droplet
			VectorD e_r = VectorD::Ones() * length * (real).3; e_r[1] *= (real).4;
			Ellipsoid<d> ellipsoid(fluid.mac_grid.grid.Center(), e_r);

			// water bulk (not needed

			// initialize phi
			iterate_cell(iter, fluid.mac_grid.grid) {
				const VectorDi& cell = iter.Coord();
				fluid.levelset.phi(cell) = ellipsoid.Phi(fluid.mac_grid.grid.Center(cell));
			}

			// initialize droplet velocity
			fluid.velocity.Fill(VectorD::Zero());

			// wall boundary (not needed

			// initialize solid boundary phi (not needed
			
			////initialize isf related parameters
			fluid.h_bar = .1;
			fluid.projection_p_psi = true;
			fluid.projection_psi_s_damp = 1.;
			fluid.use_q_projection = true;
			//fluid.use_nonzero_neumann_q_proj = false;
			//fluid.use_enforce_bc=true;
			//fluid.use_psi_diffusion=false;
			//fluid.imp_dif_coef=(real).0;
			fluid.blend_coef=0.;
			fluid.normalize_after_advection = true;

			////initialize droplet and water bulk psi 
			fluid.initial_psi = [&](const VectorD& pos)->Vector4{
				Vector<C,2> psi;
				psi = Vel_To_Psi_C<d>(VectorD::Zero(),pos); //zero speed
				return C2V(psi);	
			};

			fluid.Initialize();
			fluid.Initialize_Parameters_Default();
		}break;

		case 3: {	////Droplet falling to floor
			std::cout << "isf Droplet falling to floor" << std::endl;
			cell_counts=VectorDi::Ones()*scale;cell_counts[1]/=3;
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[0]);
			fluid.use_body_force=true;
			frame_rate=100;

			////Droplet
			VectorD center=fluid.mac_grid.grid.Center();
			center[1]=fluid.mac_grid.grid.domain_min[1]+length*(real).2;
			real r=length*(real).1;
			Sphere<d> sphere(center,r);
			//Box<d> sphere(center-VectorD::Ones()*r,center+VectorD::Ones()*r);

			////Water bulk
			////Initialize phi
			iterate_cell(iter,fluid.mac_grid.grid){const VectorDi& cell=iter.Coord();
				VectorD pos=fluid.mac_grid.grid.Center(cell);
				fluid.levelset.phi(cell)=sphere.Phi(pos);}

			////Wall boundary
			for(int axis=0;axis<d;axis++)iterate_face_in_one_dim(axis,iter,fluid.mac_grid){const VectorDi& face=iter.Coord();
				if(face[axis]==0||face[axis]==fluid.mac_grid.face_grids[axis].node_counts[axis]-1){
					fluid.bc.Set_Psi_N(axis,face,(real)0);}}
			
			////initialize solid boundary phi
			NegativeBox<d> tank(fluid.mac_grid.grid.domain_min,fluid.mac_grid.grid.domain_max);
			solid_boundary_primitives.push_back(std::make_shared<NegativeBox<d> >(tank));		////source box
			fluid.Solid_Boundary_Phi=std::bind(&IsfFluidEulerFreeSurfaceDriver<d>::Solid_Boundary_Phi,this,std::placeholders::_1);

			////initialize droplet velocity, needs to be called after initializing narrow_band_width
			VectorD init_droplet_vel=VectorD::Unit(1)*(real)-2;
			iterate_face(axis,iter,fluid.mac_grid){const VectorDi& face=iter.Coord();
				VectorD pos=fluid.mac_grid.Face_Center(axis,face);
				real phi=sphere.Phi(pos);
				if(phi<fluid.narrow_band_width)fluid.velocity(axis,face)=init_droplet_vel[axis];}

			////initialize isf related parameters
			fluid.h_bar = .1;
			fluid.projection_p_psi = true;
			fluid.projection_psi_s_damp = 1.;
			fluid.use_q_projection = true;
			fluid.use_nonzero_neumann_q_proj = false;
			//fluid.use_enforce_bc=true;
			//fluid.use_psi_diffusion=true;
			//fluid.imp_dif_coef=(real).01;
			fluid.blend_coef=.98;
			fluid.normalize_after_advection = false;
			if (input_alpha > 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta > 0) { fluid.blend_coef = 1. - input_beta; }

			////initialize droplet and water bulk psi
			VectorD vel_h_bar = init_droplet_vel/fluid.h_bar; 
			fluid.initial_psi = [&](const VectorD& pos)->Vector4{
				Vector<C,2> psi;
				real phi = sphere.Phi(pos);
				if (phi < fluid.narrow_band_width) { //inside droplet or narrow band
					psi = Vel_To_Psi_C<d>(vel_h_bar,pos);
				} else { //// zero speed outside droplet
					psi = Vel_To_Psi_C<d>(VectorD::Zero(),pos);
				}
				return C2V(psi);	
			};

			fluid.Initialize();
			fluid.Initialize_Parameters_Default();
		}break;

		case 4: {	////stream with obstacle
			std::cout << "isf Stream with obstacle" << std::endl;
			length *= 2;
			cell_counts=VectorDi::Ones()*scale; cell_counts[1]/=4; 
			if(d==3){cell_counts[2]/=2; }
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[0]);
			fluid.use_body_force=true;
			frame_rate=100;

			VectorD source_velocity=VectorD::Unit(0)*1.;
			fluid.source_velocity = source_velocity;
			real source_len = length * 0.025;
			real source_height = length * 0.025;
			real source_width = source_height*2.; 
			VectorD source_center = fluid.mac_grid.grid.Position(V<d>((real).0,(real).2,(real).5));
			auto in_source = [=](const VectorD& pos)->bool { 
				auto rx=pos-source_center;
				bool flag = ((pos[0]<source_len) && (rx[1]<source_height));
				//bool flag = ((pos[0]<source_len) && (abs(rx[1])<source_height));
				//if (d==3){flag = (flag & (abs(rx[2])<source_width));}
				return flag; 
			};

			////initialize isf related parameters
			fluid.h_bar = .1;
			fluid.projection_p_psi = true;
			fluid.projection_psi_s_damp = 10.;
			fluid.use_q_projection = true;
			fluid.use_nonzero_neumann_q_proj = false;
			//fluid.use_enforce_bc=true;
			//fluid.use_psi_diffusion=true;
			//fluid.imp_dif_coef=(real).01;
			fluid.blend_coef=.98; 
			fluid.normalize_after_advection = false;
			fluid.use_enforce_bc=true;
			if (input_alpha > 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta > 0) { fluid.blend_coef = 1. - input_beta; }

			////initialize psi
			VectorD vel_h_bar = source_velocity/fluid.h_bar; 
			fluid.initial_psi = [&](const VectorD& pos)->Vector4{
				Vector<C,2> psi;
				if (in_source(pos)) { //inside source
					psi = Vel_To_Psi_C<d>(vel_h_bar,pos);
				} else { //// ~zero speed outside source
					psi = Vel_To_Psi_C<d>(VectorD::Zero(),pos);
				}
				return C2V(psi);	
			};
			
			////ground
			{int axis=1;iterate_face_in_one_dim(axis,iter,fluid.mac_grid){
				const VectorDi& face=iter.Coord();
				if (face[axis]==0){fluid.bc.Set_Psi_N(axis,face,(real)0);}}}

			////wall
			if(d==3){
			{int axis=2;iterate_face_in_one_dim(axis,iter,fluid.mac_grid){
				const VectorDi& face=iter.Coord();
				if (face[axis]==0 || face[axis]==fluid.mac_grid.face_grids[axis].node_counts[axis]-1){fluid.bc.Set_Psi_N(axis,face,(real)0);}}}}

			////source wall 
			{int axis=0;iterate_face_in_one_dim(axis, iter, fluid.mac_grid) {
				const VectorDi& face = iter.Coord();
				const VectorD& pos=fluid.mac_grid.Face_Center(axis,face); 
				if (face[axis] == 0 && !in_source(pos)) {
					fluid.bc.Set_Psi_N(axis, face, 0);}}}

			////source boundary
			iterate_cell(iter,fluid.mac_grid.grid){
				const VectorDi& cell=iter.Coord();
				const VectorD& pos=fluid.mac_grid.grid.Center(cell); 
				if(in_source(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Source);  
					//psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] 
						= std::make_pair(fluid.initial_psi(pos), source_velocity.dot(source_velocity)/fluid.h_bar);		////TO CHECK
					for(int axis=0;axis<d;axis++)
						for(int side=0;side<2;side++) {
							VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
							fluid.bc.Set_Psi_N(axis,face,source_velocity[axis]);
							fluid.velocity(axis,face) = source_velocity[axis];}}}

			////obstacle
			VectorD ob_center=fluid.mac_grid.grid.Position(V<d>((real).4,(real).5,(real).5));real ob_r=(real).08*length;
			if (d==3) {ob_center[1]=ob_r; }
			Sphere<d> obstacle(ob_center,ob_r);
			iterate_cell(iter,fluid.mac_grid.grid){const VectorDi& cell=iter.Coord();const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(obstacle.Inside(pos)){fluid.bc.Set_Psi_D(cell,(ushort)CellType::Solid);
					for(int axis=0;axis<d;axis++)for(int side=0;side<2;side++){VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);fluid.bc.Set_Psi_N(axis,face,(real)0);}}}

			////initialize solid boundary phi
			NegativeBox<d> tank(fluid.mac_grid.grid.domain_min, fluid.mac_grid.grid.domain_max);
			solid_boundary_primitives.push_back(std::make_shared<NegativeBox<d> >(tank));		////source box
			solid_boundary_primitives.push_back(std::make_shared<Sphere<d> >(obstacle));		////sphere obstacle

			fluid.Solid_Boundary_Phi = std::bind(&IsfFluidEulerFreeSurfaceDriver<d>::Solid_Boundary_Phi, this, std::placeholders::_1);

			////Water bulk
			Plane<d> plane(VectorD::Unit(1), fluid.mac_grid.grid.Center()*0.8 /*- VectorD::Unit(1) * (real)1*/);
			fluid.stream_axis=0;
			fluid.stream_phi=fluid.mac_grid.grid.Center()[1];

			////Initialize phi
			iterate_cell(iter, fluid.mac_grid.grid) {
				const VectorDi& cell = iter.Coord();
				VectorD pos = fluid.mac_grid.grid.Center(cell);
				fluid.levelset.phi(cell) = plane.Phi(pos);
				fluid.levelset.phi(cell)=std::max(-fluid.Solid_Boundary_Phi(pos),fluid.levelset.phi(cell));}
			fluid.levelset.Fast_Marching();

			fluid.Initialize();
			fluid.Initialize_Parameters_Stream();

		}break;

		case 5: {	////stream with multiple obstacles
			std::cout << "isf Stream with multiple obstacles" << std::endl;
			length *= 2;
			cell_counts=VectorDi::Ones()*scale; cell_counts[1]/=4; cell_counts[1]*=1.5; 
			if(d==3){cell_counts[2]/=2; cell_counts[2]*=1.5; }
			print(cell_counts.transpose());
			fluid.Allocate_Data(cell_counts,(real)length/cell_counts[0]);
			fluid.use_body_force=true;
			frame_rate=100;

			VectorD source_velocity=VectorD::Unit(0)*1.;
			fluid.source_velocity = source_velocity;
			real source_len = length * 0.025;
			real source_height = length * 0.02;
			real source_width = source_height*2.; 
			VectorD source_center = fluid.mac_grid.grid.Position(V<d>((real).0,(real).2,(real).5));
			auto in_source = [=](const VectorD& pos)->bool { 
				auto rx=pos-source_center;
				bool flag = ((pos[0]<source_len) && (rx[1]<source_height));
				//bool flag = ((pos[0]<source_len) && (abs(rx[1])<source_height));
				//if (d==3){flag = (flag & (abs(rx[2])<source_width));}
				return flag; 
			};

			////initialize isf related parameters
			fluid.h_bar = .1;
			fluid.projection_p_psi = true;
			fluid.projection_psi_s_damp = 10.;
			fluid.use_q_projection = true;
			fluid.use_nonzero_neumann_q_proj = false;
			//fluid.use_enforce_bc=true;
			//fluid.use_psi_diffusion=true;
			//fluid.imp_dif_coef=(real).01;
			fluid.blend_coef=.98; 
			fluid.normalize_after_advection = false;
			fluid.use_enforce_bc=true;
			if (input_alpha > 0) { fluid.projection_psi_s_damp = 1./ input_alpha; }
			if (input_beta > 0) { fluid.blend_coef = 1. - input_beta; }

			////initialize psi
			VectorD vel_h_bar = source_velocity/fluid.h_bar; 
			fluid.initial_psi = [&](const VectorD& pos)->Vector4{
				Vector<C,2> psi;
				if (in_source(pos)) { //inside source
					psi = Vel_To_Psi_C<d>(vel_h_bar,pos);
				} else { //// ~zero speed outside source
					psi = Vel_To_Psi_C<d>(VectorD::Zero(),pos);
				}
				return C2V(psi);	
			};
			
			////ground
			{int axis=1;iterate_face_in_one_dim(axis,iter,fluid.mac_grid){
				const VectorDi& face=iter.Coord();
				if (face[axis]==0){fluid.bc.Set_Psi_N(axis,face,(real)0);}}}

			////wall
			if(d==3){
			{int axis=2;iterate_face_in_one_dim(axis,iter,fluid.mac_grid){
				const VectorDi& face=iter.Coord();
				if (face[axis]==0 || face[axis]==fluid.mac_grid.face_grids[axis].node_counts[axis]-1){fluid.bc.Set_Psi_N(axis,face,(real)0);}}}}

			////source wall 
			{int axis=0;iterate_face_in_one_dim(axis, iter, fluid.mac_grid) {
				const VectorDi& face = iter.Coord();
				const VectorD& pos=fluid.mac_grid.Face_Center(axis,face); 
				if (face[axis] == 0 && !in_source(pos)) {
					fluid.bc.Set_Psi_N(axis, face, 0);}}}

			////source boundary
			iterate_cell(iter,fluid.mac_grid.grid){
				const VectorDi& cell=iter.Coord();
				const VectorD& pos=fluid.mac_grid.grid.Center(cell); 
				if(in_source(pos)) {
					fluid.bc.Set_Psi_D(cell,(ushort)CellType::Source);  
					//psi_D_psi_values;	////cell_idx -> (psi_init,phase_speed(v^2/h_bar))
					fluid.psi_D_psi_values[fluid.mac_grid.grid.Cell_Index(cell)] 
						= std::make_pair(fluid.initial_psi(pos), source_velocity.dot(source_velocity)/fluid.h_bar);		////TO CHECK
					for(int axis=0;axis<d;axis++)
						for(int side=0;side<2;side++) {
							VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);
							fluid.bc.Set_Psi_N(axis,face,source_velocity[axis]);
							fluid.velocity(axis,face) = source_velocity[axis];}}}

			////obstacle
			std::vector<real> ob_size = {1.,.8,.8,.8,1.25,.8}; 
			for(int i=0;i<ob_size.size();i++){ob_size[i]/=10;}
			std::vector<VectorD> ob_centers = {
				fluid.mac_grid.grid.Position(V<d>((real).3,(real).0,(real).35)),
				fluid.mac_grid.grid.Position(V<d>((real).4,(real).0,(real).65)),
				fluid.mac_grid.grid.Position(V<d>((real).6,(real).0,(real).6)),
				fluid.mac_grid.grid.Position(V<d>((real).5,(real).0,(real).325)),
				fluid.mac_grid.grid.Position(V<d>((real).75,(real).0,(real).3)),
				fluid.mac_grid.grid.Position(V<d>((real).8,(real).0,(real).7))
			};
			if (d==3) {
			for (int i = 0; i < ob_size.size(); i++) {
				ob_centers[i][1] = ob_size[i];
			}}
			std::function<bool(const VectorD& pos)> in_obstacle = [&](const VectorD& pos)->bool{
				for (int i = 0; i < ob_size.size(); i++) {
					VectorD dx = ob_centers[i] - pos;
					if (d != 3) { print("This setting only works for 3d!!!"); }
					real dis = std::sqrt(dx[0]*dx[0]+dx[2]*dx[2]);
					if (i%2 == 0) { 
						dis = std::sqrt(dis*dis + dx[1]*dx[1]); 
						if (dis <= ob_size[i]) { return true; }
					}  //sphere && 3d 
					else { 
						if (dis <= ob_size[i] /*&& pos[2] < length/2.*/) {return true;}
					} 
				} 
				return false; };	
			iterate_cell(iter,fluid.mac_grid.grid){const VectorDi& cell=iter.Coord();const VectorD& pos=fluid.mac_grid.grid.Center(cell);
				if(in_obstacle(pos)){fluid.bc.Set_Psi_D(cell,(ushort)CellType::Solid);
					for(int axis=0;axis<d;axis++)for(int side=0;side<2;side++){VectorDi face=fluid.mac_grid.Cell_Incident_Face(axis,cell,side);fluid.bc.Set_Psi_N(axis,face,(real)0);}}}

			////initialize solid boundary phi
			NegativeBox<d> tank(fluid.mac_grid.grid.domain_min, fluid.mac_grid.grid.domain_max);
			solid_boundary_primitives.push_back(std::make_shared<NegativeBox<d> >(tank));		////source box
			//solid_boundary_primitives.push_back(std::make_shared<Sphere<d> >(obstacle));		////sphere obstacle

			fluid.Solid_Boundary_Phi = std::bind(&IsfFluidEulerFreeSurfaceDriver<d>::Solid_Boundary_Phi, this, std::placeholders::_1);

			////Water bulk
			Plane<d> plane(VectorD::Unit(1), fluid.mac_grid.grid.Center()*0.6 /*- VectorD::Unit(1) * (real)1*/);
			fluid.stream_axis=0;
			fluid.stream_phi=fluid.mac_grid.grid.Center()[1];

			////Initialize phi
			iterate_cell(iter, fluid.mac_grid.grid) {
				const VectorDi& cell = iter.Coord();
				VectorD pos = fluid.mac_grid.grid.Center(cell);
				fluid.levelset.phi(cell) = plane.Phi(pos);
				fluid.levelset.phi(cell)=std::max(-fluid.Solid_Boundary_Phi(pos),fluid.levelset.phi(cell));}
			fluid.levelset.Fast_Marching();

			fluid.Initialize();
			fluid.Initialize_Parameters_Stream();

		}break;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	////solid boundary
	real Solid_Boundary_Phi(const VectorD& pos)
	{
		real phi=(real)FLT_MAX;
		for(auto& obj:solid_boundary_primitives){
			real p0=obj->Phi(pos);if(p0<phi)phi=p0;}
		return phi;
	}

	//// Not tested
	void Resume() {
		std::string current_frame_s;
		File::Read_Text_From_File(output_dir + "/" + std::to_string(0) + "/last_frame.txt", current_frame_s);
		current_frame = std::stoi(current_frame_s);
		std::cout << "Proceed from frame: " << current_frame << std::endl;

		try {
			{std::string file_name = output_dir + "/current_velocity_f";
			fluid.velocity.Read_Binary(file_name); }
			{std::string file_name = output_dir + "/current_impulse_f";
			fluid.impulse.Read_Binary(file_name); }
		}
		catch (const std::exception&) {
			std::cerr << "Not read in face velocity or impulse successfully." << std::endl;
		}
	}
};
