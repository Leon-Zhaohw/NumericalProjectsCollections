//////////////////////////////////////////////////////////////////////////
// Helper functions for printing.
// Author: Anonymous authors
// This file is part of XXX, whose distribution is governed by the LICENSE file.
//////////////////////////////////////////////////////////////////////////

#pragma once

#include <iostream>
#include <functional>
#include <vector>
#include <string>
#include <unordered_map>
#include <tuple>
#include <any>

//////////////////////////////////////////////////////////////////////////
////cout helpers used for debug
template<class T> void print(const T& t) { std::cout << t << std::endl; }
template<class T, class... Args> void print(const T& t, const Args&... r) { std::cout << t << "\t"; print(r...); }
#define disp(a) print(#a, a);
#define disp_once(a) {static bool flag__DISPLAY__ = true; if(flag__DISPLAY__){print(#a, a);} flag__DISPLAY__ = false;} 
#define disp_multiple(a, b) {static int cnt__DISPLAY__ = 0; if(cnt__DISPLAY__ < b){print(#a, a);} cnt__DISPLAY__ ++;} 
#define disp_every_n(a, b) {static long long cnt__DISPLAY__ = 0; if(cnt__DISPLAY__ % b == 0) {print(#a, a);} cnt__DISPLAY__ ++;} 
/* Example:
    int test = 10001; print(test); print(test, test); disp(test); // output: test 10001 \n 
    for (int i = 0; i < test; i++) { disp_once(i); }  // output: i 0 \n
    for (int i = 0; i < test; i++) { disp_multiple(i, 10); }  // output: i 0 \n i 1 \n i 2 \n i 3 \n... i 9 \n
    for (int i = 0; i < test; i++) { disp_every_n(i, 500); }  // output: i 0 \n i 500 \n i 1000 \n i 1500 \n ... i 10000 \n
*/

//////////////////////////////////////////////////////////////////////////
////a helper class for printing parameters
class PrintParamHelpers {
public:
    std::vector<std::pair<std::string, const int*>> int_para_table;
    std::vector<std::pair<std::string, const float*>> float_para_table;
    std::vector<std::pair<std::string, const double*>> double_para_table;
    std::vector<std::pair<std::string, const bool*>> bool_para_table;

    void Add_Params_(const std::string & para_name, const int & param) {
        int_para_table.emplace_back(para_name, &param);
    }
    void Add_Params_(const std::string & para_name, const float & param) {
        float_para_table.emplace_back(para_name, &param);
    }
    void Add_Params_(const std::string & para_name, const double & param) {
        double_para_table.emplace_back(para_name, &param);
    }
    void Add_Params_(const std::string & para_name, const bool & param) {
        bool_para_table.emplace_back(para_name, &param);
    }
    template<class T> 
    void Add_Params(const std::string & name, const T & param) {
        Add_Params_(name, param);
    }
    template<class T, class... Args> 
    void Add_Params(const std::string & name, const T & param, const Args&... r) {
        Add_Params(name, param); Add_Params(r...); 
    }
    template<class T>
    void Print_One_Table(std::ostream& out, const std::vector<std::pair<std::string, T*>> & table) {
        for (const auto & a: table) {
            out << a.first << " \t" << typeid(T).name() << " \t" << *(a.second) << std::endl;
        }
    }
    void Print_Param(std::ostream& out) {
        out << std::boolalpha;
        Print_One_Table(out, bool_para_table);
        Print_One_Table(out, int_para_table);
        Print_One_Table(out, float_para_table);
        Print_One_Table(out, double_para_table);
    }  
#define __Add_Param(a) Add_Params(#a, a)
#define __Get_Name(a) (std::string(#a))
#define __Param(a) std::string(#a), a
#define __Declare_PrintParamHelpers using PrintParamHelpers::Add_Params; using PrintParamHelpers::Print_Param;
};
/* Example:
class TestClass: public PrintParamHelpers {
public:
    __Declare_PrintParamHelpers
    const int a = 1; int b = 100; double c = 1000.0; float d = 10.0; bool e = false; const double f = -1.0; 
    void Initialize () {
        __Add_Param(a); __Add_Param(b); ...  //or,
        Add_Params(__Param(a), __Param(b), __Param(c), __Param(d), __Param(e), __Param(f));
        c = -3; b = -999;  // will print out the modified values
    }
};
.......
TestClass test; test.Initialize(); test.Print_Param(std::cout);
*/