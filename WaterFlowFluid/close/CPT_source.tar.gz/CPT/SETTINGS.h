#ifndef SETTINGS_H
#define SETTINGS_H

#include <cassert>
#define Real float
#define SINGLE_PRECISION 1

#include "TIMER.h"

#ifndef NDEBUG
#define NDEBUG
#endif

#endif
