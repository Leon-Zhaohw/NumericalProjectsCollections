#include "StdAfx.h"
#include "StateSalad.h"
#include "Core.h"
#include <iterator>
#include <KLIB/GLSLNoise.h>

using namespace std;
using namespace KLIB;


namespace {
Core& core = Core::getInstance();
OGL& ogl = core.ogl_;
Salad& salad = core.salad_;
bool isAutoRotate_ = false;
}

void StateSalad::initialize() {
    salad.pieces_.clear();
    salad.silRenderer_.clear();
    currentPieceID_ = 0;
    glEnable(GL_DEPTH_TEST);
    glLineWidth(1);
}

void StateSalad::draw() {
    if (onDrawCompute_) {
        salad.updateSilhouette();
        onDrawCompute_ = false;
    }

    glPushAttrib(GL_ENABLE_BIT);
    glEnable(GL_NORMALIZE);
    
    // enable shader
    core.noiseShader_.enable();
    core.noiseShader_.setUniform1f("u_time", 0.0f);
    core.noiseShader_.setUniform1i("u_flagNoise", showNoise_);
    GLSLNoise::bindPermTexture(core.noiseShader_, 0);
    GLSLNoise::bindGradTexture(core.noiseShader_, 1);
    core.noiseShader_.setUniform1i("u_texWeight0", 2);
    core.noiseShader_.setUniform1i("u_texWeight1", 3);
    
    for (int i = 0; i < int(salad.pieces_.size()); ++i) {
        Piece& piece = salad.pieces_[i];
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_3D, piece.noiseWeight_.texID_[0]);
        glActiveTexture(GL_TEXTURE3);
        glBindTexture(GL_TEXTURE_3D, piece.noiseWeight_.texID_[1]);
        // transformation
	    glPushMatrix();
	    piece.t_.call_gl();
        // draw mesh3s
        for (size_t meshid = 0; meshid < piece.mesh3s_.size(); ++meshid) {
            Mesh3& mesh3 = piece.mesh3s_[meshid];
            if (showFaceEdge_ % 2) {
                core.noiseShader_.setUniform1i("u_flagLighting", 1);
                Drawer::draw_mesh_twosided(mesh3);
            }
            if (showFaceEdge_ / 2) {
                if (i == currentPieceID_)
                    glColor3d(1, 0, 0);
                else
                    glColor3d(0, 0, 0);
                core.noiseShader_.setUniform1i("u_flagLighting", 0);
                Drawer::draw_mesh_edge(mesh3);
            }
        }
        // draw mesh2
        if (showFaceEdge_ % 2) {
            core.noiseShader_.setUniform1i("u_flagLighting", 1);
            Drawer::draw_mesh_colored(piece.mesh2_);
        }
        if (showFaceEdge_ / 2) {
            if (i == currentPieceID_)
                glColor3d(1, 0, 0);
            else
                glColor3d(0, 0, 0);
            core.noiseShader_.setUniform1i("u_flagLighting", 0);
            Drawer::draw_mesh_edge(piece.mesh2_);
        }
	    glPopMatrix();
    }
    
    // disable noise shader
    glBindTexture(GL_TEXTURE_3D, 0);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_3D, 0);
    glActiveTexture(GL_TEXTURE0);
    GLSLNoise::unbindTexture(0);
    GLSLNoise::unbindTexture(1);
    core.noiseShader_.disable();
    
    if (showSilhouette_)
        salad.silRenderer_.gl_draw();

    glPopAttrib();
}
void StateSalad::OnLButtonDown(UINT nFlags, CPoint& point) {
    pointOld_ = point;
}
void StateSalad::OnLButtonUp  (UINT nFlags, CPoint& point) {
}
void StateSalad::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateSalad::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateSalad::OnMouseMove  (UINT nFlags, CPoint& point) {
    if (core.eventHandler_.isLButtonDown_) {
        Transform& t = salad.pieces_[currentPieceID_].t_;
        int width  = ogl.getWidth ();
        int height = ogl.getHeight();
        bool isShiftDown   = (nFlags & MK_SHIFT  ) != 0;
        bool isControlDown = (nFlags & MK_CONTROL) != 0;
        if (!isControlDown) {             // translate
            Vector3d start, ori;
            ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
            if (!isShiftDown) {  // along zx-plane
                /*
                (start + d * ori).y = t.translate_.y
                d = (t.translate_.y -start.y) / ori.y
                */
                double d = (t.translate_[1] - start[1]) / ori[1];
                Vector3d v = start + d * ori;
                t.translate_[0] = v[0];
                t.translate_[2] = v[2];
            } else {            // along y-axis
                /*
                start + d1 * ori = (t.translate_[0], 0, t.translate_[2]) + d2 * (0, 1, 0)
                */
                Vector3d yaxis0 = Vector3d(t.translate_[0], 0, t.translate_[2]);
                Vector3d yaxis1 = Vector3d(t.translate_[0], 1, t.translate_[2]);
                Vector2d baryCoordV, baryCoordW;
                Util::calcIntersectionLineLine(start, start + ori, yaxis0, yaxis1, baryCoordV, baryCoordW);
                t.translate_[1] = baryCoordW[1];
            }
        } else if (!isShiftDown) {    // rotate
            double thetaX = 2 * M_PI * (point.x - pointOld_.x) / width;
            double thetaY = 2 * M_PI * (point.y - pointOld_.y) / height;

            // Horizontal rotation
            Matrix4x4d mat_hrz = Matrix4x4d::rotationFromAxisAngle(ogl.viewParam_.upDirection_, -thetaX);

            // Vertical rotation
            Vector3d eye = ogl.viewParam_.eyePoint_ - ogl.viewParam_.focusPoint_;  // vector from focus to eye
            Vector3d leftDirection = eye % ogl.viewParam_.upDirection_;
            leftDirection = mat_hrz.transform(leftDirection);
            Matrix4x4d mat_vrt = Matrix4x4d::rotationFromAxisAngle(leftDirection, thetaY);
            
            t.rotate_  = t.rotate_ * mat_hrz * mat_vrt;
            t.rotateT_ = t.rotate_.transpose();
        } else {                                    // scale
            t.scale_ *= 1 + (pointOld_.y - point.y) / (double)height;
        }
        pointOld_ = point;
        ogl.RedrawWindow();
    } else if (core.eventHandler_.isRButtonDown_) {
        if (showSilhouette_)
            onDrawCompute_ = true;
        core.eventHandler_.default_OnMouseMove(nFlags, point);
    }
}
void StateSalad::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    switch (nChar) {
    case 'Q':
        if (!showSilhouette_)
            onDrawCompute_ = true;
    case 'W':
        {
            bool& flag = nChar == 'Q' ? showSilhouette_ : showNoise_;
            flag = !flag;
            ogl.RedrawWindow();
        }
        break;
    case 'E':
        showFaceEdge_ = showFaceEdge_ % 3 + 1;
        ogl.RedrawWindow();
        break;
    case ' ':
        currentPieceID_ = (currentPieceID_ + 1) % salad.pieces_.size();
        ogl.RedrawWindow();
        break;
    case VK_DELETE:
        if (salad.pieces_.empty())
            return;
        salad.pieces_.pop_back();
        if (currentPieceID_ == salad.pieces_.size())
            currentPieceID_ = 0;
        if (!salad.pieces_.empty() & showSilhouette_)
            onDrawCompute_ = true;
        ogl.RedrawWindow();
        break;
    case VK_ESCAPE:
        initialize();
        ogl.RedrawWindow();
        break;
    case 'S':   // save as *.scene file
        {
            CFileDialog dlg(FALSE, "scene", "*.scene", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "scene files|*.scene||");
            if (dlg.DoModal() != IDOK)
                return;
            salad.save(dlg.GetPathName());
        }
        break;
    }
}
void StateSalad::OnDropFiles  (const std::string& fname, const std::string& ext) {
    if (ext == "piece") {
        Piece piece;
        if (piece.load(fname.c_str())) {
            salad.pieces_.push_back(piece);
            copy(piece.curves_.begin(), piece.curves_.end(), back_inserter(salad.silRenderer_.curves3d_fixed_));
            currentPieceID_ = salad.pieces_.size() - 1;
        }
    } else if (ext == "obj") {
        Piece piece;
        if (piece.loadDish(fname.c_str())) {
            salad.pieces_.push_back(piece);
            currentPieceID_ = salad.pieces_.size() - 1;
        }
    } else if (ext == "scene") {
        salad.load(fname.c_str());
        if (!salad.pieces_.empty())
            currentPieceID_ = 0;
    }
    ogl.RedrawWindow();
}

StateSalad::StateSalad(void)
    : showSilhouette_(false)
    , showNoise_(false)
    , showFaceEdge_(3)
    , onDrawCompute_(false)
    , currentPieceID_ (0)
{}
