#pragma once


class CDiffusionSurfacesDoc : public CDocument
{
protected:
	CDiffusionSurfacesDoc();
	DECLARE_DYNCREATE(CDiffusionSurfacesDoc)
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

	virtual ~CDiffusionSurfacesDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

protected:
	DECLARE_MESSAGE_MAP()
};


