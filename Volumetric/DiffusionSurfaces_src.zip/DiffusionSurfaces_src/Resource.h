//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DiffusionSurfaces.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DiffusionSurfacTYPE         129
#define IDR_TOOLBAR_STEP                136
#define IDC_BTN_GEOMETRY_DELETEFACE     1008
#define IDC_CHK_INFO_INOUT2             1033
#define ID_MODE_MODELING                32772
#define ID_MODE_BROWSING                32773
#define ID_NAVIGATION_NEXT              32774
#define ID_NAVIGATION_HOME              32775
#define ID_VIEW                         32779
#define ID_VIEW_STEP                    32780
#define ID_VIEW_MAINPANEL               32781
#define ID_VIEW_GEOMETRY                32782
#define ID_VIEW_COLOR                   32783
#define ID_VIEW_CSPLANE                 32784
#define ID_STEP_NEXT                    32785
#define ID_STEP_BACK                    32786
#define ID_TOOLBAR_MODE                 32791
#define ID_TOOLBAR_DIALOG               32792
#define ID_TOOLBAR_STEP                 32793
#define ID_STEP_HOME                    32796
#define ID_MODE_SALAD                   32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
