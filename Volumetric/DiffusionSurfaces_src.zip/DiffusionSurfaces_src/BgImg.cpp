#include "stdafx.h"
#include <stb_image.h>
#include <vector>
#include "BgImg.h"
#include "Core.h"
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

void BgImg::gl_init() {
    tex_.init();
}
void BgImg::gl_deinit() {
    tex_.deinit();
}
void BgImg::load() {
    int width = 0, height = 0, numChannel = 0;
    unsigned char *data = stbi_load(fname_.c_str(), &width, &height, &numChannel, 0);
    if (data == 0) {
        cout << "Couldn't load image file: " << fname_ << endl;
        fname_.clear();
        return;
    }
    vector<unsigned char> data2(numChannel * width * height, 0);    // flip vertically
    for (int i = 0; i < height; ++i)
        memcpy(&data2[numChannel * width * (height - 1 - i)], &data[numChannel * width * i], numChannel * width);
    stbi_image_free(data);
    
    ogl.makeOpenGLCurrent();
    tex_.bind();
    GLuint format = numChannel == 1 ? GL_LUMINANCE : numChannel == 3 ? GL_RGB : numChannel == 4 ? GL_RGBA : 0;
    tex_.allocate(format, width, height, format, GL_UNSIGNED_BYTE, &data2[0]);
    tex_.unbind();
    
    double wh = 0.5 * (width + height);
    double w = width  / wh;
    double h = height / wh;
    cornerBL_.set(-w, -h);
    cornerBR_.set( w, -h);
    cornerTL_.set(-w,  h);
    cornerTR_.set( w,  h);
}
