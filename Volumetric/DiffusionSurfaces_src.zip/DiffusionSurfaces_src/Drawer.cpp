#include "StdAfx.h"
#include "Core.h"
#include "DiffusionSurfacesView.h"
#include "Drawer.h"
#include <vector>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
}

Drawer::Drawer(void) {
}

Drawer::~Drawer(void) {
}

void Drawer::init() {
    //core.ogl_.clearColor_[0] = core.ogl_.clearColor_[1] = core.ogl_.clearColor_[2] = 0.75f;
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glPointSize(10);
    glLineWidth(5);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint(GL_LINE_SMOOTH_HINT , GL_NICEST);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0, 1.0);
    GLint tmp = 0;
}
void Drawer::draw() {
    core.state_->draw();
}
void Drawer::postDraw(CDC* pDC) {
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
    core.view_->GetClientRect ( &rc );
    pDC->DrawText (core.state_->message().c_str(), -1, &rc, DT_LEFT | DT_TOP);
	pDC->SelectObject ( pOldFont );
}
void Drawer::draw_axis() {
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glBegin(GL_LINES);
    glColor3d(1, 0, 0);    glVertex3d(0, 0, 0);    glVertex3d(1, 0, 0);
    glColor3d(0, 1, 0);    glVertex3d(0, 0, 0);    glVertex3d(0, 1, 0);
    glColor3d(0, 0, 1);    glVertex3d(0, 0, 0);    glVertex3d(0, 0, 1);
    glEnd();
    glPopAttrib();
}
void Drawer::drawTexturedQuad(const Vector2d& cornerBL, const Vector2d& cornerBR, const Vector2d& cornerTL, const Vector2d& cornerTR) {
    static const int numDiv = 4;
    static vector<Vector2d> grid((numDiv + 1) * (numDiv + 1));
    for (int j = 0; j <= numDiv; ++j) for (int i = 0; i <= numDiv; ++i) {
        double tx1 = i * 1.0 / numDiv;
        double ty1 = j * 1.0 / numDiv;
        double tx0 = 1 - tx1;
        double ty0 = 1 - ty1;
        grid[(numDiv + 1) * j + i] =
            tx0 * ty0 * cornerBL +
            tx1 * ty0 * cornerBR +
            tx0 * ty1 * cornerTL +
            tx1 * ty1 * cornerTR;
    }
    glBegin(GL_QUADS);
    glColor4d(1, 1, 1, 1);
    for (int j = 0; j < numDiv; ++j) for (int i = 0; i < numDiv; ++i) {
        double tx0 = i * 1.0 / numDiv;
        double ty0 = j * 1.0 / numDiv;
        double tx1 = tx0 + 1. / numDiv;
        double ty1 = ty0 + 1. / numDiv;
        glTexCoord2d(tx0, ty0); glVertex2dv(grid[(numDiv + 1) * (j + 0) + i + 0].ptr());
        glTexCoord2d(tx1, ty0); glVertex2dv(grid[(numDiv + 1) * (j + 0) + i + 1].ptr());
        glTexCoord2d(tx1, ty1); glVertex2dv(grid[(numDiv + 1) * (j + 1) + i + 1].ptr());
        glTexCoord2d(tx0, ty1); glVertex2dv(grid[(numDiv + 1) * (j + 1) + i + 0].ptr());
    }
    glEnd();
}
