#include "StdAfx.h"
#include "StateColor.h"
#include "StateBlur.h"
#include "Core.h"
#include <gl/glut.h>
#include <iostream>
#include <stb_image.h>

using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;

Vector3d convert_COLORREF_Vector3d(const COLORREF& colref) {
    int r = (colref >> 0 ) & 0xFF;
    int g = (colref >> 8 ) & 0xFF;
    int b = (colref >> 16) & 0xFF;
    Vector3d vec3d(r, g, b);
    vec3d /= 255.;
    return vec3d;
}
COLORREF convert_Vector3d_COLORREF(const Vector3d& vec3d) {
    Vector3uc vec3uc = (vec3d * 255).convert<unsigned char>();
    return RGB(vec3uc[0], vec3uc[1], vec3uc[2]);
}
const double PAINT_SPHERE_RADIUS = 0.0125;
}

void StateColor::initialize() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    for (size_t i = 0; i < sz_sweepObjects; ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        sweepObj.mesh0_ref_.calcLaplacianMatrix();
        if (sweepObj.hasGrain_)
            sweepObj.grainObject_.mesh0_ref_.calcLaplacianMatrix();
    }
    mode_ = MODE_PAINT;
    currentObjectID_ = 0;
    glLineWidth(1);
    glPointSize(15);
}
string StateColor::message() {
    string msg;
    msg += "Step 5: Paint colors\n";
    msg += "Mode: ";
    msg +=
        mode_ == MODE_PAINT  ? "Paint" :
        mode_ == MODE_ERASE  ? "Erase" :
        mode_ == MODE_PICKUP ? "Color pickup" :
        "";
    return msg;
}
State* StateColor::next() {
    return StateBlur::getInstance();
}

void StateColor::draw() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    Mesh0& mesh0 = isGrainMode
        ? modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_].mesh0_ref_;
    
    glPushAttrib(GL_ENABLE_BIT);
    if (mode_ == MODE_PAINT || mode_ == MODE_ERASE) {
        glEnable(GL_LIGHTING);
        Drawer::draw_mesh_twosided(mesh0);
        glDisable(GL_LIGHTING);
        glColor3d(0, 0, 0);
        Drawer::draw_mesh_edge(mesh0);
        glEnable(GL_LIGHTING);
        // color constraints
        for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
            Vector3d point  = mesh0.point(v_it);
            Vector3d normal = mesh0.normal(v_it);
            Mesh0::VertexData& vdata = mesh0.data(v_it);
            if (mesh0.isTwoSided_ && !vdata.isOpenEnd_) {   // two-sided colors, (slightly offset)
                if (vdata.isConstrained_) {
                    glColor3dv(vdata.color_.ptr());
                    glPushMatrix();
                    Vector3d offsetPoint = point + normal * PAINT_SPHERE_RADIUS;
                    glTranslated(offsetPoint[0], offsetPoint[1], offsetPoint[2]);
                    glutSolidSphere(PAINT_SPHERE_RADIUS, 12, 12);
                    glPopMatrix();
                }
                if (vdata.back_isConstrained_) {
                    glColor3dv(vdata.back_color_.ptr());
                    glPushMatrix();
                    Vector3d offsetPoint = point - normal * PAINT_SPHERE_RADIUS;
                    glTranslated(offsetPoint[0], offsetPoint[1], offsetPoint[2]);
                    glutSolidSphere(PAINT_SPHERE_RADIUS, 12, 12);
                    glPopMatrix();
                }
            } else {    // no distinction between front and back
                if (!vdata.isConstrained_) continue;
                double radius = PAINT_SPHERE_RADIUS;
                glColor3dv(vdata.color_.ptr());
                glPushMatrix();
                glTranslated(point[0], point[1], point[2]);
                glutSolidSphere(PAINT_SPHERE_RADIUS, 12, 12);
                glPopMatrix();
            }
        }
        glDisable(GL_LIGHTING);
        if (mode_ == MODE_PAINT) {  // current color at 2D cursor position
            glDisable(GL_DEPTH_TEST);
            glMatrixMode(GL_PROJECTION);
            glPushMatrix();
            glLoadIdentity();
            gluOrtho2D(0, core.ogl_.getWidth(), 0, core.ogl_.getHeight());
            glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
            glLoadIdentity();
            glBegin(GL_POINTS);
            glColor3dv(currentColor_.ptr());
            glVertex2dv(cursorPosition_.ptr());
            glEnd();
            glPopMatrix();
            glMatrixMode(GL_PROJECTION);
            glPopMatrix();
            glMatrixMode(GL_MODELVIEW);
            glEnable(GL_DEPTH_TEST);
        }
    } else if (mode_ == MODE_PICKUP) {            // color pickup mode
        glDisable(GL_DEPTH_TEST);
        // 2D camera view
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        gluOrtho2D(0, core.ogl_.getWidth(), 0, core.ogl_.getHeight());
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glViewport(0, 0, core.ogl_.getWidth(), core.ogl_.getHeight());
        glDisable(GL_LIGHTING);
        // draw quad of refrence image
        if (img_.texture_.id()) {
            img_.texture_.enable();
            img_.texture_.bind();
            int w = img_.texture_.width();
            int h = img_.texture_.height();
            glBegin(GL_QUADS);
            glTexCoord2d(0, 0);    glVertex2d(0, 0);
            glTexCoord2d(1, 0);    glVertex2d(w, 0);
            glTexCoord2d(1, 1);    glVertex2d(w, h);
            glTexCoord2d(0, 1);    glVertex2d(0, h);
            glEnd();
            img_.texture_.unbind();
            img_.texture_.disable();
        }
        // draw current color
        int d = 100;
        glBegin(GL_QUADS);
        glColor3dv(currentColor_.ptr());
        glVertex2d(0, 0);
        glVertex2d(d, 0);
        glVertex2d(d, d);
        glVertex2d(0, d);
        glEnd();
        // camera restore
        glPopMatrix();
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glEnable(GL_DEPTH_TEST);
    }
    glPopAttrib();
}
void StateColor::OnLButtonDown(UINT nFlags, CPoint& point) {
    OnMouseMove(nFlags, point);
}
void StateColor::OnLButtonUp  (UINT nFlags, CPoint& point) {
    if (!isUpdated_)
        return;
    isUpdated_ = false;
    
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    Mesh0& mesh0 = isGrainMode
        ? modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_].mesh0_ref_;
    
    mesh0.updateColor();
    core.ogl_.RedrawWindow();
}
void StateColor::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateColor::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateColor::OnMouseMove  (UINT nFlags, CPoint& point) {
    cursorPosition_.set(point.x, core.ogl_.getHeight() - point.y);
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    Mesh0& mesh0 = isGrainMode
        ? modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_].mesh0_ref_;
    
    if (core.eventHandler_.isLButtonDown_) {
        if (mode_ == MODE_PAINT || mode_ == MODE_ERASE) {
            Vector3d start, ori;
            core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
            double dist_min = DBL_MAX;
            Mesh0::VHandle vhandle_target;
            for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
                Vector3d       point  [3];
                Mesh0::VHandle vhandle[3];
                Mesh0::FVIter fv_it = mesh0.fv_iter(f_it);
                for (int i = 0; i < 3; ++i, ++fv_it) {
                    point  [i] = mesh0.point(fv_it);
                    vhandle[i] = fv_it.handle();
                }
                Vector2d baryCoordLine;
                Vector3d baryCoordFace;
                Util::calcIntersectionLineTriangle(start, start + ori,
                    point[0], point[1], point[2],
                    baryCoordLine, baryCoordFace);
                double bary_max = 0;
                int index = -1;
                for (int i = 0; i < 3; ++i) {
                    if (baryCoordFace[i] < 0) {
                        index = -1;
                        break;
                    }
                    if (bary_max < baryCoordFace[i]) {
                        bary_max = baryCoordFace[i];
                        index = i;
                    }
                }
                if (index == -1)
                    continue;
                if (dist_min < baryCoordLine[1])
                    continue;
                dist_min = baryCoordLine[1];
                vhandle_target = vhandle[index];
            }
            if (vhandle_target.idx() == -1)
                return;
            isUpdated_ = true;
            struct Local {
                static void func(Mesh0::VertexData& vdata, Vector3d color, Mode mode, int whichside) {  // whichside = { 1: front, 2: back, 3: front & back }
                    if (whichside & 1) {
                        if (mode == MODE_PAINT) {
                            vdata.color_ = color;
                            vdata.isConstrained_ = true;
                        } else if (mode == MODE_ERASE)
                            vdata.isConstrained_ = false;
                    }
                    if (whichside & 2) {
                        if (mode == MODE_PAINT) {
                            vdata.back_color_ = color;
                            vdata.back_isConstrained_ = true;
                        } else if (mode == MODE_ERASE)
                            vdata.back_isConstrained_ = false;
                    }

                }
            };
            Mesh0::VertexData& vdata = mesh0.data(vhandle_target);
            Mesh0::VertexData* mapped_vdata = vdata.nfold1_mapped_vid_ != -1
                ? &mesh0.data(mesh0.vertex_handle(vdata.nfold1_mapped_vid_))
                : 0;
            if (!mesh0.isTwoSided_ || vdata.isOpenEnd_) {
                Local::func(vdata, currentColor_, mode_, 3);
                if (mapped_vdata)
                    Local::func(*mapped_vdata, currentColor_, mode_, 3);
            } else {
                const Vector3d& normal = mesh0.normal(vhandle_target);
                if ((normal | ori) < 0) {     // front
                    Local::func(vdata, currentColor_, mode_, 1);
                    if (mapped_vdata)
                        Local::func(*mapped_vdata, currentColor_, mode_, 1);
                } else {                    // back
                    Local::func(vdata, currentColor_, mode_, 2);
                    if (mapped_vdata)
                        Local::func(*mapped_vdata, currentColor_, mode_, 2);
                }
            }
            core.ogl_.RedrawWindow();
        } else if (mode_ == MODE_PICKUP) {        // color pickup mode
            if (!img_.texture_.id())
                return;
            int ix = static_cast<int>(cursorPosition_[0]);
            int iy = static_cast<int>(cursorPosition_[1]);
            if (img_.texture_.width() < ix)
                return;
            if (img_.texture_.height() < iy)
                return;
            Vector3uc color_uc = img_.dump_[img_.texture_.width() * iy + ix];
            currentColor_ = color_uc.convert<double>();
            currentColor_ /= 255.;
            core.ogl_.RedrawWindow();
        }
    } else {
        if (mode_ == MODE_PAINT)
            core.ogl_.RedrawWindow();
    }
    core.eventHandler_.default_OnMouseMove(nFlags, point);
}
void StateColor::OnDropFiles(const std::string& fname, const std::string& ext) {
    if (ext == "step5") {
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_Color(ifs)) {
            cout << "Error occurred in Modeler::load_Color()" << endl;
            return;
        }
        core.ogl_.RedrawWindow();
        return;
    }
    if (ext == "jpg" || ext == "png" || ext == "bmp") {
        int width, height, numChannel;
        unsigned char *data = stbi_load(fname.c_str(), &width, &height, &numChannel, 0);
        if (data == 0) {
            cout << "Couldn't load image file: " << fname << endl;
            return;
        }
        if (numChannel != 3) {
            cout << "Only RGB images are acceptable.\n";
            return;
        }
        img_.dump_.resize(width * height, Vector3uc());
        for (int i = 0; i < height; ++i)
            memcpy(&img_.dump_[width * (height - 1 - i)], &data[3 * width * i], 3 * width);
        core.ogl_.makeOpenGLCurrent();
        if (!img_.texture_.id())
            img_.texture_.init();
        img_.texture_.bind();
        GLuint format = numChannel == 1 ? GL_LUMINANCE : numChannel == 3 ? GL_RGB : numChannel == 4 ? GL_RGBA : 0;
        img_.texture_.allocate(format, width, height, format, GL_UNSIGNED_BYTE, &img_.dump_[0]);
        img_.texture_.unbind();
        stbi_image_free(data);
        core.ogl_.RedrawWindow();
        return;
    }
}
void StateColor::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    Mesh0& mesh0 = isGrainMode
        ? modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_].mesh0_ref_;
    
    switch (nChar) {
    case ' ':
        ++currentObjectID_;
        if (sz_sweepObjects <= currentObjectID_) {
            while (true) {
                if (currentObjectID_ == 2 * sz_sweepObjects) {
                    currentObjectID_ = 0;
                    break;
                }
                if (modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].hasGrain_)
                    break;
                ++currentObjectID_;
            }
        }
        core.ogl_.RedrawWindow();
        break;
    case 'Q':
    case 'W':
    case 'E':
        mode_ =
            nChar == 'Q' ? MODE_PAINT :
            nChar == 'W' ? MODE_ERASE : MODE_PICKUP;
        core.ogl_.RedrawWindow();
        break;
    case 'R': // Color chooser dialog
        {
            COLORREF colref = convert_Vector3d_COLORREF(currentColor_);
            CColorDialog dlg(colref);
            if (dlg.DoModal() == IDOK) {
                colref = dlg.GetColor();
                currentColor_ = convert_COLORREF_Vector3d(colref);
                core.ogl_.RedrawWindow();
            }
        }
        break;
    case 'T':   // isTwoSided on/off
        if (mesh0.isTwoSided_) {
            int ret = AfxMessageBox("Discard all two-sided colors?", MB_OKCANCEL);
            if (ret == IDCANCEL)
                return;
            for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
                Mesh0::VertexData& vdata = mesh0.data(v_it);
                vdata.back_color_         = vdata.color_;
                vdata.back_isConstrained_ = vdata.isConstrained_;
            }
        }
        mesh0.isTwoSided_ = !mesh0.isTwoSided_;
        cout << "isTwoSided: " << (mesh0.isTwoSided_ ? "yes" : "no") << "\n";
        break;
    case 'H':   // isHole on/off
        mesh0.isHole_ = !mesh0.isHole_;
        cout << "isHole: " << (mesh0.isHole_ ? "yes" : "no") << "\n";
        break;
    case 'F':   // flip
        if (!mesh0.isTwoSided_)
            return;
        for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
            Mesh0::VertexData& vdata = mesh0.data(v_it);
            swap(vdata.color_, vdata.back_color_);
            swap(vdata.isConstrained_, vdata.back_isConstrained_);
        }
        core.ogl_.RedrawWindow();
        break;
    case 'S':   // save
        {
            CFileDialog dlg(FALSE, "step5", "*.step5", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step5 files|*.step5||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_Color(ofs);
        }
        break;
    }
}
