#include "StdAfx.h"
#include "SilhouetteRendererT.h"
#include "Core.h"
#include <algorithm>
#include <stb_image.h>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

template <class TScene>
void SilhouetteRendererT<TScene>::gl_init() {
    fbo_.init();
    bufDepth_.init();
    bufColor_.init();
    // load brush texture
    int width, height, numChannel;
    unsigned char *data = stbi_load("brush.png", &width, &height, &numChannel, 0);
    if (data != 0) {
        texBrush_.init();
        texBrush_.bind();
        GLuint format = numChannel == 1 ? GL_LUMINANCE : numChannel == 3 ? GL_RGB : numChannel == 4 ? GL_RGBA : 0;
        gluBuild2DMipmaps(GL_TEXTURE_2D, format, width, height, format, GL_UNSIGNED_BYTE, data);
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
        texBrush_.unbind();
        stbi_image_free(data);
    }
}
template <class TScene>
void SilhouetteRendererT<TScene>::gl_deinit() {
    fbo_.deinit();
    bufDepth_.deinit();
    bufColor_.deinit();
    texBrush_.deinit();
}

template <class TScene>
void SilhouetteRendererT<TScene>::gl_resize(int width, int height) {
    bufColor_.bind();
    bufColor_.allocate(GL_RGBA, width, height);
    bufColor_.unbind();
    bufDepth_.bind();
    bufDepth_.allocate(GL_DEPTH_COMPONENT, width, height);
    bufDepth_.unbind();
    fbo_.bind();
    fbo_.attachRenderbuffer(GL_COLOR_ATTACHMENT0_EXT, bufColor_);
    fbo_.attachRenderbuffer(GL_DEPTH_ATTACHMENT_EXT , bufDepth_);
    GLUtil::checkFramebufferStatus("SilhouetteRendererT::gl_resize");
    fbo_.unbind();
}

template <class TScene>
void SilhouetteRendererT<TScene>::gl_draw() {
    int width  = bufDepth_.width ();
    int height = bufDepth_.height();
    
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, width, height, 0.0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_VIEWPORT_BIT | GL_TEXTURE_BIT);
    glViewport(0, 0, width, height);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    texBrush_.enable();
    texBrush_.bind();
    glColor3d(1, 0, 0);
    
    for (size_t i = 0; i < strips_.size(); ++i) {
        glBegin(GL_TRIANGLE_STRIP);
        vector<Vector2d>& strip = strips_[i];
        double s = 0;
        double ds = 1. / (strip.size() / 2 - 1);
        for (size_t j = 0; j < strip.size(); j += 2, s += ds) {
            glTexCoord2d(s, 0);
            glVertex2d(strip[j]);
            glTexCoord2d(s, 1);
            glVertex2d(strip[j + 1]);
        }
        glEnd();
    }
    
    glPopAttrib();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

template <class TScene>
void SilhouetteRendererT<TScene>::clear() {
    curves3d_fixed_.clear();
    curves3d_.clear();
    curves2d_.clear();
    flagVisible_.clear();
    strips_.clear();
}

template <class TScene>
void SilhouetteRendererT<TScene>::update(TScene& scene) {
    ogl.makeOpenGLCurrent();
    
    scene.calcFixedCurves();
    
    curves3d_ = curves3d_fixed_;
    
    scene.calcSilhouetteCurves();
    
    step1_renderID_pre();
    
    scene.renderSceneDepth();
    
    step1_renderID_post();
    step2_findVisible();
    step3a_calcCurves2d();
    step3b_pruneShortCurves();
    step3c_smooth();
    step3d_resample();
    step3e_calcLappedCurves();
    step4_calcStrips();
}

template <class TScene>
void SilhouetteRendererT<TScene>::step1_renderID_pre() {
    fbo_.bind();
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_POINT_BIT);
    glClearColor(1, 1, 1, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3d(1, 1, 1);
    glDisable(GL_LIGHTING);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
}
template <class TScene>
void SilhouetteRendererT<TScene>::step1_renderID_post() {
    struct Local {
        static Vector3uc id2color(unsigned int id) {
            return Vector3uc(id & 0xFF, (id >> 8) & 0xFF, (id >> 16) & 0xFF);
        }
    };
    // draw 3D curves
    unsigned int id = 0;
    glPointSize(10);
    glBegin(GL_POINTS);
    for (size_t i = 0; i < curves3d_.size(); ++i) {
        Polyline3d& curve = curves3d_[i];
        for (size_t j = 0; j < curve.size(); ++j, ++id) {
            Vector3uc color = Local::id2color(id);
            glColor3ub(color);
            glVertex3d(curve[j]);
        }
    }
    glEnd();
    
    glPopAttrib();
    bufColor_cpu_.clear();
    int width  = bufColor_.width ();
    int height = bufColor_.height();
    bufColor_cpu_.resize(4 * width * height);
    glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, &bufColor_cpu_[0]);
    glFinish();
    fbo_.unbind();
}

template <class TScene>
void SilhouetteRendererT<TScene>::step2_findVisible() {
    struct Local {
        static unsigned int color2id(const Vector3uc& color) {
            return color[0] | (color[1] << 8) | (color[2] << 16);
        }
    };
    size_t numCurvePoints = 0;
    for (size_t i = 0; i < curves3d_.size(); ++i)
        numCurvePoints += curves3d_[i].size();
    flagVisible_.clear();
    flagVisible_.resize(numCurvePoints, 0);
    int width  = bufColor_.width ();
    int height = bufColor_.height();
    //int wh =  * bufColor_.height();
    for (size_t j = 0; j < height; ++j) for (size_t i = 0; i < width; ++i) {
        Vector3uc color(&bufColor_cpu_[4 * (i + width * j)]);
        if ((color[0] & color[1] & color[2]) == 0xFF)
            continue;
        unsigned int id = Local::color2id(color);
        flagVisible_[id] = 1;
    }
    if (numCurvePoints < 2)
        return;
    for (size_t i = 1; i < numCurvePoints - 1; ++i)
        if (flagVisible_[i - 1] && flagVisible_[i + 1])         // kind of hack... :/
            flagVisible_[i] = 1;
}

template <class TScene>
void SilhouetteRendererT<TScene>::step3a_calcCurves2d() {
    curves2d_.clear();
    unsigned int id = 0;
    for (size_t i = 0; i < curves3d_.size(); ++i) {
        Polyline3d& curve3d = curves3d_[i];
        vector<Polyline2d> curves2d_temp;
        Polyline2d* curve2d = 0;
        bool wasVisible = false;    // true if the previous curve point was visible
        bool allVisible = true;
        bool isFirstVisible = false;
        bool isLastVisible  = false;
        for (size_t j = 0; j < curve3d.size(); ++j, ++id) {
            if (flagVisible_[id]) {
                if (!wasVisible) {  // add a new 2d curve
                    curves2d_temp.push_back(Polyline2d());
                    curve2d = &curves2d_temp.back();
                    wasVisible = true;
                }
                // add a point to the current 2d curve
                Vector3d& point_3d = curve3d[j];
                Vector2d point_2d(ogl.project(point_3d));
                curve2d->push_back(point_2d);
            } else {
                wasVisible = false;
                allVisible = false;
            }
            if (j == 0)
                isFirstVisible = flagVisible_[id] != 0;
            if (j == curve3d.size() - 1)
                isLastVisible  = flagVisible_[id] != 0;
        }
        if (curve3d.isLoop()) {
            if (allVisible) {
                curve2d->setLoop(true);
            } else if (isFirstVisible && isLastVisible) {
                Polyline2d& curve_front = curves2d_temp.front();
                Polyline2d  curve_back  = curves2d_temp.back();
                curves2d_temp.pop_back();
                curve_front.reverse();
                for (int j = static_cast<int>(curve_back.size()) - 1; j >= 0; --j)
                    curve_front.push_back(curve_back[j]);
            }
        }
        // append all curves
        for (size_t j = 0; j < curves2d_temp.size(); ++j)
            curves2d_.push_back(curves2d_temp[j]);
    }
}

template <class TScene>
void SilhouetteRendererT<TScene>::step3b_pruneShortCurves() {
    double length_threshold = 0.01 * (bufDepth_.width() + bufDepth_.height());
    vector<Polyline2d> curves2d_old = curves2d_;
    curves2d_.clear();
    curves2d_.reserve(curves2d_old.size());
    for (size_t i = 0; i < curves2d_old.size(); ++i) {
        Polyline2d& curve = curves2d_old[i];
        if (length_threshold < curve.length())
            curves2d_.push_back(curve);
    }
}

template <class TScene>
void SilhouetteRendererT<TScene>::step3c_smooth() {
    for (size_t i = 0; i < curves2d_.size(); ++i) {
        Polyline2d& curve = curves2d_[i];
        curve.smooth_simple();
        curve.smooth_simple();
        curve.smooth_simple();
    }
}

template <class TScene>
void SilhouetteRendererT<TScene>::step3d_resample() {
    double segLength = 0.001 * (bufDepth_.width() + bufDepth_.height());
    for (size_t i = 0; i < curves2d_.size(); ++i) {
        Polyline2d& curve = curves2d_[i];
        int n = 1 + static_cast<int>(curve.length() / segLength);
        curve.resample(n);
    }
}

template <class TScene>
void SilhouetteRendererT<TScene>::step3e_calcLappedCurves() {
    vector<Polyline2d> curves2d_old = curves2d_;
    curves2d_.clear();
    curves2d_.reserve(curves2d_old.size() * 10);
    const int pieceSize = 30;
    for (size_t i = 0; i < curves2d_old.size(); ++i) {
        Polyline2d& curve_old = curves2d_old[i];
        size_t n = curve_old.size();
        if (n <= pieceSize) {
            curves2d_.push_back(curve_old);
            continue;
        }
        vector<int> isCovered(n, 0);
        struct LessThan2 { bool operator()(int num) const { return num < 2; } };
        while (count_if(&isCovered[0] + pieceSize / 2, &isCovered[0] + n - pieceSize / 2, LessThan2()) != 0) {
            int index_begin = rand() % (curve_old.isLoop() ? n : (n - pieceSize));
            //if (isCovered[(index_begin + pieceSize / 2) % n])
            //    continue;
            int index = index_begin;
            Polyline2d curve_new;
            for (int cnt = 0; cnt < pieceSize; ++cnt) {
                ++isCovered[index];
                curve_new.push_back(curve_old[index]);
                index = (index + 1) % n;
            }
            curves2d_.push_back(curve_new);
        }
    }
}

template <class TScene>
void SilhouetteRendererT<TScene>::step4_calcStrips() {
    strips_.clear();
    for (size_t i = 0; i < curves2d_.size(); ++i) {
        vector<Vector2d> strip;
        Polyline2d& curve2d = curves2d_[i];
        double w = 5;
        double dw = 0.5 * w / curve2d.size();
        for (size_t j = 0; j < curve2d.size(); ++j) {
            Vector2d n0, n1;
            if (0 < j) {
                n0 = rotate90(curve2d[j] - curve2d[j - 1]);
                n0.normalize();
            }
            if (j < curve2d.size() - 1) {
                n1 = rotate90(curve2d[j + 1] - curve2d[j]);
                n1.normalize();
            }
            Vector2d r = n0 + n1;
            r.normalize();
            r *= w;
            //w -= dw;
            strip.push_back(curve2d[j] - r);
            strip.push_back(curve2d[j] + r);
        }
        // should consider the case of looped curves?
        strips_.push_back(strip);
    }
}

template <class TScene>
template <class TMesh, class TTransform>
void SilhouetteRendererT<TScene>::addSilhouette(TMesh& mesh, const TTransform& tfm) {
    // compute normal-eye dot product
    for (TMesh::VIter v = mesh.vertices_begin(); v != mesh.vertices_end(); ++v) {
        Vector3d point = mesh.point(v);
        Vector3d normal = mesh.normal(v);
        point = tfm.transform(point);
        normal = tfm.rotate(normal);
        Vector3d eye = ogl.viewParam_.eyePoint_ - point;
        eye.normalize();
        mesh.data(v).normal_eye_product_ = normal | eye;
    }
    // compute silhouette position on edges
    for (TMesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e) {
        Vector3d point[2];
        double product[2];
        for (int i = 0; i < 2; ++i) {
            TMesh::VHandle vhandle = mesh.to_vertex_handle(mesh.halfedge_handle(e, i));
            point[i] = tfm.transform(mesh.point(vhandle));
            product[i] = mesh.data(vhandle).normal_eye_product_;
        }
        mesh.data(e).isSilhouetteCrossed_ = product[0] * product[1] < 0;
        if (mesh.data(e).isSilhouetteCrossed_) {
            double t = -product[0] / (product[1] - product[0]);
            mesh.data(e).silhouettePos_ = (1 - t) * point[0] + t * point[1];
        }
    }
    // connect silhouette points on edges to form curves
    std::list<std::pair<int, int> > sil_indices;
    for (TMesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
        bool isFirst = true;
        std::pair<int, int> index_pair(-1, -1);
        for (TMesh::FEIter e = mesh.fe_iter(f); e; ++e) {
            if (mesh.data(e).isSilhouetteCrossed_) {
                if (isFirst) {
                    isFirst = false;
                    index_pair.first  = e.handle().idx();
                } else {
                    assert(index_pair.second == -1);
                    index_pair.second = e.handle().idx();
                }
            }
        }
        if (index_pair.first != -1)
            sil_indices.push_back(index_pair);
    }
    int index_forward  = -1;
    int index_backward = -1;
    std::vector<Vector3d> points_forward;
    std::vector<Vector3d> points_backward;
    bool isLoop = false;
    while (true) {
        if (sil_indices.empty() || index_forward == -1 && index_backward == -1) {
            if (!points_forward.empty() || !points_backward.empty()) {
                Polyline3d sil_curve;
                for (std::vector<Vector3d>::reverse_iterator it = points_backward.rbegin(); it != points_backward.rend(); ++it)
                    sil_curve.push_back(*it);
                for (std::vector<Vector3d>::iterator         it = points_forward .begin (); it != points_forward .end (); ++it)
                    sil_curve.push_back(*it);
                sil_curve.setLoop(isLoop);
                curves3d_.push_back(sil_curve);
            }
            if (sil_indices.empty())
                break;
            index_forward  = sil_indices.back().first;
            index_backward = sil_indices.back().second;
            sil_indices.pop_back();
            points_forward .clear();
            points_backward.clear();
            points_forward .push_back(mesh.data(mesh.edge_handle(index_forward )).silhouettePos_);
            points_backward.push_back(mesh.data(mesh.edge_handle(index_backward)).silhouettePos_);
            isLoop = false;
        }
        if (index_forward != -1) {
            bool isFound = false;
            for (std::list<std::pair<int, int> >::iterator it = sil_indices.begin(); it != sil_indices.end(); ++it) {
                if (it->first == index_forward || it->second == index_forward) {
                    index_forward = it->first == index_forward ? it->second : it->first;
                    sil_indices.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_forward.push_back(mesh.data(mesh.edge_handle(index_forward)).silhouettePos_);
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_forward = -1;
        }
        if (index_backward != -1) {
            bool isFound = false;
            for (std::list<std::pair<int, int> >::iterator it = sil_indices.begin(); it != sil_indices.end(); ++it) {
                if (it->first == index_backward || it->second == index_backward) {
                    index_backward = it->first == index_backward ? it->second : it->first;
                    sil_indices.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_backward.push_back(mesh.data(mesh.edge_handle(index_backward)).silhouettePos_);
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_backward = -1;
        }
    }
}
template <class TScene>
template <class TMesh>
void SilhouetteRendererT<TScene>::addSilhouette(TMesh& mesh) {
    struct NoTransform {
        Vector3d transform(const Vector3d& p) const { return p; }
        Vector3d rotate(const Vector3d& p) const { return p; }
    };
    addSilhouette(mesh, NoTransform());
}

template <class TScene>
template <class TMesh, class TTransform>
void SilhouetteRendererT<TScene>::renderDepth(const TMesh& mesh, const TTransform& tfm) const {
    // transformation
	glPushMatrix();
	tfm.call_gl();
    glBegin(GL_TRIANGLES);
    // draw mesh3s
    for (TMesh::CFIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
        if (mesh.data(f).isHidden())
            continue;
        for (TMesh::CFVIter v = mesh.cfv_iter(f); v; ++v)
            glVertex3d(mesh.point(v));
    }
    glEnd();
    glPopMatrix();
}
template <class TScene>
template <class TMesh>
void SilhouetteRendererT<TScene>::renderDepth(const TMesh& mesh) const {
    struct NoTransform { void call_gl() const {} };
    renderDepth(mesh, NoTransform());
}

// manually instantiate templates
template struct SilhouetteRendererT<VolumeObject>;
template void SilhouetteRendererT<VolumeObject>::addSilhouette<Mesh0>(Mesh0& mesh);
template void SilhouetteRendererT<VolumeObject>::addSilhouette<Mesh3>(Mesh3& mesh);
template void SilhouetteRendererT<VolumeObject>::renderDepth<Mesh0>(const Mesh0& mesh) const;
template void SilhouetteRendererT<VolumeObject>::renderDepth<Mesh2>(const Mesh2& mesh) const;
template void SilhouetteRendererT<VolumeObject>::renderDepth<Mesh3>(const Mesh3& mesh) const;
template struct SilhouetteRendererT<Salad>;
template void SilhouetteRendererT<Salad>::addSilhouette<Mesh0, Transform>(Mesh0& mesh, const Transform& tfm);
template void SilhouetteRendererT<Salad>::addSilhouette<Mesh3, Transform>(Mesh3& mesh, const Transform& tfm);
template void SilhouetteRendererT<Salad>::renderDepth<Mesh0>(const Mesh0& mesh, const Transform& tfm) const;
template void SilhouetteRendererT<Salad>::renderDepth<Mesh2>(const Mesh2& mesh, const Transform& tfm) const;
template void SilhouetteRendererT<Salad>::renderDepth<Mesh3>(const Mesh3& mesh, const Transform& tfm) const;
