#include "stdafx.h"
#include "Core.h"
#include "DiffusePmvcT.h"
#include "CutParam.h"
#include <KLIB/Util.h>
#include <KLIB/TriangleUtil.h>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;

const double DBG_EDGE_SPLIT_SIZE = 0.0;
}

template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2_mesh2(VolumeObject& volObj, CutParam& param) {
    volObj.cutData_.mesh1_.clear();
    cut_step2a_mesh0intersect(volObj, param);
    cut_step2b_mesh0segment  (volObj, param);
    if (volObj.cutData_.mesh1_.vertices_empty())
        return;
    cut_step2c_calltriangle  (volObj, param);
    cut_step2d_mesh1vertex   (volObj, param);
    cut_step2e_mesh1edge     (volObj, param);
    cut_step2f_mesh1_mesh2   (volObj, param);
    cut_step2g_mesh2label    (volObj, param);
    cut_step2h_mesh2color    (volObj, param);
    cout << "";
}

template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2a_mesh0intersect(VolumeObject& volObj, CutParam& param) {
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id) {
        Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
        // check if the cutting stroke crosses edges
        for (Mesh0::EIter e = mesh0.edges_begin(); e != mesh0.edges_end(); ++e) {
            Vector3d point3d   [2];
            Vector3d color     [2];
            Vector3d back_color[2];
            for (int i = 0; i < 2; ++i) {
                Mesh0::VHandle vhandle = mesh0.from_vertex_handle(mesh0.halfedge_handle(e, i));
                Mesh0::VertexData& vdata = mesh0.data(vhandle);
                point3d   [i] = mesh0.point(vhandle);
                color     [i] = vdata.color_;
                back_color[i] = vdata.back_color_;
            }
            Mesh0::EdgeData& mesh0_edata = mesh0.data(e);
            bool isCrossed    = mesh0_edata.isCrossed_;
            double crossedPos = mesh0_edata.crossedPos_;
            if (isCrossed) {
                //cout << "The RBF scalar field's zero surface crosses edge " << e.handle().idx() << endl;
                Vector3d& point3d_cross = (1 - crossedPos) * point3d[0] + crossedPos * point3d[1];
                Vector2d& point2d = cut_step2_trimesh_project(point3d_cross, param);
                Mesh1::VHandle mesh1_vhandle = mesh1.add_vertex(point3d_cross);   // add mesh1 boundary vertex
                Mesh1::VertexData& mesh1_vdata = mesh1.data(mesh1_vhandle);
                mesh1_vdata.type_ = (mesh0.isTwoSided_ && !mesh0_edata.isOpenEnd_) ? Mesh1Traits::VERTEX_BOUNDARY_SPLIT : Mesh1Traits::VERTEX_BOUNDARY;
                mesh1_vdata.point2d_    = point2d;
                mesh1_vdata.color_      = (1 - crossedPos) * color     [0] + crossedPos * color     [1];
                mesh1_vdata.back_color_ = (1 - crossedPos) * back_color[0] + crossedPos * back_color[1];
                // reference from mesh0 vertex to mesh1 vertex
                mesh0_edata.mesh1_vid_ = mesh1_vhandle.idx();
            } else {
                // no reference from mesh0 vertex to mesh1 vertex
                mesh0_edata.mesh1_vid_ = -1;
            }
        }
    }
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2b_mesh0segment(VolumeObject& volObj, CutParam& param) {
    // generate input data for Shewchuk's Triangle library
    triangle_inout_ = TriangleInOut();
    
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    vector<SegmentInfo>& segmentinfolist = triangle_inout_.segmentinfolist_;
    vector<double>& in_pointlist         = triangle_inout_.in_pointlist_;
    vector<int>&    in_segmentlist       = triangle_inout_.in_segmentlist_;
    vector<int>&    in_segmentmarkerlist = triangle_inout_.in_segmentmarkerlist_;
    size_t& n_bvertices = triangle_inout_.n_bvertices_;
    size_t& n_bsegments = triangle_inout_.n_bsegments_;
    
    // pointlist (already available)
    in_pointlist  .reserve(2 * mesh1.n_vertices());
    for (Mesh1::VIter v = mesh1.vertices_begin(); v != mesh1.vertices_end(); ++v) {
        Vector2d& point2d = mesh1.data(v).point2d_;
        for (int i = 0; i < 2; ++i)
            in_pointlist.push_back(point2d[i]);
    }
    // segmentlist (made by visiting all mesh0 faces)
    in_segmentlist.reserve(in_pointlist.size() * 3 / 2);
    double segmentLength_min = DBL_MAX;
    double segmentLength_max = 0;
    for (int mesh0id = 0; mesh0id < volObj.srfMeshes_.size(); ++mesh0id) {
        Mesh0& mesh0 = volObj.srfMeshes_[mesh0id].mesh0_;
        for (Mesh0::FIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {
            int cntCrossed = 0;
            Mesh0::FEIter e = mesh0.fe_iter(f);
            for (int i = 0; i < 3; ++i, ++e) {
                if (mesh0.data(e).isCrossed_)
                    ++cntCrossed;
            }
            if (cntCrossed == 0)
                continue;
            assert (cntCrossed == 2);
            bool isFirst = true;
            Vector2d segment;
            for (e = mesh0.fe_iter(f); e; ++e) {
                if (!mesh0.data(e).isCrossed_)
                    continue;
                int mesh1_vid = mesh0.data(e).mesh1_vid_;
                in_segmentlist.push_back(mesh1_vid);
                Vector2d& point2d = mesh1.data(mesh1.vertex_handle(mesh1_vid)).point2d_;
                segment = isFirst ? point2d : (segment - point2d);
                isFirst = false;
            }
            segmentinfolist.push_back(SegmentInfo(mesh0id, f.handle().idx()));
            double segmentLength = segment.length();
            segmentLength_min = min(segmentLength_min, segmentLength);
            segmentLength_max = max(segmentLength_max, segmentLength);
        }
    }
    triangle_inout_.in_area_ = 0.5 * (segmentLength_min + segmentLength_max);
    triangle_inout_.in_area_ *= triangle_inout_.in_area_ * 1.73205081 / 4;
    n_bvertices = in_pointlist  .size() / 2;
    if (param.mode_ == CutParam::WEDGE) {
        // additional points on y-axis for the case of wedge cut
        double y_min = volObj.bbox_.min_[1];
        double y_max = volObj.bbox_.max_[1];
        for (int i = 0; i < CutParam::NUM_WEDGE_VERTICES__; ++i) {
            const double ratio = 1.0;//0.75;
            double x_jitter = volObj.bbox_.diagonal() * 0.005;
            double t = ratio * i / (CutParam::NUM_WEDGE_VERTICES__ - 1.) + 0.5 * (1 - ratio);
            double y = (1 - t) * y_min + t * y_max;
            double x = (1 - 2 * rand() / (double)RAND_MAX) * x_jitter;
            in_pointlist.push_back(x);
            in_pointlist.push_back(y);
        }
    }
    n_bsegments = in_segmentlist.size() / 2;
    in_segmentmarkerlist.resize(n_bsegments);
    for (size_t i = 0; i < n_bsegments; ++i)
        in_segmentmarkerlist[i] = i + 1;
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2c_calltriangle  (VolumeObject& volObj, CutParam& param) {
    vector<double>& in_pointlist         = triangle_inout_.in_pointlist_;
    vector<int>&    in_segmentlist       = triangle_inout_.in_segmentlist_;
    vector<int>&    in_segmentmarkerlist = triangle_inout_.in_segmentmarkerlist_;
    size_t& n_bvertices = triangle_inout_.n_bvertices_;
    size_t& n_bsegments = triangle_inout_.n_bsegments_;
    vector<double>& out_pointlist         = triangle_inout_.out_pointlist_;
    vector<int>&    out_pointmarkerlist   = triangle_inout_.out_pointmarkerlist_;
    vector<int>&    out_trianglelist      = triangle_inout_.out_trianglelist_;
    vector<int>&    out_segmentlist       = triangle_inout_.out_segmentlist_;
    vector<int>&    out_segmentmarkerlist = triangle_inout_.out_segmentmarkerlist_;
    
    // call Triangle
    triangulateio in, out;
    TriangleUtil::initData(in);
    TriangleUtil::initData(out);
    in.pointlist = &in_pointlist[0];
    in.numberofpoints = in_pointlist.size() / 2;
    in.segmentlist       = &in_segmentlist      [0];
    in.segmentmarkerlist = &in_segmentmarkerlist[0];
    in.numberofsegments = static_cast<int>(n_bsegments);
    ostringstream triangle_switch;
    triangle_switch << "zpq32D";
    //triangle_switch << "a" << fixed << triangle_inout_.in_area_;  // area constraint
    triangulate(const_cast<char*>(triangle_switch.str().c_str()), &in, &out, 0);
    out_pointlist        .resize(out.numberofpoints    * 2);
    out_pointmarkerlist  .resize(out.numberofpoints);
    out_trianglelist     .resize(out.numberoftriangles * 3);
    out_segmentlist      .resize(out.numberofsegments  * 2);
    out_segmentmarkerlist.resize(out.numberofsegments);
    memcpy(&out_pointlist        [0], out.pointlist        , sizeof(double) * out_pointlist        .size());
    memcpy(&out_pointmarkerlist  [0], out.pointmarkerlist  , sizeof(int)    * out_pointmarkerlist  .size());
    memcpy(&out_trianglelist     [0], out.trianglelist     , sizeof(int)    * out_trianglelist     .size());
    memcpy(&out_segmentlist      [0], out.segmentlist      , sizeof(int)    * out_segmentlist      .size());
    memcpy(&out_segmentmarkerlist[0], out.segmentmarkerlist, sizeof(int)    * out_segmentmarkerlist.size());
    trifree(out.pointlist        );
    trifree(out.pointmarkerlist  );
    trifree(out.trianglelist     );
    trifree(out.segmentlist      );
    trifree(out.segmentmarkerlist);
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2d_mesh1vertex   (VolumeObject& volObj, CutParam& param) {
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    vector<double>& in_pointlist         = triangle_inout_.in_pointlist_;
    vector<int>&    in_segmentlist       = triangle_inout_.in_segmentlist_;
    vector<int>&    in_segmentmarkerlist = triangle_inout_.in_segmentmarkerlist_;
    size_t& n_bvertices = triangle_inout_.n_bvertices_;
    size_t& n_bsegments = triangle_inout_.n_bsegments_;
    vector<double>& out_pointlist         = triangle_inout_.out_pointlist_;
    vector<int>&    out_pointmarkerlist   = triangle_inout_.out_pointmarkerlist_;
    vector<int>&    out_trianglelist      = triangle_inout_.out_trianglelist_;
    vector<int>&    out_segmentlist       = triangle_inout_.out_segmentlist_;
    vector<int>&    out_segmentmarkerlist = triangle_inout_.out_segmentmarkerlist_;
    size_t n_vertices = out_pointlist   .size() / 2;
    size_t n_faces    = out_trianglelist.size() / 3;

    // add newly generated vertices to Mesh1, while also checking steiner points
    vector<Mesh1::VHandle> vhandles(n_vertices);
    Mesh1::VIter v = mesh1.vertices_begin();
    for (size_t i = 0; i < n_bvertices; ++i, ++v) {
        assert(mesh1.data(v).type_ != Mesh1Traits::VERTEX_INTERIOR);
        vhandles[i] = v.handle();
    }
    for (size_t i = n_bvertices; i < n_vertices; ++i) {
        Vector2d point2d(&out_pointlist[2 * i]);
        int segmentid = out_pointmarkerlist[i] - 1;
        bool isSteiner = segmentid != -1;      // this output point is Steiner point inserted between a boundary edge
        if (isSteiner) {
            int      steiner_vid[2];
            Vector3d steiner_point3d[2];
            Vector2d steiner_point2d[2];
            Vector3d steiner_color[2];
            Vector3d steiner_back_color[2];
            bool isSplit = false;
            for (int j = 0; j < 2; ++j) {
                steiner_vid[j] = in_segmentlist[2 * segmentid + j];
                Mesh1::VHandle     steiner_vhandle = mesh1.vertex_handle(steiner_vid[j]);
                Mesh1::VertexData& steiner_vdata   = mesh1.data(steiner_vhandle);
                steiner_point3d   [j] = mesh1.point(steiner_vhandle);
                steiner_point2d   [j] = steiner_vdata.point2d_;
                steiner_color     [j] = steiner_vdata.color_;
                steiner_back_color[j] = steiner_vdata.back_color_;
                if (steiner_vdata.type_ == Mesh1Traits::VERTEX_BOUNDARY_SPLIT)
                    isSplit = true;
            }
            Vector2d& baryCoordLine = Util::calcBarycentricCoord<double, 2, 2>(steiner_point2d, point2d);
            double steiner_divPos = baryCoordLine[1];
            // add mesh1 boundary vertex (Steiner point)
            Vector3d& point3d    = (1 - steiner_divPos) * steiner_point3d   [0] + steiner_divPos * steiner_point3d   [1];
            Vector3d& color      = (1 - steiner_divPos) * steiner_color     [0] + steiner_divPos * steiner_color     [1];
            Vector3d& back_color = (1 - steiner_divPos) * steiner_back_color[0] + steiner_divPos * steiner_back_color[1];
            vhandles[i] = mesh1.add_vertex(point3d);
            Mesh1::VertexData& vdata = mesh1.data(vhandles[i]);
            vdata.type_       = isSplit ? Mesh1Traits::VERTEX_BOUNDARY_SPLIT : Mesh1Traits::VERTEX_BOUNDARY;
            vdata.point2d_    = point2d;
            vdata.color_      = color;
            vdata.back_color_ = back_color;
            vdata.dbg_isOpenEnd_ = isSplit;
            vdata.dbg_isSteiner_ = true;
        } else {
            // add mesh1 interior vertex
            Vector3d& point3d = cut_step2_trimesh_unproject(point2d, param);   // compute 2D-3D mapping
            vhandles[i] = mesh1.add_vertex(point3d);
            Mesh1::VertexData& vdata = mesh1.data(vhandles[i]);
            vdata.type_     = Mesh1Traits::VERTEX_INTERIOR;
            vdata.point2d_ = point2d;
        }
    }
    cout << "adding faces... ";
    for (size_t i = 0; i < n_faces; ++i) {
        vector<Mesh1::VHandle> face_vhandles(3);
        for (int j = 0; j < 3; ++j)
            face_vhandles[j] = vhandles[out_trianglelist[3 * i + j]];
        reverse(face_vhandles.begin(), face_vhandles.end());
        mesh1.add_face(face_vhandles);
    }
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2e_mesh1edge     (VolumeObject& volObj, CutParam& param) {
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    vector<SegmentInfo>& segmentinfolist = triangle_inout_.segmentinfolist_;
    vector<double>& in_pointlist         = triangle_inout_.in_pointlist_;
    vector<int>&    in_segmentlist       = triangle_inout_.in_segmentlist_;
    vector<int>&    in_segmentmarkerlist = triangle_inout_.in_segmentmarkerlist_;
    size_t& n_bvertices = triangle_inout_.n_bvertices_;
    size_t& n_bsegments = triangle_inout_.n_bsegments_;
    vector<double>& out_pointlist         = triangle_inout_.out_pointlist_;
    vector<int>&    out_pointmarkerlist   = triangle_inout_.out_pointmarkerlist_;
    vector<int>&    out_trianglelist      = triangle_inout_.out_trianglelist_;
    vector<int>&    out_segmentlist       = triangle_inout_.out_segmentlist_;
    vector<int>&    out_segmentmarkerlist = triangle_inout_.out_segmentmarkerlist_;
    
    // set Mesh1 edge data (type & normal) according to out_segmentmarkerlist, compute face barycenter, assign two normals for each vertices to be split
    for (Mesh1::EIter e = mesh1.edges_begin(); e != mesh1.edges_end(); ++e)  // set default as INTERIOR
        mesh1.data(e).type_ = Mesh1Traits::EDGE_INTERIOR;
    size_t n_out_segments = out_segmentlist.size() / 2;
    double normal_delta = volObj.bbox_.diagonal() * 0.001;
    double ratio_max = 0;
    double ratio_min = 100000;
    for (size_t out_segmentid = 0; out_segmentid < n_out_segments; ++out_segmentid) {   // process Mesh1 edge corresponding to Triangle's output segment
        int vid[2];
        for (int j = 0; j < 2; ++j)
            vid[j] = out_segmentlist[2 * out_segmentid + j];
        Mesh1::VHandle vhandle0 = mesh1.vertex_handle(vid[0]);
        Mesh1::VHandle vhandle1;
        Mesh1::EHandle ehandle;
        for (Mesh1::VOHIter voh_it = mesh1.voh_iter(vhandle0); voh_it; ++voh_it) {  // find correspondence by vertex-halfedge circulation
            vhandle1 = mesh1.to_vertex_handle(voh_it);
            if (vhandle1.idx() == vid[1]) {
                ehandle = mesh1.edge_handle(voh_it);
                break;
            }
        }
        assert(ehandle.idx() != -1);
        Mesh1::EdgeData& edata = mesh1.data(ehandle);
        int segmentid = out_segmentmarkerlist[out_segmentid] - 1;
        SegmentInfo& segmentinfo = segmentinfolist[segmentid];
        Mesh0& mesh0 = volObj.srfMeshes_[segmentinfo.mesh0_id_].mesh0_;
        edata.mesh0_id_ = segmentinfo.mesh0_id_;
        if (mesh0.isTwoSided_) {
            edata.type_ = Mesh1Traits::EDGE_BOUNDARY_SPLIT;
            Vector2d& point2d0 = mesh1.data(vhandle0).point2d_;
            Vector2d& point2d1 = mesh1.data(vhandle1).point2d_;
            Vector3d& point3d0 = mesh1.point(vhandle0);
            Vector3d& point3d1 = mesh1.point(vhandle1);
            Vector2d midpoint2d = 0.5 * (point2d0 + point2d1);
            Vector3d midpoint3d = 0.5 * (point3d0 + point3d1);
            Vector3d normal3d = mesh0.normal(mesh0.face_handle(segmentinfo.mesh0_fid_));
            normal3d *= (point3d1 - point3d0).length() * 0.05;
            Vector2d normal2d_project = cut_step2_trimesh_project(midpoint3d + normal3d, param) - midpoint2d;
            Vector2d normal2d = rotate90(point2d1 - point2d0);
            double ratio = normal2d_project.length() / normal2d.length();
            ratio_max = ratio_max < ratio ? ratio : ratio_max;
            ratio_min = ratio_min > ratio ? ratio : ratio_min;
            normal2d.normalize();
            if ((normal2d_project | normal2d) < 0)
                normal2d *= -1.;
            //Vector3d normal2d_unproject = cut_step2_trimesh_unproject(midpoint2d + normal_delta * normal2d) - midpoint3d;
            //const Vector3d& face_normal = mesh0.normal(mesh0.face_handle(segmentinfo.mesh0_fid_));
            //if (face_normal.dot_product(normal2d_unproject) < 0) normal2d *= -1.;
            edata.normal2d_ = normal2d;
            edata.dbg_normal3d_ = normal3d;
        } else {
            edata.type_ = Mesh1Traits::EDGE_BOUNDARY;
        }
    }
    // set face's barycenter2d
    for (Mesh1::FIter f = mesh1.faces_begin(); f != mesh1.faces_end(); ++f) {
        Vector2d& barycenter2d = mesh1.data(f).barycenter2d_;
        barycenter2d.set(0, 0);
        for (Mesh1::FVIter v = mesh1.fv_iter(f); v; ++v)
            barycenter2d += mesh1.data(v).point2d_;
        barycenter2d /= 3.;
    }
    // set 2 normals for each boundary vertex that needs to be split
    for (Mesh1::VIter v = mesh1.vertices_begin(); v != mesh1.vertices_end(); ++v) {
        mesh1.data(v).orientInfo_.normal2ds_.clear();
        mesh1.data(v).orientInfo_.outEdge2ds_.clear();
        mesh1.data(v).dbg_normal3ds_.clear();
    }
    for (Mesh1::EIter e = mesh1.edges_begin(); e != mesh1.edges_end(); ++e) {
        Mesh1::EdgeData& edata = mesh1.data(e);
        if (edata.type_ != Mesh1Traits::EDGE_BOUNDARY_SPLIT)
            continue;
        for (int i = 0; i < 2; ++i) {
            Mesh1::HHandle hhandle = mesh1.halfedge_handle(e, i);
            Mesh1::VHandle vhandle = mesh1.to_vertex_handle(hhandle);
            Mesh1::VertexData& vdata = mesh1.data(vhandle);
            if (vdata.type_ == Mesh1Traits::VERTEX_BOUNDARY_SPLIT) {
                vdata.orientInfo_.normal2ds_.push_back(edata.normal2d_);
                Vector2d outEdge2d = mesh1.data(mesh1.from_vertex_handle(hhandle)).point2d_ - mesh1.data(vhandle).point2d_;
                outEdge2d.normalize();
                vdata.orientInfo_.outEdge2ds_.push_back(outEdge2d);
                vdata.mesh0_id_ = edata.mesh0_id_;
                vdata.dbg_normal3ds_.push_back(edata.dbg_normal3d_);
            }
        }
    }
    for (Mesh1::VIter v = mesh1.vertices_begin(); v != mesh1.vertices_end(); ++v) {
        Mesh1::VertexData& vdata = mesh1.data(v);
        if (vdata.type_ != Mesh1Traits::VERTEX_BOUNDARY_SPLIT)
            continue;
        //assert (vdata.orientInfo_.normal2ds_.size() == 2);
        //if (vdata.orientInfo_.normal2ds_.size() != 2)
        //    cout << "vdata.orientInfo_.normal2ds_.size() != 2\n";
        double h0 = Util::calcArea(Vector2d(), vdata.orientInfo_.outEdge2ds_[0], vdata.orientInfo_.normal2ds_[0]);
        double h1 = Util::calcArea(Vector2d(), vdata.orientInfo_.outEdge2ds_[1], vdata.orientInfo_.normal2ds_[1]);
        //assert (h0 * h1 <= 0);
        //if (0 < h0 * h1)
        //    cout << "0 < h0 * h1\n";
        double t = Util::calcArea(Vector2d(), vdata.orientInfo_.outEdge2ds_[0], vdata.orientInfo_.outEdge2ds_[1]);
        vdata.orientInfo_.strategy_ = t < 0 ?
            (h0 < 0 ? Mesh1Traits::VertexOrientInfo::STRATEGY_AND : Mesh1Traits::VertexOrientInfo::STRATEGY_OR ) :
            (h0 < 0 ? Mesh1Traits::VertexOrientInfo::STRATEGY_OR  : Mesh1Traits::VertexOrientInfo::STRATEGY_AND);
    }
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2f_mesh1_mesh2   (VolumeObject& volObj, CutParam& param) {
    // convert Mesh1 to Mesh2 (split two-sided edges)
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    Mesh2& mesh2 = volObj.mesh2_;
    
    for (Mesh1::VIter v = mesh1.vertices_begin(); v != mesh1.vertices_end(); ++v) {    // add vertices
        Vector3d& point = mesh1.point(v);
        Mesh1::VertexData& vdata = mesh1.data(v);
        Vector3d d;
        if (vdata.type_ == Mesh1Traits::VERTEX_BOUNDARY_SPLIT) {
            assert(vdata.dbg_normal3ds_.size() == 2);
            d = vdata.dbg_normal3ds_[0] + vdata.dbg_normal3ds_[1];
            d.normalize();
            d *= DBG_EDGE_SPLIT_SIZE;
        }
        {   // front vertex
            Mesh2::VHandle mesh2_vhandle = mesh2.add_vertex(point + d);
            mesh2.data(mesh2_vhandle).type_    = (vdata.type_ == Mesh1Traits::VERTEX_INTERIOR) ? Mesh2Traits::VERTEX_INTERIOR : Mesh2Traits::VERTEX_BOUNDARY;
            mesh2.data(mesh2_vhandle).color_   = vdata.color_;
            vdata.mesh2_vid_ = mesh2_vhandle.idx();
        }
        if (vdata.type_ == Mesh1Traits::VERTEX_BOUNDARY_SPLIT) {   // split vertex by adding back vertex
            Mesh2::VHandle back_mesh2_vhandle = mesh2.add_vertex(point - d);
            mesh2.data(back_mesh2_vhandle).type_    = Mesh2Traits::VERTEX_BOUNDARY;
            mesh2.data(back_mesh2_vhandle).color_   = vdata.back_color_;
            vdata.back_mesh2_vid_ = back_mesh2_vhandle.idx();
        }
    }
    vector<Mesh2::VHandle> face_vhandle(3);
    for (Mesh1::FIter f = mesh1.faces_begin(); f != mesh1.faces_end(); ++f) {    // add faces
        Vector2d& barycenter2d = mesh1.data(f).barycenter2d_;
        Mesh1::FVIter v = mesh1.fv_iter(f);
        int side[3];
        int label = -2;
        for (int i = 0; i < 3; ++i, ++v) {
            Mesh1::VertexData& vdata = mesh1.data(v);
            if (vdata.type_ == Mesh1Traits::VERTEX_BOUNDARY_SPLIT) {
                Vector2d d = barycenter2d - vdata.point2d_;
                bool isFront;
                Mesh1Traits::VertexOrientInfo& orientInfo = vdata.orientInfo_;
                if (orientInfo.strategy_ == Mesh1Traits::VertexOrientInfo::STRATEGY_AND)
                    isFront = (d | orientInfo.normal2ds_[0]) > 0 && (d | orientInfo.normal2ds_[1]) > 0;
                else
                    isFront = (d | orientInfo.normal2ds_[0]) > 0 || (d | orientInfo.normal2ds_[1]) > 0;
                face_vhandle[i] = mesh2.vertex_handle(isFront ? vdata.mesh2_vid_ : vdata.back_mesh2_vid_);
                side[i] = isFront ? 1 : 2;
                int mesh0_id = vdata.mesh0_id_;         // set the region labels
                Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
                if (mesh0.isClosed_ && !isFront) {
                    int label_old = label;
                    label = mesh0.isHole_ ? -1 : mesh0_id;
                    assert(label_old == -2 || label_old == label);
                }
            } else {
                face_vhandle[i] = mesh2.vertex_handle(vdata.mesh2_vid_);
                side[i] = 0;
            }
        }
        Mesh2::FHandle fhandle = mesh2.add_face(face_vhandle);
        Mesh2::FaceData& fdata = mesh2.data(fhandle);
        fdata.label_ = label;
        mesh1.data(f).mesh2_fid_ = fhandle.idx();
    }
    for (Mesh2::EIter e = mesh2.edges_begin(); e != mesh2.edges_end(); ++e) {  // set edge type
        Mesh2Traits::EdgeType& type = mesh2.data(e).type_;
        type = Mesh2Traits::EDGE_INTERIOR;
        for (int i = 0; i < 2; ++i) {
            Mesh2::FHandle fhandle = mesh2.face_handle(mesh2.halfedge_handle(e, i));
            if (fhandle.idx() == -1) {
                type = Mesh2Traits::EDGE_BOUNDARY;
                break;
            }
        }
    }
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2g_mesh2label    (VolumeObject& volObj, CutParam& param) {
    // propagate Mesh2 face's label information
    Mesh2& mesh2 = volObj.mesh2_;
    bool changed;
    while (true) {
        cout << ".";
        changed = false;
        for (Mesh2::FIter f = mesh2.faces_begin(); f != mesh2.faces_end(); ++f) {
            Mesh2::FaceData& fdata = mesh2.data(f);
            if (fdata.label_ != -2)
                continue;
            for (Mesh2::FFIter ff = mesh2.ff_iter(f); ff; ++ff) {
                Mesh2::FaceData& ffdata = mesh2.data(ff);
                if (ffdata.label_ != -2) {
                    fdata.label_ = ffdata.label_;
                    changed = true;
                    break;
                }
            }
        }
        if (!changed)   // no more update
            break;
    }
    for (Mesh2::FIter f = mesh2.faces_begin(); f != mesh2.faces_end(); ++f) {
        Mesh2::FaceData& fdata = mesh2.data(f);
        if (fdata.label_ == -2)
            fdata.label_ = 0;
    }
}
template <class TPmvcAlgorithm>
void DiffusePmvcT<TPmvcAlgorithm>::cut_step2h_mesh2color    (VolumeObject& volObj, CutParam& param) {
    Mesh2& mesh2 = volObj.mesh2_;
    // compute color at each interior vertex using PMVC
    vector<Vector3d*> target_points;
    vector<Vector3d*> target_colors;
    target_points.reserve(mesh2.n_vertices());
    target_colors.reserve(mesh2.n_vertices());
    for (Mesh2::VIter v = mesh2.vertices_begin(); v != mesh2.vertices_end(); ++v) {
        Mesh2::VertexData& vdata = mesh2.data(v);
        if (vdata.type_ != Mesh2Traits::VERTEX_INTERIOR)
            continue;
        bool isHole = false;
        for (Mesh2::VFIter f = mesh2.vf_iter(v); f; ++f) {
            if (mesh2.data(f).label_ == -2) {
                isHole = true;
                break;
            }
        }
        if (isHole)
            continue;
        Vector3d& point = mesh2.point(v);
        Vector3d& color = vdata.color_;
        target_points.push_back(&point);
        target_colors.push_back(&color);
    }
    cout << "computing colors with PMVC (" << target_points.size() << " samples)\n";
    vector<Vector3d> pmvc_points(target_points.size());
    for (size_t i = 0; i < pmvc_points.size(); ++i)
        pmvc_points[i] = *target_points[i];
    vector<Vector3d> pmvc_colors = pmvc_.getColor(volObj.cutData_.pmvcInfo_, pmvc_points);
    for (size_t i = 0; i < pmvc_colors.size(); ++i)
        *target_colors[i] = pmvc_colors[i];
}
template <class TPmvcAlgorithm>
Vector2d DiffusePmvcT<TPmvcAlgorithm>::cut_step2_trimesh_project  (const Vector3d& point3d, CutParam& param) {
    if (param.mode_ == CutParam::FREEFORM) {
        size_t n_cutStroke = param.freeform_stroke3d_.size();
        Vector3d& eye = ogl.viewParam_.eyePoint_;
        Vector2d result;
        double dist_min = DBL_MAX;
        for (size_t i = 0; i < n_cutStroke - 1; ++i) {
            Vector3d& cut0 = param.freeform_stroke3d_[i];
            Vector3d& cut1 = param.freeform_stroke3d_[i + 1];
            Vector3d face[3] = { eye, cut0, cut1 };
            Vector3d& baryCoordTriangle = Util::calcBarycentricCoord<double,3, 3>(face, point3d);
            if (0 < i               && baryCoordTriangle[2] < 0)
                continue;
            if (i < n_cutStroke - 2 && baryCoordTriangle[1] < 0)
                continue;
            Vector3d projected = baryCoordTriangle[0] * eye + baryCoordTriangle[1] * cut0 + baryCoordTriangle[2] * cut1;
            double dist = (point3d - projected).length();
            if (dist_min < dist)
                continue;
            result.set((i + baryCoordTriangle[2] / (1 - baryCoordTriangle[0])) / (n_cutStroke - 1.), baryCoordTriangle[0]);
            dist_min = dist;
        }
        return result;
    } else if (param.mode_ == CutParam::SLICEX) {
        return Vector2d(point3d[2], point3d[1]);
    } else if (param.mode_ == CutParam::SLICEY) {
        return Vector2d(point3d[0], point3d[2]);
    } else if (param.mode_ == CutParam::SLICEZ) {
        return Vector2d(point3d[1], point3d[0]);
    } else {
        Vector2d zx(point3d[2], point3d[0]);
        double r = zx.length();
        if (r == 0)             // special case: point3d lies on y-axis
            return Vector2d(0, point3d[1]);
        double angle = atan2(zx[1], zx[0]);
        double diff_begin = DBL_MAX;
        double diff_end   = DBL_MAX;
        for (int i = -1; i <= 1; ++i) {
            diff_begin = min(abs(param.wedge_begin_ + i * 2 * M_PI - angle), diff_begin);
            diff_end   = min(abs(param.wedge_end_   + i * 2 * M_PI - angle), diff_end  );
        }
        Vector2d result(diff_begin < diff_end ? -r : r, point3d[1]);
        return result;
    }
}
template <class TPmvcAlgorithm>
Vector3d DiffusePmvcT<TPmvcAlgorithm>::cut_step2_trimesh_unproject(const Vector2d& point2d, CutParam& param) {
    if (param.mode_ == CutParam::FREEFORM) {
        size_t n_cutStroke = param.freeform_stroke3d_.size();
        double uScale = point2d[0] * (n_cutStroke - 1);
        int segmentID = static_cast<int>(uScale);
        if (segmentID       < 0        ) segmentID = 0;
        if (n_cutStroke - 2 < segmentID) segmentID = n_cutStroke - 2;
        double t1 = uScale - segmentID;
        double t0 = 1 - t1;
        Vector3d baryCoordTriangle;
        baryCoordTriangle[0] = point2d[1];
        baryCoordTriangle[1] = t0 * (1 - baryCoordTriangle[0]);
        baryCoordTriangle[2] = t1 * (1 - baryCoordTriangle[0]);
        Vector3d& eye = ogl.viewParam_.eyePoint_;
        Vector3d& cut0 = param.freeform_stroke3d_[segmentID];
        Vector3d& cut1 = param.freeform_stroke3d_[segmentID + 1];
        Vector3d point3d =
            baryCoordTriangle[0] * eye +
            baryCoordTriangle[1] * cut0 + 
            baryCoordTriangle[2] * cut1;
        return point3d;
    } else if (param.mode_ == CutParam::SLICEX) {
        return Vector3d(param.slice_top_, point2d[1], point2d[0]);
    } else if (param.mode_ == CutParam::SLICEY) {
        return Vector3d(point2d[0], param.slice_top_, point2d[1]);
    } else if (param.mode_ == CutParam::SLICEZ) {
        return Vector3d(point2d[1], point2d[0], param.slice_top_);
    } else {
        double r = abs(point2d[0]);
        double angle = point2d[0] < 0 ? param.wedge_begin_ : param.wedge_end_;
        Vector3d point3d(r * sin(angle), point2d[1], r * cos(angle));
        return point3d;
    }
}

template struct DiffusePmvcT<PmvcAlgorithm>;
