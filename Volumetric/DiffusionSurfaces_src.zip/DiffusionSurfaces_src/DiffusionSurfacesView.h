#pragma once


class CDiffusionSurfacesDoc;
class CDiffusionSurfacesView : public CView
{
protected:
	CDiffusionSurfacesView();
	DECLARE_DYNCREATE(CDiffusionSurfacesView)

public:
	CDiffusionSurfacesDoc* GetDocument() const;

	virtual void OnDraw(CDC* pDC);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

public:
	virtual ~CDiffusionSurfacesView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	DECLARE_MESSAGE_MAP()
public:
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
    afx_msg void OnDestroy();
public:
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
public:
    afx_msg void OnSize(UINT nType, int cx, int cy);
public:
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
public:
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
public:
    afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
public:
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
public:
    afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
public:
    afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
public:
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
    afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
public:
    afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
public:
    afx_msg void OnDropFiles(HDROP hDropInfo);
public:
    afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
};

#ifndef _DEBUG  
inline CDiffusionSurfacesDoc* CDiffusionSurfacesView::GetDocument() const
   { return reinterpret_cast<CDiffusionSurfacesDoc*>(m_pDocument); }
#endif

