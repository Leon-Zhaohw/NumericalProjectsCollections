#include "stdafx.h"
#include "DiffusionSurfaces.h"
#include "MainFrm.h"

#include "DiffusionSurfacesDoc.h"
#include "DiffusionSurfacesView.h"

#include "Core.h"
#include "StateCsVrt.h"
#include "StateBrowse.h"
#include "StateSalad.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace {
Core& core = Core::getInstance();
}


// CDiffusionSurfacesApp

BEGIN_MESSAGE_MAP(CDiffusionSurfacesApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, &CDiffusionSurfacesApp::OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, &CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
    ON_COMMAND(ID_STEP_NEXT, &CDiffusionSurfacesApp::OnStepNext)
    ON_UPDATE_COMMAND_UI(ID_STEP_NEXT, &CDiffusionSurfacesApp::OnUpdateStepNext)
    ON_COMMAND(ID_MODE_MODELING, &CDiffusionSurfacesApp::OnModeModeling)
    ON_UPDATE_COMMAND_UI(ID_MODE_MODELING, &CDiffusionSurfacesApp::OnUpdateModeModeling)
    ON_COMMAND(ID_MODE_BROWSING, &CDiffusionSurfacesApp::OnModeBrowsing)
    ON_UPDATE_COMMAND_UI(ID_MODE_BROWSING, &CDiffusionSurfacesApp::OnUpdateModeBrowsing)
    ON_COMMAND(ID_TOOLBAR_STEP, &CDiffusionSurfacesApp::OnToolbarStep)
    ON_UPDATE_COMMAND_UI(ID_TOOLBAR_STEP, &CDiffusionSurfacesApp::OnUpdateToolbarStep)
    ON_COMMAND(ID_STEP_HOME, &CDiffusionSurfacesApp::OnStepHome)
    ON_UPDATE_COMMAND_UI(ID_STEP_HOME, &CDiffusionSurfacesApp::OnUpdateStepHome)
    ON_COMMAND(ID_MODE_SALAD, &CDiffusionSurfacesApp::OnModeSalad)
    ON_UPDATE_COMMAND_UI(ID_MODE_SALAD, &CDiffusionSurfacesApp::OnUpdateModeSalad)
END_MESSAGE_MAP()


CDiffusionSurfacesApp::CDiffusionSurfacesApp() {
    core.app_ = this;
}

CDiffusionSurfacesApp theApp;


BOOL CDiffusionSurfacesApp::InitInstance()
{
	CWinApp::InitInstance();

	SetRegistryKey(_T("Diffusion Surfaces demo"));
	LoadStdProfileSettings(0);
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CDiffusionSurfacesDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CDiffusionSurfacesView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);



	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);


	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV

protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

void CDiffusionSurfacesApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


void CDiffusionSurfacesApp::OnStepNext() {
    core.ogl_.makeOpenGLCurrent();
    core.state_->finalize();
    core.state_ = core.state_->next();
    core.state_->initialize();
    core.ogl_.RedrawWindow();
}

void CDiffusionSurfacesApp::OnUpdateStepNext(CCmdUI *pCmdUI) {
    pCmdUI->Enable(core.state_->isReady());
}

void CDiffusionSurfacesApp::OnStepHome() {
    core.ogl_.makeOpenGLCurrent();
    core.state_->finalize();
    core.state_ = StateCsVrt::getInstance();
    core.state_->initialize();
    core.ogl_.RedrawWindow();
}

void CDiffusionSurfacesApp::OnUpdateStepHome(CCmdUI *pCmdUI) {
    pCmdUI->Enable(core.state_ != StateBrowse::getInstance() && core.state_ != StateSalad::getInstance() && core.state_ != StateCsVrt::getInstance());
}

void CDiffusionSurfacesApp::OnModeModeling() {
    core.ogl_.makeOpenGLCurrent();
    core.state_->finalize();
    core.state_ = StateCsVrt::getInstance();
    core.state_->initialize();
    core.ogl_.RedrawWindow();
}

void CDiffusionSurfacesApp::OnUpdateModeModeling(CCmdUI *pCmdUI) {
    pCmdUI->SetCheck(core.state_ != StateBrowse::getInstance() && core.state_ != StateSalad::getInstance());
}

void CDiffusionSurfacesApp::OnModeBrowsing() {
    core.ogl_.makeOpenGLCurrent();
    core.state_->finalize();
    core.state_ = StateBrowse::getInstance();
    core.state_->initialize();
    core.ogl_.RedrawWindow();
}

void CDiffusionSurfacesApp::OnUpdateModeBrowsing(CCmdUI *pCmdUI) {
    pCmdUI->SetCheck(core.state_ == StateBrowse::getInstance());
}

void CDiffusionSurfacesApp::OnToolbarStep() {
    CMainFrame& mainFrm = *core.mainFrm_;
	bool b = mainFrm.wndToolBar_step_.IsWindowVisible() == TRUE;
	mainFrm.ShowControlBar(&mainFrm.wndToolBar_step_, !b, true);
}

void CDiffusionSurfacesApp::OnUpdateToolbarStep(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(core.mainFrm_->wndToolBar_step_.IsWindowVisible());
}


void CDiffusionSurfacesApp::OnModeSalad() {
    core.ogl_.makeOpenGLCurrent();
    core.state_->finalize();
    core.state_ = StateSalad::getInstance();
    core.state_->initialize();
    core.ogl_.RedrawWindow();
}

void CDiffusionSurfacesApp::OnUpdateModeSalad(CCmdUI *pCmdUI)
{
    pCmdUI->SetCheck(core.state_ == StateSalad::getInstance());
}
