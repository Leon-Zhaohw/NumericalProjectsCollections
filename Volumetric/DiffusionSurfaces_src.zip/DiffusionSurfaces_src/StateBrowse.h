#pragma once
#include <vector>
#include "state.h"
#include "Core.h"

class StateBrowse : public State {
    StateBrowse(void);
    ~StateBrowse(void) {}
public:
    static StateBrowse* getInstance() {
        static StateBrowse p;
        return &p;
    }
    void initialize();
    void draw();
    std::string message() { return "Browsing mode"; }
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMButtonDown(UINT nFlags, CPoint& point);
    void OnMButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    void OnDropFiles  (const std::string& fname, const std::string& ext);

    bool showSilhouette_;
    bool showNoise_;
    bool showAllMesh_;
    bool showEdge_;
    bool onDrawCompute_;
    int  currentMeshID_;
    double paramDelta_;
    
    /* [Rules for surface visibility]
    Mesh0& mesh0 = volObj_.mesh0s_[i];
    Mesh3& mesh3 = volObj_.mesh3s_[i];
    int flag_showHole = flag_showHole_[i];
    
    [before cutting]
    if (mesh0.isOutermost_)
        draw mesh0
    
    [after cutting]
    if (mesh.isOutermost_)
        draw mesh3
    else if (!mesh.isClosed_)
        continue;
    else if (mesh.isHole_)
        draw mesh3 with opposite color
    else if (flag_show_mesh == SHOW_MESH0)
        draw mesh0 with opposite color
    else if (flag_show_mesh == SHOW_MESH3)
        draw mesh3 with opposite color
    else if (flag_show_mesh == SHOW_MESH2)
        continue;
    */
};
