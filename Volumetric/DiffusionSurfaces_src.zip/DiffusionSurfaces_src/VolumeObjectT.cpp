#include "StdAfx.h"
#include "VolumeObjectT.h"
#include "Core.h"
#include "Piece.h"
#include <tinyxml.h>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::gl_init() {
    noiseWeight_.gl_init();
    cutData_    .gl_init();
    silRenderer_.gl_init();
}
template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::gl_deinit() {
    noiseWeight_.gl_deinit();
    cutData_    .gl_deinit();
    silRenderer_.gl_deinit();
}
template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::calcAuxiliaryInfo() {
    processBlur();
    
    // bbox_, srfMeshes_[i].mesh0_.isOutermost_
    bbox_.init();
    int mesh0_outermost = -1;
    for (size_t i = 0; i < srfMeshes_.size(); ++i) {
        srfMeshes_[i].mesh0_.isOutermost_ = false;
        srfMeshes_[i].mesh0_.calcAuxiliaryInfo();
        Vector3d bbox_max_old = bbox_.max_;
        bbox_.max_ = bbox_.max_.pairwiseMax(srfMeshes_[i].mesh0_.bbox_.max_);
        if (bbox_.max_ != bbox_max_old)
            mesh0_outermost = i;
        bbox_.min_ = bbox_.min_.pairwiseMin(srfMeshes_[i].mesh0_.bbox_.min_);
    }
    srfMeshes_[mesh0_outermost].mesh0_.isOutermost_ = true;
    for (size_t i = 0; i < srfMeshes_.size(); ++i) {
        Mesh0& mesh0 = srfMeshes_[i].mesh0_;
        SrfMesh::ShowFlag& flag = srfMeshes_[i].showFlag_;
        flag.srf_ = (mesh0.isOutermost_ || mesh0.isHole_) ? SrfMesh::ShowFlag::MESH3 : SrfMesh::ShowFlag::NONE;
        flag.cs_  = !mesh0.isHole_;
    }

    ogl.makeOpenGLCurrent();
    cutData_.preprocess(*this);
}

template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::processBlur() {
    vector<SrfMesh> srfMeshes_old = srfMeshes_;
    srfMeshes_.clear();
    srfMeshes_.reserve(srfMeshes_old.size() * 2);
    for (size_t i = 0; i < srfMeshes_old.size(); ++i) {
        Mesh0& mesh0 = srfMeshes_old[i].mesh0_;
        if (!mesh0.hasBlur_) {
            srfMeshes_.push_back(SrfMesh());
            srfMeshes_.back().mesh0_ = mesh0;
            continue;
        }
        Mesh0 mesh0_front = mesh0;
        Mesh0 mesh0_back  = mesh0;
        mesh0_front.isTwoSided_ = mesh0_back.isTwoSided_ = false;
        mesh0_front.hasBlur_    = mesh0_back.hasBlur_    = false;
        Mesh0::VIter v_it       = mesh0      .vertices_begin();
        Mesh0::VIter v_it_front = mesh0_front.vertices_begin();
        Mesh0::VIter v_it_back  = mesh0_back .vertices_begin();
        for (; v_it != mesh0.vertices_end(); ++v_it, ++v_it_front, ++v_it_back) {
            Mesh0::VertexData& vdata       = mesh0      .data(v_it);
            Mesh0::VertexData& vdata_front = mesh0_front.data(v_it_front);
            Mesh0::VertexData& vdata_back  = mesh0_back .data(v_it_back);
            // offset vector
            double blurValue = vdata.blurValue_;
            assert(0 < blurValue);
            Vector3d offset = mesh0.normal(v_it);
            offset *= blurValue;
            mesh0_front.point(v_it_front) += offset;
            mesh0_back .point(v_it_back ) -= offset;
            vdata_front.color_ = vdata_front.back_color_ = vdata.color_;
            vdata_back .color_ = vdata_back .back_color_ = vdata.back_color_;
            vdata_front.blurValue_ = vdata_back.blurValue_ = 0;
        }
        assert(v_it_front == mesh0_front.vertices_end());
        assert(v_it_back  == mesh0_back .vertices_end());
        mesh0_front.update_normals();
        mesh0_back .update_normals();
        srfMeshes_.push_back(SrfMesh());
        srfMeshes_.back().mesh0_ = mesh0_front;
        srfMeshes_.push_back(SrfMesh());
        srfMeshes_.back().mesh0_ = mesh0_back;
    }
}

template <class TDiffuseAlgorithm>
Piece VolumeObjectT<TDiffuseAlgorithm>::convertToPiece() const {
    Piece piece;
    // copy Mesh2 from volumeObject considering the show/hide flag for each face
    Mesh2& mesh2 = piece.mesh2_;
    const Mesh2& mesh2_orig = mesh2_;
    for (Mesh2::CVIter v_it = mesh2_orig.vertices_begin(); v_it != mesh2_orig.vertices_end(); ++v_it) {
        Mesh2::VHandle vhandle = mesh2.add_vertex(mesh2_orig.point(v_it));
        mesh2.data(vhandle) = mesh2_orig.data(v_it);
    }
    for (Mesh2::CFIter f_it = mesh2_orig.faces_begin(); f_it != mesh2_orig.faces_end(); ++f_it) {
        int label = mesh2_orig.data(f_it).label_;
        if (label == -1)    // hole
            continue;
        if (!srfMeshes_[label].showFlag_.cs_) // set as hidden
            continue;
        vector<Mesh2::VHandle> face_vhandles(3);
        Mesh2::CFVIter fv_it = mesh2_orig.cfv_iter(f_it);
        for (int i = 0; i < 3; ++i, ++fv_it)
            face_vhandles[i] = mesh2.vertex_handle(fv_it.handle().idx());
        mesh2.add_face(face_vhandles);
    }
    // copy Mesh0/Mesh3 from volumeObject considering the ShowFlag
    for (size_t meshid = 0; meshid < srfMeshes_.size(); ++meshid) {
        const SrfMesh& srfMesh = srfMeshes_[meshid];
        if (srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::NONE)
            continue;
        const Mesh0& mesh0 = srfMesh.mesh0_;
        const Mesh3& mesh3 = srfMesh.mesh3_;
        if (srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::MESH0 || srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::MESH0_OPPOSITE) {    // add mesh0 converted to meseh3
            bool isOpposite = srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::MESH0_OPPOSITE;
            Mesh3 mesh3_new;
            for (Mesh0::CVIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
                Mesh3::VHandle vhandle = mesh3_new.add_vertex(mesh0.point(v_it));
                const Mesh0::VertexData& mesh0vdata = mesh0    .data(v_it);
                Mesh3::VertexData& mesh3vdata = mesh3_new.data(vhandle);
                mesh3vdata.color_      = isOpposite ? mesh0vdata.back_color_ : mesh0vdata.color_;
                mesh3vdata.back_color_ = isOpposite ? mesh0vdata.color_      : mesh0vdata.back_color_;
            }
            for (Mesh0::CFIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
                vector<Mesh3::VHandle> face_vhandles(3);
                Mesh0::CFVIter fv_it = mesh0.cfv_iter(f_it);
                for (int i = 0; i < 3; ++i, ++fv_it)
                    face_vhandles[i] = mesh3_new.vertex_handle(fv_it.handle().idx());
                mesh3_new.add_face(face_vhandles);
            }
            piece.mesh3s_.push_back(mesh3_new);
        } else if (srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::MESH3) {
            piece.mesh3s_.push_back(mesh3);
        } else {    // srfMesh.showFlag_.srf_ == SrfMesh::ShowFlag::MESH3_OPPOSITE
            Mesh3 mesh3_new = mesh3;
            for (int i = 0; i < mesh3.n_vertices(); ++i) {
                const Mesh3::VertexData& vdata = mesh3.data(mesh3.vertex_handle(i));
                Mesh3::VertexData& vdata_new = mesh3_new.data(mesh3_new.vertex_handle(i));
                vdata_new.color_      = vdata.back_color_;  // flip color
                vdata_new.back_color_ = vdata.color_;
            }
            piece.mesh3s_.push_back(mesh3_new);
        }
    }
    piece.curves_ = silRenderer_.curves3d_fixed_;
    piece.noiseWeight_ = noiseWeight_;

    return piece;
}

template <class TDiffuseAlgorithm>
bool VolumeObjectT<TDiffuseAlgorithm>::loadXML(const char* fname) {
    // load
    TiXmlDocument doc;
    if (!doc.LoadFile(fname))
        return false;
    // mesh_list
    TiXmlElement* elem_mesh_list = doc.FirstChildElement("mesh_list");
    int mesh_list_size;
    elem_mesh_list->QueryIntAttribute("size", &mesh_list_size);
    srfMeshes_.clear();
    srfMeshes_.reserve(mesh_list_size);
    for (TiXmlElement* elem_mesh = elem_mesh_list->FirstChildElement("mesh"); elem_mesh; elem_mesh = elem_mesh->NextSiblingElement()) {
        // mesh
        srfMeshes_.push_back(SrfMesh());
        Mesh0& mesh = srfMeshes_.back().mesh0_;
        int isTwoSided, isHole, hasBlur;
        elem_mesh->QueryIntAttribute("is_two_sided", &isTwoSided);
        elem_mesh->QueryIntAttribute("is_hole",      &isHole);
        elem_mesh->QueryIntAttribute("has_blur",     &hasBlur);
        mesh.isTwoSided_ = isTwoSided != 0;
        mesh.isHole_     = isHole     != 0;
        mesh.hasBlur_    = hasBlur    != 0;
        // vertex_list
        TiXmlElement* elem_vertex_list = elem_mesh->FirstChildElement("vertex_list");
        int vertex_list_size;
        elem_vertex_list->QueryIntAttribute("size", &vertex_list_size);
        for (TiXmlElement* elem_vertex = elem_vertex_list->FirstChildElement("vertex"); elem_vertex; elem_vertex = elem_vertex->NextSiblingElement()) {
            // vertex position
            Vector3d point;
            elem_vertex->QueryDoubleAttribute("x", &point[0]);
            elem_vertex->QueryDoubleAttribute("y", &point[1]);
            elem_vertex->QueryDoubleAttribute("z", &point[2]);
            //point += Vector3d(0.01, 0, 0);        // why does this cause a problem?
            Mesh0::VHandle vhandle = mesh.add_vertex(point);
            Mesh0::VertexData& vdata = mesh.data(vhandle);
            // color
            Vector3d& color      = vdata.color_;
            Vector3d& back_color = vdata.back_color_;
            if (isTwoSided) {
                elem_vertex->QueryDoubleAttribute("front_r", &color[0]);
                elem_vertex->QueryDoubleAttribute("front_g", &color[1]);
                elem_vertex->QueryDoubleAttribute("front_b", &color[2]);
                elem_vertex->QueryDoubleAttribute("back_r", &back_color[0]);
                elem_vertex->QueryDoubleAttribute("back_g", &back_color[1]);
                elem_vertex->QueryDoubleAttribute("back_b", &back_color[2]);
            } else {
                elem_vertex->QueryDoubleAttribute("r", &color[0]);
                elem_vertex->QueryDoubleAttribute("g", &color[1]);
                elem_vertex->QueryDoubleAttribute("b", &color[2]);
                back_color = color;
            }
            // blur
            double& blurValue = vdata.blurValue_;
            if (hasBlur)
                elem_vertex->QueryDoubleAttribute("blur_value", &blurValue);
        }
        assert(mesh.n_vertices() == vertex_list_size);
        // face_list
        TiXmlElement* elem_face_list = elem_mesh->FirstChildElement("face_list");
        int face_list_size;
        elem_face_list->QueryIntAttribute("size", &face_list_size);
        vector<Mesh0::VHandle> vhandles;
        vhandles.reserve(vertex_list_size);
        for (Mesh0::VIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
            vhandles.push_back(v_it.handle());
        vector<Mesh0::VHandle> face_vhandles(3);
        for (TiXmlElement* elem_face = elem_face_list->FirstChildElement("face"); elem_face; elem_face = elem_face->NextSiblingElement()) {
            // face
            int face_vid[3];
            elem_face->QueryIntAttribute("vid0", &face_vid[0]);
            elem_face->QueryIntAttribute("vid1", &face_vid[1]);
            elem_face->QueryIntAttribute("vid2", &face_vid[2]);
            for (int i = 0; i < 3; ++i) face_vhandles[i] = vhandles[face_vid[i]];
            mesh.add_face(face_vhandles);
        }
        assert(mesh.n_faces() == face_list_size);
        // use OpenMesh feature of normal calculation
        mesh.request_face_normals();
        mesh.request_vertex_normals();
        mesh.update_normals();
    }
    assert(srfMeshes_.size() == mesh_list_size);
    silRenderer_.clear();
    
    return true;
}

template <class TDiffuseAlgorithm>
bool VolumeObjectT<TDiffuseAlgorithm>::saveXML(const char* fname) const {
    /*
    <mesh_list size="2">
        <mesh is_two_sided="0" is_hole="0">
            <vertex_list size="100">
                <vertex x="" y="" z="" r="" g="" b=""/>
                ...
            </vertex_list>
            <face_list size="100">
                <face vid0="" vid1="" vid2=""/>
                <face vid0="" vid1="" vid2=""/>
                ...
            </face_list>
        </mesh>
        <mesh is_two_sided="1" is_hole="0" n_vertices="150" n_faces="250">
            <vertex x="" y="" z="" front_r="" front_g="" front_b="" back_r="" back_g="" back_b=""/>
            ...
            <face vid0="" vid1="" vid2=""/>
            <face vid0="" vid1="" vid2=""/>
            ...
        </mesh>
        ...
    </mesh_list>
    */
    
    // std::list to store TiXmlElement instances in the heap
    TiXmlDocument doc;
    TiXmlDeclaration* decl = new TiXmlDeclaration("1.0", "", "");
    doc.LinkEndChild(decl);
    // mesh_list
    TiXmlElement* elem_mesh_list = new TiXmlElement("mesh_list");
    doc.LinkEndChild(elem_mesh_list);
    elem_mesh_list->SetAttribute("size", srfMeshes_.size());
    for (size_t i = 0; i < srfMeshes_.size(); ++i) {
        // mesh
        const Mesh0& mesh = srfMeshes_[i].mesh0_;
        TiXmlElement* elem_mesh = new TiXmlElement("mesh");
        elem_mesh_list->LinkEndChild(elem_mesh);
        elem_mesh->SetAttribute("is_two_sided", mesh.isTwoSided_ ? 1 : 0);
        elem_mesh->SetAttribute("is_hole",      mesh.isHole_     ? 1 : 0);
        elem_mesh->SetAttribute("has_blur",     mesh.hasBlur_    ? 1 : 0);
        // vertex_list
        TiXmlElement* elem_vertex_list = new TiXmlElement("vertex_list");
        elem_mesh->LinkEndChild(elem_vertex_list);
        elem_vertex_list->SetAttribute("size", mesh.n_vertices());
        for (Mesh0::CVIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it) {
            const Mesh0::VertexData& vdata = mesh.data(v_it);
            // vertex position
            const Vector3d& point = mesh.point(v_it);
            TiXmlElement* elem_vertex = new TiXmlElement("vertex");
            elem_vertex_list->LinkEndChild(elem_vertex);
            elem_vertex->SetDoubleAttribute("x", point[0]);
            elem_vertex->SetDoubleAttribute("y", point[1]);
            elem_vertex->SetDoubleAttribute("z", point[2]);
            // color
            const Vector3d& color       = vdata.color_;
            const Vector3d& back_color  = vdata.back_color_;
            if (mesh.isTwoSided_) {
                elem_vertex->SetDoubleAttribute("front_r", color[0]);
                elem_vertex->SetDoubleAttribute("front_g", color[1]);
                elem_vertex->SetDoubleAttribute("front_b", color[2]);
                elem_vertex->SetDoubleAttribute("back_r", back_color[0]);
                elem_vertex->SetDoubleAttribute("back_g", back_color[1]);
                elem_vertex->SetDoubleAttribute("back_b", back_color[2]);
            } else {
                elem_vertex->SetDoubleAttribute("r", color[0]);
                elem_vertex->SetDoubleAttribute("g", color[1]);
                elem_vertex->SetDoubleAttribute("b", color[2]);
            }
            if (mesh.hasBlur_)
                elem_vertex->SetDoubleAttribute("blur_value", vdata.blurValue_);
        }
        // face_list
        TiXmlElement* elem_face_list = new TiXmlElement("face_list");
        elem_mesh->LinkEndChild(elem_face_list);
        elem_face_list->SetAttribute("size", mesh.n_faces());
        for (Mesh0::CFIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it) {
            // face
            TiXmlElement* elem_face = new TiXmlElement("face");
            elem_face_list->LinkEndChild(elem_face);
            Mesh0::CFVIter fv_it = mesh.cfv_iter(f_it);
            elem_face->SetAttribute("vid0", fv_it.handle().idx());    ++fv_it;
            elem_face->SetAttribute("vid1", fv_it.handle().idx());    ++fv_it;
            elem_face->SetAttribute("vid2", fv_it.handle().idx());    ++fv_it;
            assert(!fv_it);
        }
    }
    return doc.SaveFile(fname);
}

template <class TDiffuseAlgorithm>
bool VolumeObjectT<TDiffuseAlgorithm>::loadDSS(const char* fname) {
    ifstream ifs;
    ifs.open(fname, ios::binary);
    if (!ifs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    //ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    
    size_t mesh_list_size;
    ifs.read((char*)&mesh_list_size, sizeof(size_t));
    srfMeshes_.clear();
    srfMeshes_.reserve(mesh_list_size);
    for (size_t meshid = 0; meshid < mesh_list_size; ++meshid) {
        // mesh
        srfMeshes_.push_back(SrfMesh());
        Mesh0& mesh = srfMeshes_.back().mesh0_;
        ifs.read((char*)&mesh.isTwoSided_, sizeof(bool));
        ifs.read((char*)&mesh.isHole_,     sizeof(bool));
        ifs.read((char*)&mesh.hasBlur_,    sizeof(bool));
        // vertex_list
        int n_vertices;
        ifs.read((char*)&n_vertices, sizeof(int));
        for (size_t v_idx = 0; v_idx < n_vertices; ++v_idx) {
            // vertex position
            Vector3f point;
            ifs.read((char*)&point, sizeof(Vector3f));
            Mesh0::VHandle vhandle = mesh.add_vertex(point.convert<double>());
            Mesh0::VertexData& vdata = mesh.data(vhandle);
            // color
            Vector3f color;
            Vector3f back_color;
            if (mesh.isTwoSided_) {
                ifs.read((char*)&color,      sizeof(Vector3f));
                ifs.read((char*)&back_color, sizeof(Vector3f));
                vdata.color_      = color.     convert<double>();
                vdata.back_color_ = back_color.convert<double>();
            } else {
                ifs.read((char*)&color, sizeof(Vector3f));
                vdata.color_ = vdata.back_color_ = color.convert<double>();
            }
            // blur
            if (mesh.hasBlur_) {
                float blurValue;
                ifs.read((char*)&blurValue, sizeof(float));
                vdata.blurValue_ = static_cast<double>(blurValue);
            }
        }
        // face_list
        int n_faces;
        ifs.read((char*)&n_faces, sizeof(int));
        vector<Mesh0::VHandle> vhandles;
        vhandles.reserve(mesh.n_vertices());
        for (Mesh0::VIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it)
            vhandles.push_back(v_it.handle());
        vector<Mesh0::VHandle> face_vhandles(3);
        for (size_t f_idx = 0; f_idx < n_faces; ++f_idx) {
            // face
            int face_vid[3];
            ifs.read((char*)face_vid, sizeof(int) * 3);
            for (int i = 0; i < 3; ++i)
                face_vhandles[i] = vhandles[face_vid[i]];
            mesh.add_face(face_vhandles);
        }
        // use OpenMesh feature of normal calculation
        mesh.request_face_normals();
        mesh.request_vertex_normals();
        mesh.update_normals();
    }
    assert(srfMeshes_.size() == mesh_list_size);
    silRenderer_.clear();
    
    return true;
}

template <class TDiffuseAlgorithm>
bool VolumeObjectT<TDiffuseAlgorithm>::saveDSS(const char* fname) const {
    ofstream ofs;
    ofs.open(fname, ios::trunc | ios::binary);
    if (!ofs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    
    // mesh_list
    size_t mesh_list_size = srfMeshes_.size();
    ofs.write((char*)&mesh_list_size, sizeof(size_t));
    for (size_t i = 0; i < srfMeshes_.size(); ++i) {
        // mesh
        const Mesh0& mesh = srfMeshes_[i].mesh0_;
        ofs.write((char*)&mesh.isTwoSided_, sizeof(bool));
        ofs.write((char*)&mesh.isHole_,     sizeof(bool));
        ofs.write((char*)&mesh.hasBlur_,    sizeof(bool));
        // vertex_list
        int n_vertices = mesh.n_vertices();
        ofs.write((char*)&n_vertices, sizeof(int));
        for (Mesh0::CVIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it) {
            const Mesh0::VertexData& vdata = mesh.data(v_it);
            // vertex position
            Vector3f& point = mesh.point(v_it).convert<float>();
            ofs.write((char*)&point, sizeof(Vector3f));
            // color
            Vector3f& color      = vdata.color_.     convert<float>();
            Vector3f& back_color = vdata.back_color_.convert<float>();
            if (mesh.isTwoSided_) {
                ofs.write((char*)&color,      sizeof(Vector3f));
                ofs.write((char*)&back_color, sizeof(Vector3f));
            } else {
                ofs.write((char*)&color,      sizeof(Vector3f));
            }
            if (mesh.hasBlur_) {
                float blurValue = static_cast<float>(vdata.blurValue_);
                ofs.write((char*)&blurValue, sizeof(float));
            }
        }
        // face_list
        int n_faces = mesh.n_faces();
        ofs.write((char*)&n_faces, sizeof(int));
        for (Mesh0::CFIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it) {
            // face
            for (Mesh0::CFVIter fv_it = mesh.cfv_iter(f_it); fv_it; ++fv_it) {
                int fv_idx = fv_it.handle().idx();
                ofs.write((char*)&fv_idx, sizeof(int));
            }
        }
    }
    return true;
}

template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::calcSilhouetteCurves() {
    for (size_t j = 0; j < srfMeshes_.size(); ++j) {
        const SrfMesh::ShowFlag::Srf& srf = srfMeshes_[j].showFlag_.srf_;
        if (srf == SrfMesh::ShowFlag::MESH0 || srf == SrfMesh::ShowFlag::MESH0_OPPOSITE || !cutDone_)
            silRenderer_.addSilhouette(srfMeshes_[j].mesh0_);
        else
            silRenderer_.addSilhouette(srfMeshes_[j].mesh3_);
    }
}

template <class TDiffuseAlgorithm>
void VolumeObjectT<TDiffuseAlgorithm>::renderSceneDepth() const {
    for (size_t j = 0; j < srfMeshes_.size(); ++j) {
        const SrfMesh::ShowFlag::Srf& srf = srfMeshes_[j].showFlag_.srf_;
        if (srf == SrfMesh::ShowFlag::MESH0 || srf == SrfMesh::ShowFlag::MESH0_OPPOSITE || !cutDone_)
            silRenderer_.renderDepth(srfMeshes_[j].mesh0_);
        else
            silRenderer_.renderDepth(srfMeshes_[j].mesh3_);
    }
    silRenderer_.renderDepth(mesh2_);
}

template struct VolumeObjectT<DiffuseAlgorithm>;
