#pragma once
#include "CutParam.h"

template <class TDiffuseAlgorithm>
struct VolumeObjectT;

struct Mesh0;
struct Mesh1;
struct Mesh3;

template <class TDiffuseAlgorithm>
struct CutAlgorithmT {
    typedef VolumeObjectT<TDiffuseAlgorithm> VolumeObject;
    TDiffuseAlgorithm diffuseAlgorithm_;
    CutParam param_;

    void gl_init() { diffuseAlgorithm_.gl_init(); }
    void gl_deinit() { diffuseAlgorithm_.gl_deinit(); }
    void cut(VolumeObject& volObj);
    void cut_step1_cutValue    (VolumeObject& volObj);
    void cut_step1_cutValue_sub(Mesh0& mesh0);
    void cut_step3_mesh3    (VolumeObject& volObj);
    void cut_step3_mesh3_sub(VolumeObject& volObj, Mesh0& mesh0, Mesh3& mesh3);
    void           calcWedgeLine    (VolumeObject& volObj);
    KLIB::Vector3d calcWedgeLine_sub(Mesh1& mesh1, int edge_id);
};
