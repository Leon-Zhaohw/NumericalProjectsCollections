#pragma once
#include <KLIB/Vector.h>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

// Mesh2: cross-sectional triangle mesh 
struct Mesh2Traits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3d Point;
    typedef KLIB::Vector3d Normal;
    enum VertexType { VERTEX_INTERIOR, VERTEX_BOUNDARY };
    VertexTraits {
    public:
        VertexType type_;
        KLIB::Vector3d color_;
        VertexT() : type_(VERTEX_INTERIOR) {}
        // debug
        int              dbg_id_;
        std::vector<int> dbg_vf_;
        std::vector<int> dbg_ve_;
        std::vector<int> dbg_vv_;
    };
    enum EdgeType { EDGE_INTERIOR, EDGE_BOUNDARY };
    EdgeTraits {
    public:
        EdgeType type_;
        EdgeT() : type_(EDGE_INTERIOR) {}
        // debug
        int              dbg_id_;
        std::vector<int> dbg_ev_;
        std::vector<int> dbg_ef_;
    };
    FaceTraits {
    public:
        int label_;         // this face belongs to (label_ == -2 ? undetermined : label_ == -1 ? empty : mesh0s_[label_])
        FaceT() : label_(0) {}
        bool isHidden() const { return label_ == -1; }
        // debug
        int              dbg_id_;
        int              dbg_cnt_;
        std::vector<int> dbg_fv_;
        std::vector<int> dbg_fe_;
        std::vector<int> dbg_ff_;
        std::vector<int> dbg_side_;
    };
};
//typedef OpenMesh::TriMesh_ArrayKernelT<Mesh2Traits> Mesh2;
struct Mesh2 : public OpenMesh::TriMesh_ArrayKernelT<Mesh2Traits> {};
