#include "StdAfx.h"
#include "Core.h"
#include "NoiseWeight.h"
#include <fstream>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

void NoiseWeight::gl_init() {
    gl_deinit();
    glGenTextures(2, texID_);
}
void NoiseWeight::gl_deinit() {
    if (texID_[0] != 0) {
        glDeleteTextures(2, texID_);
        texID_[0] = texID_[1] = 0;
    }
}
void NoiseWeight::clear() {
    resolution_ = 0;
    data_[0].clear();
    data_[1].clear();
}
void NoiseWeight::resize(int resolution, const KLIB::Vector8uc& weight) {
    resolution_ = resolution;
    int N = resolution;
    for (int i = 0; i < 2; ++i)
        data_[i].resize(N * N * N, Vector4uc(&weight[4 * i]));
}
bool NoiseWeight::load(const char* fname) {
    // load 3d texture as a table associating RGB colors and weights for each frequency octave
    ifstream ifs;
    ifs.open(fname, ios::binary);
    if (!ifs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    int N;
    ifs.read((char*)&N, sizeof(int));
    resize(N);
    ifs.read((char*)&data_[0][0], N * N * N * sizeof(Vector4uc));
    ifs.read((char*)&data_[1][0], N * N * N * sizeof(Vector4uc));
    transferToGpu();
    return true;
}
void NoiseWeight::setDefault() {
    clear();
    resize(32, Vector8uc(16, 64, 32, 16, 8, 4, 2, 1));
    transferToGpu();
}
void NoiseWeight::transferToGpu() const {
    const int& N = resolution_;
    ogl.makeOpenGLCurrent();
    
    glBindTexture(GL_TEXTURE_3D, texID_[0]);
    glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA, N, N, N, 0, GL_RGBA, GL_UNSIGNED_BYTE, &data_[0][0]);
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE );
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
    glBindTexture(GL_TEXTURE_3D, texID_[1]);
    glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA, N, N, N, 0, GL_RGBA, GL_UNSIGNED_BYTE, &data_[1][0]);
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE );
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
    glBindTexture(GL_TEXTURE_3D, 0);
}
