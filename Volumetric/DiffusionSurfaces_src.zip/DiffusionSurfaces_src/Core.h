// DiffusionSurfaces Core class
#pragma once
#include <gl/glew.h>
#include <KLIB/OGL.h>
#include <KLIB/GLSLUtil.h>
#include "Drawer.h"
#include "EventHandler.h"
#include "State.h"
#include "Salad.h"
#include "Modeler.h"

// choices of algorithms ======================================================================
#include "Pmvc.h"                   // standard PMVC
#include "PmvcMr.h"               // PMVC with micro-rendering
typedef Pmvc PmvcAlgorithm;
//typedef PmvcMr PmvcAlgorithm;
//---------------------------------------------------------------------------------------------
#include "DiffusePmvcT.h"           // PMVC-based color diffusion
#include "DiffusePoisson.h"       // Poisson-based color diffusion
typedef DiffusePmvcT<PmvcAlgorithm> DiffuseAlgorithm;
//typedef DiffusePoisson DiffuseAlgorithm;
//=============================================================================================
#include "CutAlgorithmT.h"
typedef CutAlgorithmT<DiffuseAlgorithm> CutAlgorithm;
#include "VolumeObjectT.h"
typedef VolumeObjectT<DiffuseAlgorithm> VolumeObject;

class CDiffusionSurfacesView;
class CDiffusionSurfacesApp;
class CMainFrame;

class Core {
    Core(void);
    ~Core(void);
    Core(const Core& src);
public:
    static Core& getInstance() {
        static Core p;
        return p;
    }
    CDiffusionSurfacesApp* app_;
    CDiffusionSurfacesView* view_;
    CMainFrame* mainFrm_;
    
    KLIB::OGL ogl_;
    Drawer drawer_;
    EventHandler eventHandler_;
    State* state_;
    
    CutAlgorithm cutAlgorithm_;
    VolumeObject volObj_;
    Salad salad_;
    
    KLIB::ProgramObject noiseShader_;

    Modeler modeler_;
    
    void gl_init();
    void gl_deinit();
};
