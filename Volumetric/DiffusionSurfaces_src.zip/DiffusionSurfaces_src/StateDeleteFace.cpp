#include "StdAfx.h"
#include "StateDeleteFace.h"
#include "StateGrain.h"
#include "StateColor.h"
#include "Core.h"
#include <KLIB/RBF.h>

using namespace std;
using namespace KLIB;

namespace {

Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;
void draw_mesh0_simple(Mesh0& mesh0) {
    glBegin(GL_TRIANGLES);
    for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it)
        for (Mesh0::FVIter fv_it = mesh0.fv_iter(f_it); fv_it; ++fv_it) {
            glVertex3dv(mesh0.point(fv_it).ptr());
        }
    glEnd();
}
bool isAutoRotate_ = false;
}

void StateDeleteFace::initialize() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    size_t numFold = modeler.foldAngles_exemplar_.size();
    // generate mesh4 & mesh0
    if (modeler.type_ == Modeler::TYPE_CYLIND) {
        for (size_t objID = 0; objID < sz_sweepObjects; ++objID) {
            SweepObject& sweepObj = modeler.sweepObjects_[objID];
            sweepObj.mesh4_ref_ = sweepObj.genMesh4_cylind(sweepObj.strokeHrz_exemplar_[0]);
            sweepObj.mesh0_ref_ = sweepObj.mesh4_ref_.convert();
            if (sweepObj.hasGrain_) {
                sweepObj.genGrainMesh4();
                sweepObj.grainObject_.mesh0_ref_ = sweepObj.grainObject_.mesh4_ref_.convert();
            }
        }
    } else {    // (modeler.type_ == Modeler::TYPE_CYLIND)
        double angle_end = 2 * M_PI / numFold;
        for (size_t objID = 0; objID < sz_sweepObjects; ++objID) {
            SweepObject& sweepObj = modeler.sweepObjects_[objID];
            sweepObj.mesh4_ref_;
            if (sweepObj.type_ == SweepObject::TYPE_NFOLD1) {
                Polyline2d& strokeHrz = sweepObj.strokeHrz_exemplar_[0];
                Polyline2d temp_strokeHrz = strokeHrz;
                size_t sz_strokeHrz = strokeHrz.size();
                for (size_t i = 0; i < sz_strokeHrz; ++i)
                    temp_strokeHrz[i].x_ = 0.5 * (strokeHrz[i].x_ + strokeHrz[sz_strokeHrz - 1 - i].x_);
                sweepObj.mesh4_ref_ = sweepObj.genMesh4_nfold1(temp_strokeHrz, 0, angle_end);
            } else {
                sweepObj.mesh4_ref_ = sweepObj.genMesh4_nfold2(sweepObj.strokeHrz_exemplar_[0], 0, angle_end);
            }
            sweepObj.mesh0_ref_ = sweepObj.mesh4_ref_.convert();
            if (sweepObj.hasGrain_) {
                sweepObj.genGrainMesh4();
                sweepObj.grainObject_.mesh0_ref_ = sweepObj.grainObject_.mesh4_ref_.convert();
            }
        }
    }
    
    currentObjectID_ = 0;
    core.ogl_.makeOpenGLCurrent();
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
}
State* StateDeleteFace::next() {
    for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i)
        if (modeler.sweepObjects_[i].hasGrain_)
            return StateGrain::getInstance();
    return StateColor::getInstance();
}
void StateDeleteFace::draw() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    size_t numFold = modeler.foldAngles_exemplar_.size();
    
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);
    
    // draw gohst meshes
    if (!isGrainMode) {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glEnable(GL_BLEND);
        glColor4d(0, 0, 0, 0.2);
        for (size_t i = 0; i < sz_sweepObjects; ++i) {
            Mesh0& mesh0 = modeler.sweepObjects_[i].mesh0_ref_;
            if (modeler.type_ == Modeler::TYPE_CYLIND)
                draw_mesh0_simple(mesh0);
            else {
                glPushMatrix();
                for (size_t j = 0; j < numFold; ++j) {
                    draw_mesh0_simple(mesh0);
                    glRotated(360. / numFold, 0, 1, 0);
                }
                glPopMatrix();
            }
        }
        glDisable(GL_BLEND);
        glEnable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);
    }
    
    Mesh0& mesh0 =  isGrainMode
        ? modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_].mesh0_ref_;
    // mesh face
    glEnable(GL_LIGHTING);
    glColor3d(1, 1, 1);
    Drawer::draw_mesh_face(mesh0);
    // mesh edge
    glDisable(GL_LIGHTING);
    glColor3d(0, 0, 0);
    glLineWidth(1);
    Drawer::draw_mesh_edge(mesh0);
    
    // cutting stroke
    if (!cutStroke2D_.empty()) {
        glLineWidth(5);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor3d(1, 0, 0);
        glBegin(GL_LINE_STRIP);
        for (size_t i = 0; i < cutStroke3D_.size(); ++i) glVertex3dv(cutStroke3D_[i].ptr());
        glEnd();
    }
    
    glPopAttrib();
}
void StateDeleteFace::OnLButtonDown(UINT nFlags, CPoint& point) {
    Vector2d point2d(point.x, point.y);
    Vector3d point3d = core.ogl_.unproject(point2d);
    cutStroke2D_.clear();
    cutStroke3D_.clear();
    cutStroke2D_.push_back(point2d);
    cutStroke3D_.push_back(point3d);
}
void StateDeleteFace::OnLButtonUp  (UINT nFlags, CPoint& point) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    Mesh0& mesh0 = currentObjectID_ < sz_sweepObjects
        ? modeler.sweepObjects_[currentObjectID_].mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_;
    Mesh4& mesh4 = currentObjectID_ < sz_sweepObjects
        ? modeler.sweepObjects_[currentObjectID_].mesh4_ref_
        : modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh4_ref_;
    
    if (cutStroke2D_.size() < 5) {   // clear cross section
        for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v)
            mesh4.data(v).cutValue_ = Mesh4Traits::CUTVALUE_DEFAULT;
        mesh0 = mesh4.convert();
    } else {
        // resample stroke points evenly
        cutStroke2D_.resample(20);
        
        // construct 2D scalar field with RBF
        ThinPlate2d rbf;
        vector<Vector2d> rbfPoints;
        vector<double>   rbfValues;
        for (size_t i = 0; i < cutStroke2D_.size(); ++i) {
            Vector2d p = cutStroke2D_[i];
            Vector2d d;
            if (0 < i)
                d += p - cutStroke2D_[i - 1];
            if (i < cutStroke2D_.size() - 1)
                d += cutStroke2D_[i + 1] - p;
            d = rotate90(d);
            d.normalize();
            d *= (core.ogl_.getWidth() + core.ogl_.getHeight()) * 0.001;
            rbfPoints.push_back(p + d);     rbfValues.push_back( 1);
            rbfPoints.push_back(p - d);     rbfValues.push_back(-1);
        }
        rbf.setPoints(rbfPoints);
        rbf.setValues(rbfValues);
        
        // evaluate RBF values on mesh4 vertices
        Vector3d eyeDir = core.ogl_.viewParam_.focusPoint_ - core.ogl_.viewParam_.eyePoint_;
        for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v) {
            Vector3d& point3d = mesh4.point(v);
            Vector3d  normal = mesh4.normal(v);
            if (0 < (normal | eyeDir))
                continue;
            Vector2d& point2d = Vector2d(core.ogl_.project(point3d));
            double cutValue = rbf.getValue(point2d);
            if (cutValue < mesh4.data(v).cutValue_)
                mesh4.data(v).cutValue_ = cutValue;
        }
        if (currentObjectID_ < sz_sweepObjects && modeler.sweepObjects_[currentObjectID_].type_ == SweepObject::TYPE_NFOLD1) {
            for (int vid = 0; vid < mesh4.n_vertices(); ++vid) {
                Mesh4::VHandle v = mesh4.vertex_handle(vid);
                Mesh4::VertexData& vdata = mesh4.data(v);
                double& cutValue = vdata.cutValue_;
                int mapped_vid = vdata.nfold1_mapped_vid_;
                if (mapped_vid == -1)
                    continue;
                Mesh4::VHandle mapped_v = mesh4.vertex_handle(mapped_vid);
                Mesh4::VertexData& mapped_vdata = mesh4.data(mapped_v);
                double& mapped_cutValue = mapped_vdata.cutValue_;
                cutValue = mapped_cutValue = min<double>(cutValue, mapped_cutValue);
            }
        }
        mesh0 = mesh4.convert();
    }
    cutStroke2D_.clear();
    cutStroke3D_.clear();
    core.ogl_.RedrawWindow();
}

void StateDeleteFace::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateDeleteFace::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateDeleteFace::OnMouseMove  (UINT nFlags, CPoint& point) {
    if (core.eventHandler_.isLButtonDown_) {
        Vector2d point2d(point.x, point.y);
        Vector3d point3d = core.ogl_.unproject(point2d);
        cutStroke2D_.push_back(point2d);
        cutStroke3D_.push_back(point3d);
        core.ogl_.RedrawWindow();
    }
    core.eventHandler_.default_OnMouseMove(nFlags, point);
}
void StateDeleteFace::OnDropFiles(const string& fname, const string& ext) {
    if (ext == "step3") {
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_DeleteFace(ifs)) {
            cout << "Error occurred in Modeler::load_DeleteFace()" << endl;
            return;
        }
        return;
    }
}
void StateDeleteFace::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    
    switch (nChar) {
    case ' ':
        ++currentObjectID_;
        if (sz_sweepObjects <= currentObjectID_) {
            while (true) {
                if (currentObjectID_ == 2 * sz_sweepObjects) {
                    currentObjectID_ = 0;
                    break;
                }
                if (modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].hasGrain_)
                    break;
                ++currentObjectID_;
            }
        }
        core.ogl_.RedrawWindow();
        break;
    case 'S':   // save
        {
            CFileDialog dlg(FALSE, "step3", "*.step3", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step3 files|*.step3||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_DeleteFace(ofs);
        }
        break;
    }
}

