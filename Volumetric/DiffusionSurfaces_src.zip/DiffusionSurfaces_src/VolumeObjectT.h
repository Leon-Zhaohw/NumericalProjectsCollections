#pragma once
#include <vector>
#include <string>
#include "SrfMesh.h"
#include "Mesh2.h"
#include "NoiseWeight.h"
#include "BoundingBox.h"
#include "SilhouetteRendererT.h"

struct Piece;

template <class TDiffuseAlgorithm>
struct VolumeObjectT {
    std::vector<SrfMesh> srfMeshes_;
    Mesh2 mesh2_;           // resulting cross-section
    
    typename TDiffuseAlgorithm::ObjectData cutData_;
    
    BoundingBox bbox_;
    bool cutDone_;
    NoiseWeight noiseWeight_;
    
    VolumeObjectT()
        : cutDone_(false)
    {}
    void gl_init();
    void gl_deinit();
    void calcAuxiliaryInfo();
    void processBlur();
    Piece convertToPiece() const;
    bool loadXML(const char* fname);         // text-based IO
    bool saveXML(const char* fname) const;
    bool loadDSS(const char* fname);         // binary-based IO
    bool saveDSS(const char* fname) const;
    
    // functions used in SilhouetteRendererT
    SilhouetteRendererT<VolumeObjectT<TDiffuseAlgorithm> > silRenderer_;
    void updateSilhouette() { silRenderer_.update(*this); }
    void calcFixedCurves() const {}
    void calcSilhouetteCurves();
    void renderSceneDepth() const;
private:        // don't want copying/substitution!
    VolumeObjectT(const VolumeObjectT& src);
    VolumeObjectT& operator=(const VolumeObjectT& src);
};
