#pragma once
#include "state.h"
#include "Mesh0.h"
#include <KLIB/Vector.h>
#include <KLIB/Polyline.h>

class StateGrain : public State {
    StateGrain(void) {}
    ~StateGrain(void) {}
public:
    static StateGrain* getInstance() {
        static StateGrain p;
        return &p;
    }
    std::string message();
    void initialize();
    bool isReady() { return true; }
    State* next();
    
    void draw();
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    
    enum Mode {
        MODE_TURNON,
        MODE_TURNOFF,
        MODE_RADIUS,
        MODE_OFFSET,
        MODE_SCALE,
        MODE_MOVEREF,
    } mode_;
    
    int currentObjectID_;
    
    CPoint point_old_;
    
    // reference point for visualizing radius, offset, scale
    Mesh0          refPoint_mesh0_;
    KLIB::Vector3d refPoint_;
    KLIB::Vector3d refPoint_normal_;
    
    void refPointMesh0Update();
    void refPointInit();
    KLIB::Polyline2d cutStroke2D_;
    KLIB::Polyline3d cutStroke3D_;
};
