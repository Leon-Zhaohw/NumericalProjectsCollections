#include "StdAfx.h"
#include <OpenMesh/Core/IO/MeshIO.hh>
#include "Core.h"
#include "Piece.h"
using namespace KLIB;
using namespace std;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

bool Piece::load(const char* fname) {
    ifstream ifs;
    ifs.open(fname, ios::binary);
    if (!ifs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    load_sub(ifs);
    return true;
}
void Piece::load_sub(ifstream& ifs) {
    // mesh2_
    mesh2_.clear();
    int mesh2_nv;
    int mesh2_nf;
    ifs.read((char*)&mesh2_nv, sizeof(int));
    ifs.read((char*)&mesh2_nf, sizeof(int));
    for (int i = 0; i < mesh2_nv; ++i) {
        Vector3d point;
        Vector3d color;
        ifs.read((char*)&point, sizeof(Vector3d));
        ifs.read((char*)&color, sizeof(Vector3d));
        Mesh2::VHandle vhandle = mesh2_.add_vertex(point);
        mesh2_.data(vhandle).color_ = color;
    }
    for (int i = 0; i < mesh2_nf; ++i) {
        vector<Mesh2::VHandle> face_vhandles(3);
        for (int j = 0; j < 3; ++j) {
            int vid;
            ifs.read((char*)&vid, sizeof(int));
            face_vhandles[j] = mesh2_.vertex_handle(vid);
        }
        mesh2_.add_face(face_vhandles);
    }
    mesh2_.request_face_normals();
    mesh2_.request_vertex_normals();
    mesh2_.update_normals();
    
    // mesh3s;
    int n_mesh3s;
    ifs.read((char*)&n_mesh3s, sizeof(int));
    mesh3s_.clear();
    mesh3s_.resize(n_mesh3s);
    for (int i = 0; i < n_mesh3s; ++i) {
        Mesh3& mesh3 = mesh3s_[i];
        int mesh3_nv;
        int mesh3_nf;
        ifs.read((char*)&mesh3_nv, sizeof(int));
        ifs.read((char*)&mesh3_nf, sizeof(int));
        for (int i = 0; i < mesh3_nv; ++i) {
            Vector3d point     ;
            Vector3d color     ;
            Vector3d back_color;
            ifs.read((char*)&point,      sizeof(Vector3d));
            ifs.read((char*)&color,      sizeof(Vector3d));
            ifs.read((char*)&back_color, sizeof(Vector3d));
            Mesh3::VHandle vhandle = mesh3.add_vertex(point);
            mesh3.data(vhandle).color_      = color;
            mesh3.data(vhandle).back_color_ = back_color;
        }
        for (int i = 0; i < mesh3_nf; ++i) {
            vector<Mesh3::VHandle> face_vhandles(3);
            for (int j = 0; j < 3; ++j) {
                int vid;
                ifs.read((char*)&vid, sizeof(int));
                face_vhandles[j] = mesh3.vertex_handle(vid);
            }
            mesh3.add_face(face_vhandles);
        }
        mesh3.request_face_normals();
        mesh3.request_vertex_normals();
        mesh3.update_normals();
    }
    // feature curves used for line rendering
    int n_curves;
    ifs.read((char*)&n_curves, sizeof(int));
    curves_.resize(n_curves);
    for (int i = 0; i < n_curves; ++i) {
        Polyline3d& curve = curves_[i];
        int curve_nv;
        int curve_isLoop;
        ifs.read((char*)&curve_nv,     sizeof(int));
        ifs.read((char*)&curve_isLoop, sizeof(int));
        for (int j = 0; j < curve_nv; ++j) {
            Vector3d point;
            ifs.read((char*)&point, sizeof(Vector3d));
            curve.push_back(point);
        }
        curve.setLoop(curve_isLoop == 1);
    }
    
    // noise weight data
    int N;
    ifs.read((char*)&N, sizeof(int));
    noiseWeight_.resize(N);
    ifs.read((char*)&noiseWeight_.data_[0][0], N * N * N * sizeof(Vector4uc));
    ifs.read((char*)&noiseWeight_.data_[1][0], N * N * N * sizeof(Vector4uc));
    
    // transfer to GPU
    ogl.makeOpenGLCurrent();
    noiseWeight_.gl_init();
    noiseWeight_.transferToGpu();
    
    // transformation
    ifs.read((char*)&t_, sizeof(Transform));
}
bool Piece::loadDish(const char* fname) {
    Mesh3 mesh3_temp;
    if (!OpenMesh::IO::read_mesh(mesh3_temp, fname))
        return false;
    *this = Piece();
    mesh3s_.push_back(mesh3_temp);
    Mesh3& mesh3 = mesh3s_.back();
    mesh3.request_face_normals();
    mesh3.request_vertex_normals();
    mesh3.update_normals();
    for (Mesh3::VIter v_it = mesh3.vertices_begin(); v_it != mesh3.vertices_end(); ++v_it)
        mesh3.data(v_it).color_ = mesh3.data(v_it).back_color_ = Vector3d(1.0, 0.9, 0.8);   // dish color
    
    // noise weight data (totally waste of memory... but for coding convenience)
    noiseWeight_.clear();
    noiseWeight_.resize(32, Vector8uc(48, 128, 64, 64, 32, 32, 16, 16));
    ogl.makeOpenGLCurrent();
    noiseWeight_.gl_init();
    noiseWeight_.transferToGpu();
    return true;
}
bool Piece::save(const char* fname) const {
    ofstream ofs;
    ofs.open(fname, ios::trunc | ios::binary);
    if (!ofs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    save_sub(ofs);
    return true;
}
void Piece::save_sub(ofstream& ofs) const {
    int mesh2_nv = mesh2_.n_vertices();
    int mesh2_nf = mesh2_.n_faces();
    ofs.write((char*)&mesh2_nv, sizeof(int));
    ofs.write((char*)&mesh2_nf, sizeof(int));
    for (Mesh2::CVIter v_it = mesh2_.vertices_begin(); v_it != mesh2_.vertices_end(); ++v_it) {
        const Vector3d& point = mesh2_.point(v_it);
        const Vector3d& color = mesh2_.data(v_it).color_;
        ofs.write((char*)&point, sizeof(Vector3d));
        ofs.write((char*)&color, sizeof(Vector3d));
    }
    for (Mesh2::CFIter f_it = mesh2_.faces_begin(); f_it != mesh2_.faces_end(); ++f_it) {
        for (Mesh2::CFVIter fv_it = mesh2_.cfv_iter(f_it); fv_it; ++fv_it) {
            int vid = fv_it.handle().idx();
            ofs.write((char*)&vid, sizeof(int));
        }
    }
    // mesh3s;
    int n_mesh3s = (int)mesh3s_.size();
    ofs.write((char*)&n_mesh3s, sizeof(int));
    for (int i = 0; i < n_mesh3s; ++i) {
        const Mesh3& mesh3 = mesh3s_[i];
        int mesh3_nv = mesh3.n_vertices();
        int mesh3_nf = mesh3.n_faces();
        ofs.write((char*)&mesh3_nv, sizeof(int));
        ofs.write((char*)&mesh3_nf, sizeof(int));
        for (Mesh3::CVIter v_it = mesh3.vertices_begin(); v_it != mesh3.vertices_end(); ++v_it) {
            const Vector3d& point      = mesh3.point(v_it);
            const Vector3d& color      = mesh3.data(v_it).color_;
            const Vector3d& back_color = mesh3.data(v_it).back_color_;
            ofs.write((char*)&point,      sizeof(Vector3d));
            ofs.write((char*)&color,      sizeof(Vector3d));
            ofs.write((char*)&back_color, sizeof(Vector3d));
        }
        for (Mesh3::CFIter f_it = mesh3.faces_begin(); f_it != mesh3.faces_end(); ++f_it) {
            for (Mesh3::CFVIter fv_it = mesh3.cfv_iter(f_it); fv_it; ++fv_it) {
                int vid = fv_it.handle().idx();
                ofs.write((char*)&vid, sizeof(int));
            }
        }
    }
    // feature curves used for line rendering
    int n_curves = (int)curves_.size();
    ofs.write((char*)&n_curves, sizeof(int));
    for (int i = 0; i < n_curves; ++i) {
        const Polyline3d& curve = curves_[i];
        int curve_nv     = (int)curve.size();
        int curve_isLoop = curve.isLoop() ? 1 : 0;
        ofs.write((char*)&curve_nv,     sizeof(int));
        ofs.write((char*)&curve_isLoop, sizeof(int));
        for (int j = 0; j < curve_nv; ++j) {
            const Vector3d& point = curve[j];
            ofs.write((char*)&point, sizeof(Vector3d));
        }
    }
    // noise weight data
    int N = noiseWeight_.resolution_;
    ofs.write((char*)&N, sizeof(int));
    ofs.write((char*)&noiseWeight_.data_[0][0], N * N * N * 4 * sizeof(char));
    ofs.write((char*)&noiseWeight_.data_[1][0], N * N * N * 4 * sizeof(char));
    // transformation
    ofs.write((char*)&t_, sizeof(Transform));
}
