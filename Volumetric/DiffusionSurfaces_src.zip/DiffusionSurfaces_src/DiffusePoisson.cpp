#include "stdafx.h"
#include "Core.h"
#include "CutParam.h"
#include "DiffusePoisson.h"
#include <map>
#include <set>
#include <tetgen.h>
#include <iterator>
#include <KLIB/Umfpack.h>
using namespace std;
using namespace KLIB;

void DiffusePoisson::ObjectData::preprocess(VolumeObject& volObj) {
    preprocess_step1_buildTetMesh(volObj);
    preprocess_step2_solvePoisson(volObj);
}
void DiffusePoisson::ObjectData::preprocess_step1_buildTetMesh(VolumeObject& volObj) {
    //--------------------------------------------------+
    // construct tetMesh0_ from srfMeshes_ using TetGen |
    //--------------------------------------------------+
    printf("Preparing data for TetGen...");
    //++++ create TetGen input ++++//
    tetgenio tetgen_in;
    // points
    tetgen_in.numberofpoints = 0;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) // count total number
        tetgen_in.numberofpoints += volObj.srfMeshes_[mesh0_id].mesh0_.n_vertices();
    int nopa = 10;  // Number Of Point Attributes
    tetgen_in.numberofpointattributes = nopa;
    tetgen_in.pointlist          = new double[3    * tetgen_in.numberofpoints];    // allocate memory
    tetgen_in.pointattributelist = new double[nopa * tetgen_in.numberofpoints];
    int offset_v = 0;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) {  // make input array
        Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
        for (int i = 0; i < mesh0.n_vertices(); ++i) {
            Mesh0::VHandle vhandle = mesh0.vertex_handle(i);
            // position
            Vector3d pos = mesh0.point(vhandle);
            pos = pos.convert<float>().convert<double>();           // this is VERY weird, but avoids degenerate tets
            for (int j = 0; j < 3; ++j)
                tetgen_in.pointlist[3 * (offset_v + i) + j] = pos[j];
            // attributes
            double flag = mesh0.isTwoSided_ && !mesh0.data(vhandle).isOpenEnd_ ? 2 : 1;
            tetgen_in.pointattributelist[nopa * (offset_v + i)] = flag;
            Mesh0::VertexData& vdata = mesh0.data(vhandle);
            for (int j = 0; j < 3; ++j)
                tetgen_in.pointattributelist[nopa * (offset_v + i) + j + 1] = vdata.color_[j];
            for (int j = 0; j < 3; ++j)
                tetgen_in.pointattributelist[nopa * (offset_v + i) + j + 4] = flag == 2 ? vdata.back_color_[j] : vdata.color_[j];
            for (int j = 0; j < 3; ++j)
                tetgen_in.pointattributelist[nopa * (offset_v + i) + j + 7] = mesh0.normal(vhandle)[j];
        }
        offset_v += mesh0.n_vertices();
    }
    // faces
    tetgen_in.numberoffacets = 0;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) // count total number
        tetgen_in.numberoffacets += volObj.srfMeshes_[mesh0_id].mesh0_.n_faces();
    tetgen_in.facetlist       = new tetgenio::facet[tetgen_in.numberoffacets];    // allocate memory
    tetgen_in.facetmarkerlist = new int            [tetgen_in.numberoffacets];
    offset_v = 0;
    int offset_f = 0;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) {  // make input array
        Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
        for (int i = 0; i < mesh0.n_faces(); ++i) {
            // construct a facet representing a single triangle
            tetgenio::facet& f = tetgen_in.facetlist[offset_f + i];
            tetgenio::init(&f);
            f.numberofpolygons = 1;
            f.polygonlist = new tetgenio::polygon[1];
            tetgenio::polygon& p = f.polygonlist[0];
            p.numberofvertices = 3;
            p.vertexlist = new int[3];
            // pass data from Mesh0
            Mesh0::FHandle fhandle = mesh0.face_handle(i);
            Mesh0::FVIter fv_it = mesh0.fv_iter(fhandle);
            for (int j = 0; j < 3; ++j, ++fv_it)
                p.vertexlist[j] = offset_v + fv_it.handle().idx();
            if (mesh0.isTwoSided_) {
                // marker indicating normal orientation (nasty hack!)
                int vertex_id0 = p.vertexlist[0];
                int vertex_id1 = p.vertexlist[1];
                int vertex_id2 = p.vertexlist[2];
                // shuffle vertices in an ascending order
                if (vertex_id1 < vertex_id0)
                    swap(vertex_id0, vertex_id1);
                if (vertex_id2 < vertex_id0)
                    swap(vertex_id0, vertex_id2);
                if (vertex_id2 < vertex_id1)
                    swap(vertex_id1, vertex_id2);
                Vector3d pos0(&tetgen_in.pointlist[3 * vertex_id0]);
                Vector3d pos1(&tetgen_in.pointlist[3 * vertex_id1]);
                Vector3d pos2(&tetgen_in.pointlist[3 * vertex_id2]);
                Vector3d test = cross_product(pos1 - pos0, pos2 - pos0);
                test.normalize();
                const Vector3d& normal = mesh0.normal(fhandle);
                tetgen_in.facetmarkerlist[offset_f + i] = 0 < test.dot_product(normal) ? 1 : 2;
            } else {
                tetgen_in.facetmarkerlist[offset_f + i] = 0;        // no need for normal orientation
            }
        }
        offset_v += mesh0.n_vertices();
        offset_f += mesh0.n_faces();
    }
    // holes
    tetgen_in.numberofholes = 0;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id )  // count total number
        if (volObj.srfMeshes_[mesh0_id].mesh0_.isHole_)
            ++tetgen_in.numberofholes;
    tetgen_in.holelist = new double[3 * tetgen_in.numberofholes];    // allocate memory
    int hole_index = 0;
    double hole_distance = volObj.bbox_.diagonal() * 0.001;
    for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) {  // make input array
        Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
        if (mesh0.isHole_) {
            Mesh0::VHandle vhandle = mesh0.vertex_handle(0);
            Vector3d hole_pos = mesh0.point(vhandle) - hole_distance * mesh0.normal(vhandle);
            for (int j = 0; j < 3; ++j)
                tetgen_in.holelist[3 * hole_index + j] = hole_pos[j];
            ++hole_index;
        }
    }
    // save to .poly file
    //tetgen_in.save_poly ("tetgen_in");
    //tetgen_in.save_nodes("tetgen_in");
    
    //// set volume constraint    --> maybe irrelevant in our case...
    //double edgelen_mean  = 0;
    //int    edgelen_count = 0;
    //for (size_t mesh0_id = 0; mesh0_id < volObj.srfMeshes_.size(); ++mesh0_id ) {
    //    Mesh0& mesh0 = volObj.srfMeshes_[mesh0_id].mesh0_;
    //    for (Mesh0::EIter e_it = mesh0.edges_begin(); e_it != mesh0.edges_end(); ++e_it) {
    //        Vector3d point[2];
    //        for (int i = 0; i < 2; ++i)
    //            point[i] = mesh0.point(mesh0.to_vertex_handle(mesh0.halfedge_handle(e_it, i)));
    //        edgelen_mean += (point[1] - point[0]).length();
    //        ++edgelen_count;
    //    }
    //}
    //edgelen_mean /= edgelen_count;
    //double volume_constraint = 2 * edgelen_mean * edgelen_mean * edgelen_mean / (6 * 1.41421356);
    ////volume_constraint *= 0.2;
    
    //++++ tetrahedralize! ++++//
    tetgenio tetgen_out;
    ostringstream tetgen_switch;
    tetgen_switch << "pznfYY";
    //tetgen_switch << "a" << volume_constraint;    // volume constraint switch
    tetgen_switch << "q1.1";       // on: high-res mesh, off: low-res mesh
    tetrahedralize(const_cast<char*>(tetgen_switch.str().c_str()), &tetgen_in, &tetgen_out);
    
    //tetgen_out.save_elements ("tetgen_out");
    //tetgen_out.save_nodes    ("tetgen_out");
    //tetgen_out.save_neighbors("tetgen_out");
    //tetgen_out.save_faces    ("tetgen_out");
    //
    //++++ convert TetGen output to TetMesh0 ++++//
    TetMesh0& tetMesh0 = volObj.cutData_.tetMesh0_;
    tetMesh0.clear();
    // add vertices
    for (int i = 0; i < tetgen_out.numberofpoints; ++i) {
        TetMesh0::Vertex vertex;
        vertex.pos_ = Vector3d(&tetgen_out.pointlist[3 * i]);
        double flag = tetgen_out.pointattributelist[nopa * i];         // 0: interior,  1: single-sided boundary,  others: two-sided boundary
        vertex.type_ = flag == 0 ? TetMesh0::VERTEX_INTERIOR : flag == 1 ? TetMesh0::VERTEX_BOUNDARY : TetMesh0::VERTEX_BOUNDARY_SPLIT;
        if (vertex.type_ != TetMesh0::VERTEX_INTERIOR) {
            vertex.color_      = Vector3d(&tetgen_out.pointattributelist[nopa * i + 1]);
            vertex.back_color_ = Vector3d(&tetgen_out.pointattributelist[nopa * i + 4]);
            vertex.normal_     = Vector3d(&tetgen_out.pointattributelist[nopa * i + 7]);
        }
        tetMesh0.vertices_.push_back(vertex);
    }
    // add tetras
    for (int i = 0; i < tetgen_out.numberoftetrahedra; ++i) {
        TetMesh0::Tetra tetra;
        for (int j = 0; j < 4; ++j) {
            tetra.vertex_  [j] = tetgen_out.tetrahedronlist[4 * i + j];
            tetra.neighbor_[j] = tetgen_out.neighborlist[4 * i + j];
            tetMesh0.vertices_[tetra.vertex_[j]].neighbor_tetras_.push_back(i);
        }
        tetMesh0.tetras_.push_back(tetra);
    }
    // add faces
    for (size_t i = 0; i < tetMesh0.vertices_.size(); ++i) {    // sort neighbor tetra list for all vertices
        TetMesh0::Vertex& vertex = tetMesh0.vertices_[i];
        sort(vertex.neighbor_tetras_.begin(), vertex.neighbor_tetras_.end());
    }
    for (int i = 0; i < tetgen_out.numberoftrifaces; ++i) {
        TetMesh0::Face face;
        vector<int> tetralist;
        for (int j = 0; j < 3; ++j) {
            int vertex_id = tetgen_out.trifacelist[3 * i + j];
            face.vertex_[j] = vertex_id;
            vector<int>& neighbor_tetras = tetMesh0.vertices_[vertex_id].neighbor_tetras_;
            if (j == 0) {
                tetralist = neighbor_tetras;
            } else {
                vector<int> intersection;
                set_intersection(
                    tetralist.begin(), tetralist.end(),
                    neighbor_tetras.begin(), neighbor_tetras.end(),
                    back_inserter(intersection));
                tetralist = intersection;
            }
        }
        assert(tetralist.size() == 1 || tetralist.size() == 2);
        // associate with tetras
        face.tetra_[1] = -1;
        for (size_t j = 0; j < tetralist.size(); ++j) {
            int tetra_id = tetralist[j];
            face.tetra_[j] = tetra_id;
            TetMesh0::Tetra& tetra = tetMesh0.tetras_[tetra_id];
            for (int k = 0; k < 4; ++k) {
                if (tetra.vertex_[k] != face.vertex_[0] &&
                    tetra.vertex_[k] != face.vertex_[1] &&
                    tetra.vertex_[k] != face.vertex_[2])
                {
                    tetra.face_[k] = i;
                    break;
                }
            }

        }
        
        int marker = tetgen_out.trifacemarkerlist[i];       // 0: not two-sided,  1(or 2): two-sided, normal direction is the same(or opposite) direction as the curl of vertices in ascending order
        face.isTwoSided_ = marker != 0;
        if (face.isTwoSided_) {
            //// determine normal
            //// (this is a ridiculous trick because TetGen doesn't support attribute data assigned to trifaces.)
            //// (this depends on TetGen's behavior that the array of input points is preserved exactly in the same order in the output array)
            int vertex_id0 = face.vertex_[0];
            int vertex_id1 = face.vertex_[1];
            int vertex_id2 = face.vertex_[2];
            //// shuffle vertices in an ascending order
            //if (vertex_id1 < vertex_id0)
            //    swap(vertex_id0, vertex_id1);
            //if (vertex_id2 < vertex_id0)
            //    swap(vertex_id0, vertex_id2);
            //if (vertex_id2 < vertex_id1)
            //    swap(vertex_id1, vertex_id2);
            Vector3d& pos0 = tetMesh0.vertices_[vertex_id0].pos_;
            Vector3d& pos1 = tetMesh0.vertices_[vertex_id1].pos_;
            Vector3d& pos2 = tetMesh0.vertices_[vertex_id2].pos_;
            Vector3d normal = cross_product(pos1 - pos0, pos2 - pos0);
            normal.normalize();
            Vector3d vnormal =
                tetMesh0.vertices_[vertex_id0].normal_ + 
                tetMesh0.vertices_[vertex_id1].normal_ + 
                tetMesh0.vertices_[vertex_id2].normal_;
            //vnormal.normalize();
            if ((normal | vnormal) < 0)
                normal *= -1.;
            //if (marker == 2)
            //    normal *= -1.;
            face.normal_ = normal;
        }
        tetMesh0.faces_.push_back(face);
    }
    
    //------------------------------------+
    // construct tetMesh1_ from tetMesh0_ |
    // by duplicating two-sided vertices  |
    //------------------------------------+
    printf("Splitting two-sided vertices...");
    TetMesh1& tetMesh1 = volObj.cutData_.tetMesh1_;
    tetMesh1.clear();
    
    // add vertices
    for (size_t i = 0; i < tetMesh0.vertices_.size(); ++i) {
        TetMesh0::Vertex& vertex0 = tetMesh0.vertices_[i];
        TetMesh1::Vertex  vertex1;
        vertex1.pos_ = vertex0.pos_;
        vertex1.isConstrained_ = vertex0.type_ != TetMesh0::VERTEX_INTERIOR;
        if (vertex1.isConstrained_)
            vertex1.color_ = vertex0.color_;    // constrained color
        vertex0.tetMesh1_vid_ = tetMesh1.vertices_.size();      // forward reference
        tetMesh1.vertices_.push_back(vertex1);
        if (vertex0.type_ == TetMesh0::VERTEX_BOUNDARY_SPLIT) {     // duplicate two-sided vertex
            TetMesh1::Vertex back_vertex1;
            back_vertex1.pos_ = vertex0.pos_;
            back_vertex1.isConstrained_ = true;
            back_vertex1.color_ = vertex0.back_color_;
            vertex0.back_tetMesh1_vid_ = tetMesh1.vertices_.size();      // forward reference
            tetMesh1.vertices_.push_back(back_vertex1);
        }
    }
    // add tetras while considering duplicated vertices
    int flag_visited_id = 0;
    for (size_t i = 0; i < tetMesh0.tetras_.size(); ++i) {
        TetMesh0::Tetra& tetra0 = tetMesh0.tetras_[i];
        TetMesh1::Tetra  tetra1;
        int tetra1_id = static_cast<int>(tetMesh1.tetras_.size());
        for (int j = 0; j < 4; ++j) {
            int vertex0_id = tetra0.vertex_[j];
            TetMesh0::Vertex& vertex0 = tetMesh0.vertices_[vertex0_id];
            if (vertex0.type_ != TetMesh0::VERTEX_BOUNDARY_SPLIT) {     // one-sided vertex = easy
                tetra1.vertex_[j] = vertex0.tetMesh1_vid_;
            } else {                                                    // otherwise, need to determine whether tetra0 is on the front or back side of vertex0
                int side = 0;       // 0: not yet determined, 1: front, -1: back
                vector<int> stack;
                stack.push_back(i);
                while (true) {
                    // pick up a tetra from the stack
                    int test_id = stack.back();
                    TetMesh0::Tetra& test = tetMesh0.tetras_[test_id];
                    stack.pop_back();
                    if (test.flag_visited_ == flag_visited_id)
                        continue;
                    test.flag_visited_ = flag_visited_id;
                    // determine vertex reference number corresponding to vertex0
                    int j1 = 0;
                    while (vertex0_id != test.vertex_[j1])
                        ++j1;
                    // for each face containing j1, check if it is two-sided
                    for (int k = 0; k < 3; ++k) {
                        int face_id = test.face_[(j1 + k + 1) % 4];
                        TetMesh0::Face& face = tetMesh0.faces_[face_id];
                        if (face.isTwoSided_) { // found!
                            Vector3d& normal = face.normal_;
                            Vector3d d = tetMesh0.getTetraBarycenter(test_id) - tetMesh0.getFaceBarycenter(face_id);
                            side = 0 < normal.dot_product(d) ? 1 : -1;
                            break;
                        }
                    }
                    if (side)
                        break;
                    // add neighboring tetras to the stack
                    for (int k = 0; k < 3; ++k) {
                        int neighbor_id = test.neighbor_[(j1 + k + 1) % 4];
                        TetMesh0::Tetra& neighbor = tetMesh0.tetras_[neighbor_id];
                        if (neighbor.flag_visited_ != flag_visited_id)
                            stack.push_back(neighbor_id);
                    }
                    assert(!stack.empty());
                }
                tetra1.vertex_[j] = side == 1 ? vertex0.tetMesh1_vid_ : vertex0.back_tetMesh1_vid_;
                ++flag_visited_id;
            }
            TetMesh1::Vertex& vertex1 = tetMesh1.vertices_[tetra1.vertex_[j]];
            vertex1.neighbor_tetras_.push_back(tetra1_id);
        }
        tetMesh1.tetras_.push_back(tetra1);
    }
    // computing edges and vertex-edge neighbors
    int n = static_cast<int>(tetMesh1.vertices_.size());
    set<int> edgeKeys;
    for (size_t j = 0; j < tetMesh1.tetras_.size(); ++j) {
        TetMesh1::Tetra& tetra = tetMesh1.tetras_[j];
        for (int a = 0; a < 3; ++a) {
            for (int b = a + 1; b < 4; ++b) {
                int vertex0 = tetra.vertex_[a];
                int vertex1 = tetra.vertex_[b];
                if (vertex1 < vertex0)
                    swap(vertex0, vertex1);
                int key = n * vertex0 + vertex1;
                if (edgeKeys.find(key) == edgeKeys.end()) { // insert a new edge
                    edgeKeys.insert(key);
                    TetMesh1::Edge edge;
                    edge.vertex_[0] = vertex0;
                    edge.vertex_[1] = vertex1;
                    int edge_id = static_cast<int>(tetMesh1.edges_.size());
                    tetMesh1.vertices_[vertex0].neighbor_edges_.push_back(edge_id);
                    tetMesh1.vertices_[vertex1].neighbor_edges_.push_back(edge_id);
                    tetMesh1.edges_.push_back(edge);
                }
            }
        }
    }
}

void DiffusePoisson::ObjectData::preprocess_step2_solvePoisson(VolumeObject& volObj) {
    // (see Appendix of Andrei Sharf's SIGGRAPH 2007 paper)
    TetMesh1& tetMesh = volObj.cutData_.tetMesh1_;
    size_t n = tetMesh.vertices_.size();
    size_t m = tetMesh.tetras_  .size();
    
    printf("Assembling Laplacian matrix...");
    // compute matrix K for each tetra
    for (size_t j = 0; j < m; ++j) {
        TetMesh1::Tetra& tetra = tetMesh.tetras_[j];
        Matrix3x3d J;
        for (int a = 0; a < 3; ++a) {
            Vector3d& pos_a = tetMesh.vertices_[tetra.vertex_[a]].pos_;
            Vector3d& pos_b = tetMesh.vertices_[tetra.vertex_[3]].pos_;
            Vector3d d = pos_a - pos_b;
            for (int xyz = 0; xyz < 3; ++xyz)
                J(a, xyz) = d[xyz];
        }
        Vector3d debug_vpos[4];
        for (int i = 0; i < 4; ++i)
            debug_vpos[i] = tetMesh.vertices_[tetra.vertex_[i]].pos_;
        double debug_volume = Util::calcVolume(debug_vpos[0], debug_vpos[1], debug_vpos[2], debug_vpos[3]);
        Matrix3x3d Jinv(J);
        bool debug_flag = Jinv.invert();
        assert(debug_flag);
        Vector3d E3 = Jinv * Vector3d(-1, -1, -1);
        Matrix<double, 3, 4> E;
        E.set(NULL,
            Jinv(0, 0), Jinv(0, 1), Jinv(0, 2), E3[0],
            Jinv(1, 0), Jinv(1, 1), Jinv(1, 2), E3[1],
            Jinv(2, 0), Jinv(2, 1), Jinv(2, 2), E3[2]);
        double det = J.determinant();
        tetra.K_ = (abs(det) / 6) * E.transpose() * E;
    }
    
    // for each vertex, compute K
    for (size_t i = 0; i < n; ++i) {
        TetMesh1::Vertex& vertex = tetMesh.vertices_[i];
        for (size_t j = 0; j < vertex.neighbor_tetras_.size(); ++j) {
            TetMesh1::Tetra& tetra = tetMesh.tetras_[vertex.neighbor_tetras_[j]];
            int i1 = 0;
            for (; i1 < 4; ++i1)
                if (tetra.vertex_[i1] == i) break;
            vertex.K_ += tetra.K_(i1, i1);
        }
    }
    
    // for each edge, compute K
    for (size_t k = 0; k < tetMesh.edges_.size(); ++k) {
        TetMesh1::Edge& edge = tetMesh.edges_[k];
        int i = edge.vertex_[0];
        int j = edge.vertex_[1];
        vector<int>& neighbor_tetras_i = tetMesh.vertices_[i].neighbor_tetras_;
        vector<int>& neighbor_tetras_j = tetMesh.vertices_[j].neighbor_tetras_;
        vector<int> neighbor_tetras;
        set_intersection(
            neighbor_tetras_i.begin(), neighbor_tetras_i.end(),
            neighbor_tetras_j.begin(), neighbor_tetras_j.end(),
            back_inserter(neighbor_tetras));
        for (size_t a = 0; a < neighbor_tetras.size(); ++a) {
            TetMesh1::Tetra& tetra = tetMesh.tetras_[neighbor_tetras[a]];
            int i1 = 0;
            for (; i1 < 4; ++i1)
                if (tetra.vertex_[i1] == i)
                    break;
            int j1 = 0;
            for (; j1 < 4; ++j1)
                if (tetra.vertex_[j1] == j)
                    break;
            edge.K_ += tetra.K_(i1, j1);
        }
    }

    // assemple the matrix K
    vector<CholmodMatrix::Triplet> triplets;
    vector<double> rhs_red(n, 0), rhs_green(n, 0), rhs_blue(n, 0);    // right-hand-side vectors
    
    // for each vertex --> diagonal entry
    for (size_t i = 0; i < n; ++i) {
        TetMesh1::Vertex& vertex = tetMesh.vertices_[i];
        if (vertex.isConstrained_) {
            triplets.push_back(CholmodMatrix::Triplet(i, i, 1));
            rhs_red  [i] = vertex.color_[0];
            rhs_green[i] = vertex.color_[1];
            rhs_blue [i] = vertex.color_[2];
        } else
            triplets.push_back(CholmodMatrix::Triplet(i, i, vertex.K_));
    }
    
    // foe each edge
    for (size_t k = 0; k < tetMesh.edges_.size(); ++k) {
        TetMesh1::Edge& edge = tetMesh.edges_[k];
        int i = edge.vertex_[0];
        int j = edge.vertex_[1];
        TetMesh1::Vertex& vertex_i = tetMesh.vertices_[i];
        TetMesh1::Vertex& vertex_j = tetMesh.vertices_[j];
        if (!vertex_i.isConstrained_ && !vertex_j.isConstrained_) {
            triplets.push_back(CholmodMatrix::Triplet(i, j, edge.K_));
            triplets.push_back(CholmodMatrix::Triplet(j, i, edge.K_));
        } else if (!vertex_i.isConstrained_) {
            rhs_red  [i] -= edge.K_ * vertex_j.color_[0];
            rhs_green[i] -= edge.K_ * vertex_j.color_[1];
            rhs_blue [i] -= edge.K_ * vertex_j.color_[2];
        } else if (!vertex_j.isConstrained_) {
            rhs_red  [j] -= edge.K_ * vertex_i.color_[0];
            rhs_green[j] -= edge.K_ * vertex_i.color_[1];
            rhs_blue [j] -= edge.K_ * vertex_i.color_[2];
        }
    }
    CholmodMatrix K(n, n, triplets);
    
    // solve!
    printf("Solving...");
    Umfpack umfpack(n, K.getAp(), K.getAi(), K.getAx(), true);    // factorization
    vector<double> x_red, x_green, x_blue;  // unknown variable vectors
    umfpack.solve(rhs_red,   x_red);
    umfpack.solve(rhs_green, x_green);
    umfpack.solve(rhs_blue,  x_blue);
    
    // assignment
    for (size_t i = 0; i < n; ++i) {
        TetMesh1::Vertex& vertex = tetMesh.vertices_[i];
        if (vertex.isConstrained_)
            continue;
        Vector3d& color = vertex.color_;
        color[0] = x_red  [i];
        color[1] = x_green[i];
        color[2] = x_blue [i];
    }
}

namespace {
// helper function for determining connectivity
void addFace(
    Mesh2& mesh2, std::map<int, int>& vtxMap,
    const KLIB::Vector3d& pos0, const KLIB::Vector3d& pos1, const KLIB::Vector3d& pos2, 
    const KLIB::Vector3d& col0, const KLIB::Vector3d& col1, const KLIB::Vector3d& col2, 
    const int&            key0, const int&            key1, const int&            key2)
{
    const Vector3d* pos_p[3] = {&pos0, &pos1, &pos2};
    const Vector3d* col_p[3] = {&col0, &col1, &col2};
    const int     * key_p[3] = {&key0, &key1, &key2};

    vector<Mesh2::VHandle> face_vhandles(3);
    for (int i = 0; i < 3; ++i) {
        map<int, int>::iterator findPos = vtxMap.find(*key_p[i]);
        if (findPos != vtxMap.end()) {
            face_vhandles[i] = mesh2.vertex_handle(findPos->second);
        } else {
            int vid = mesh2.n_vertices();
            face_vhandles[i] = mesh2.add_vertex(*pos_p[i]);
            mesh2.data(face_vhandles[i]).color_ = *col_p[i];
            vtxMap.insert(pair<int, int>(*key_p[i], vid));
        }
    }
    mesh2.add_face(face_vhandles);
}
}

void DiffusePoisson::cut_step2_mesh2(VolumeObject& volObj, CutParam& param) {
    TetMesh1& tetmesh = volObj.cutData_.tetMesh1_;
    // evaluate cutValues for each tet vtx
    for (size_t i = 0; i < tetmesh.vertices_.size(); ++i) {
        Vector3d& pos = tetmesh.vertices_[i].pos_;
        tetmesh.vertices_[i].cutValue_ = param.getCutValue(pos);
    }
    // initialize cross-sectional mesh & key-vtx mapping
    Mesh2& mesh2 = volObj.mesh2_;
    mesh2.clear();
    map<int, int> vtxMap;
    // patterns of vertex orders for each case
    static const int mapping_pattern[][4] = {
        {-1, -1, -1, -1},	//0
        {0, 1, 2, 3},	//1
        {1, 2, 0, 3},	//2
        {0, 1, 2, 3},	//3
        {2, 0, 1, 3},	//4
        {0, 2, 3, 1},	//5
        {1, 2, 0, 3},	//6
        {3, 2, 1, 0},	//7
        {3, 2, 1, 0},	//8
        {0, 3, 1, 2},	//9
        {1, 3, 2, 0},	//10
        {2, 0, 1, 3},	//11
        {2, 3, 0, 1},	//12
        {1, 2, 0, 3},	//13
        {0, 1, 2, 3},	//14
        {0, 1, 2, 3}	//15
    };
    size_t vtxSize = tetmesh.vertices_.size();
    size_t tetSize = tetmesh.tetras_  .size();
    for (size_t i = 0; i < tetSize; ++i) {
        const TetMesh1::Tetra& tetra = tetmesh.tetras_[i];
        int code = 0;
        double val[4];
        for (int j = 0; j < 4; ++j) {
            val[j] = tetmesh.vertices_[tetra.vertex_[j]].cutValue_;
            if (val[j] < 0)
                code += (1 << j);
        }
        if (code == 0 || code == 15) continue;
        const int* mapping = mapping_pattern[code];
        Vector3d vPos[4];
        Vector3d vCol[4];
        int      vKey[4];
        for (int j = 0; j < 4; ++j) {
            int index = tetra.vertex_[mapping[j]];
            vPos[j] = tetmesh.vertices_[index].pos_;
            vCol[j] = tetmesh.vertices_[index].color_;
            vKey[j] = vtxSize * index + index;
        }
        switch (code) {
            case 1:
            case 2:
            case 4:
            case 8:
                {
                    Vector3d wPos[3];
                    Vector3d wCol[3];
                    int      wKey[3];
                    for (int j = 0; j < 3; ++j) {
                        double u = (0 - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
                        wPos[j] = (1 - u) * vPos[0] + u * vPos[j + 1];
                        wCol[j] = (1 - u) * vCol[0] + u * vCol[j + 1];
                        int index0 = min(tetra.vertex_[mapping[0]], tetra.vertex_[mapping[j + 1]]);
                        int index1 = max(tetra.vertex_[mapping[0]], tetra.vertex_[mapping[j + 1]]);
                        wKey[j] = vtxSize * index0 + index1;
                    }
                    addFace(
                        volObj.mesh2_, vtxMap,
                        wPos[0], wPos[2], wPos[1],
                        wCol[0], wCol[2], wCol[1],
                        wKey[0], wKey[2], wKey[1]);
                }
                break;
            case 3:
            case 5:
            case 6:
            case 9:
            case 10:
            case 12:
                {
                    static int pairs[4][2] = {{0, 3}, {0, 2}, {1, 2}, {1, 3}};
                    Vector3d wPos[4];
                    Vector3d wCol[4];
                    int      wKey[4];
                    for (int j = 0; j < 4; ++j) {
                        const int& i0 = pairs[j][0];
                        const int& i1 = pairs[j][1];
                        double u = (0 - val[mapping[i0]]) / (val[mapping[i1]] - val[mapping[i0]]);
                        wPos[j] = (1 - u) * vPos[i0] + u * vPos[i1];
                        wCol[j] = (1 - u) * vCol[i0] + u * vCol[i1];
                        int index0 = min(tetra.vertex_[mapping[i0]], tetra.vertex_[mapping[i1]]);
                        int index1 = max(tetra.vertex_[mapping[i0]], tetra.vertex_[mapping[i1]]);
                        wKey[j] = vtxSize * index0 + index1;
                    }
                    addFace(
                        volObj.mesh2_, vtxMap,
                        wPos[0], wPos[1], wPos[2],
                        wCol[0], wCol[1], wCol[2],
                        wKey[0], wKey[1], wKey[2]);
                    addFace(
                        volObj.mesh2_, vtxMap,
                        wPos[0], wPos[2], wPos[3],
                        wCol[0], wCol[2], wCol[3],
                        wKey[0], wKey[2], wKey[3]);
                }
                break;
            case 7:
            case 11:
            case 13:
            case 14:
                {
                    Vector3d wPos[3];
                    Vector3d wCol[3];
                    int      wKey[3];
                    for (int j = 0; j < 3; ++j) {
                        double u = (0 - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
                        wPos[j] = (1 - u) * vPos[0] + u * vPos[j + 1];
                        wCol[j] = (1 - u) * vCol[0] + u * vCol[j + 1];
                        int index0 = min(tetra.vertex_[mapping[0]], tetra.vertex_[mapping[j + 1]]);
                        int index1 = max(tetra.vertex_[mapping[0]], tetra.vertex_[mapping[j + 1]]);
                        wKey[j] = vtxSize * index0 + index1;
                    }
                    addFace(
                        volObj.mesh2_, vtxMap,
                        wPos[2], wPos[0], wPos[1],
                        wCol[2], wCol[0], wCol[1],
                        wKey[2], wKey[0], wKey[1]);
                }
                break;
        }
    }
    // use OpenMesh feature of normal calculation
    mesh2.request_face_normals();
    mesh2.request_vertex_normals();
    mesh2.update_normals();
}
