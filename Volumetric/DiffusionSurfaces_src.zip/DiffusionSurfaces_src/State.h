#pragma once
#include <string>

class Core;

class State
{
protected:
    State(void) {}
    ~State(void) {}
public:
    // minimum set of required functions
    virtual void draw() {}
    virtual void OnLButtonDown(UINT nFlags, CPoint& point) {}
    virtual void OnLButtonUp  (UINT nFlags, CPoint& point) {}
    virtual void OnRButtonDown(UINT nFlags, CPoint& point) {}
    virtual void OnRButtonUp  (UINT nFlags, CPoint& point) {}
    virtual void OnMButtonDown(UINT nFlags, CPoint& point) {}
    virtual void OnMButtonUp  (UINT nFlags, CPoint& point) {}
    virtual void OnMouseMove  (UINT nFlags, CPoint& point) {}
    // optional set of functions
    virtual std::string message() { return ""; }
    virtual State* next() { return 0; }
    virtual bool isReady() { return false; }
    virtual void initialize() {}
    virtual void finalize  () {}
    virtual void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {}
    virtual void OnDropFiles  (const std::string& fname, const std::string& ext) {}
    virtual void OnMouseWheel (UINT nFlags, short zDelta, CPoint pt)  {}
    virtual void OnLButtonDblClk(UINT nFlags, CPoint point)  {}
};
