#include "StdAfx.h"
#include "StateCsHrz.h"
#include "StateDeleteFace.h"
#include "Core.h"
#include "my_atan2.h"
#include <stb_image.h>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;
}

string StateCsHrz::message() {
    string msg;
    msg += "Step 2: Sketch horizontal profiles\n";
    msg += "Mode: ";
    msg +=
        mode_ == MODE_DRAW       ? "Draw"       :
        mode_ == MODE_FOLD_ANGLE ? "Fold angle" :
        mode_ == MODE_DEFORM     ? "Deform"     :
        mode_ == MODE_SMOOTH     ? "Smooth"     : "BgImg";
    return msg;
}

void StateCsHrz::initialize() {
    core.ogl_.makeOpenGLCurrent();
    modeler.bgImgHrz_.fname_.clear();
    modeler.foldAngles_exemplar_.clear();
    modeler.foldAngles_exemplar_.resize(3, 2 * M_PI / 3);
    currentObjectID_ = 0;
    mode_ = MODE_DRAW;
    core.ogl_.setView(0, 0, 5, 0, 0, 0, 0, 1, 0);
    glLineWidth(5);
}
State* StateCsHrz::next() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    size_t numFold = modeler.foldAngles_exemplar_.size();
    modeler.type_ = numFold == 0 ? Modeler::TYPE_CYLIND : Modeler::TYPE_NFOLD;
    if (modeler.type_ == Modeler::TYPE_NFOLD) {
        for (size_t i = 0; i < sz_sweepObjects; ++i)
            if (modeler.sweepObjects_[i].type_ != SweepObject::TYPE_NFOLD2)
                modeler.sweepObjects_[i].type_ = SweepObject::TYPE_NFOLD1;
    }
    modeler.convert_strokeHrz_exemplar_xy_rt();
    return StateDeleteFace::getInstance();
}
bool StateCsHrz::isReady() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    size_t numFold = modeler.foldAngles_exemplar_.size();
    for (size_t i = 0; i < sz_sweepObjects; ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        if (sweepObj.strokeHrz_exemplar_xy_.empty())
            return false;
        if (modeler.type_ == Modeler::TYPE_NFOLD &&
            sweepObj.type_ == SweepObject::TYPE_NFOLD2 &&
            sweepObj.strokeHrz_exemplar_xy_.size() != numFold)
            return false;
        if (sweepObj.hasGrain_ && sweepObj.grainObject_.strokeHrz_.empty())
            return false;
    }
    return true;
}
void StateCsHrz::draw() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    SweepObject& currentSweepObj = modeler.sweepObjects_[currentObjectID_ - (isGrainMode ? sz_sweepObjects : 0)];
    
    BgImg& bgImgHrz = modeler.bgImgHrz_;
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    //glEnable(GL_BLEND);
    if (!isGrainMode && !bgImgHrz.fname_.empty()) {
        bgImgHrz.tex_.enable();
        bgImgHrz.tex_.bind();
        Drawer::drawTexturedQuad(bgImgHrz.cornerBL_, bgImgHrz.cornerBR_, bgImgHrz.cornerTL_, bgImgHrz.cornerTR_);
        bgImgHrz.tex_.unbind();
        bgImgHrz.tex_.disable();
        // draw frame
        Vector2d* ptr[4] = { &bgImgHrz.cornerBL_, &bgImgHrz.cornerBR_, &bgImgHrz.cornerTR_, &bgImgHrz.cornerTL_ };
        glColor3d(0.5, 0.5, 0.5);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < 4; ++i)
            glVertex2dv(ptr[i]->ptr());
        glEnd();
        glBegin(GL_POINTS);
        for (int i = 0; i < 4; ++i)
            glVertex2dv(ptr[i]->ptr());
        glEnd();
    }
    
    if (!isGrainMode) {
        // separatrices
        vector<double>& foldAngles = modeler.foldAngles_exemplar_;
        glColor4d(0, 0, 1, 0.5);
        double theta = 0;
        for (size_t i = 0; i < foldAngles.size(); theta += foldAngles[i], ++i) {
            Vector2d p(cos(theta), sin(theta));
            p *= 3;
            glBegin(GL_LINES);
            glVertex2d(0, 0);    glVertex2dv(p.ptr());
            glEnd();
        }
        glColor4d(0, 1, 0, 1);
        glBegin(GL_POINTS);
        glVertex2d(0, 0);
        glEnd();
        // strokeHrz samples corresponding to the currently selected strokeVrt
        for (size_t objID = 0; objID < sz_sweepObjects; ++objID) {
            vector<Polyline2d>& samples = modeler.sweepObjects_[objID].strokeHrz_exemplar_xy_;
            if (objID == currentObjectID_)
                glColor3d(0, 0, 0);
            else
                glColor3d(0.5, 0.5, 0.5);
            for (size_t i = 0; i < samples.size(); ++i) {
                Polyline2d& strokeHrz = samples[i];
                glBegin(GL_LINE_LOOP);
                for (size_t j = 0; j < strokeHrz.size(); ++j)
                    glVertex2dv(strokeHrz[j].ptr());
                glEnd();
            }
        }
    } else if (!currentSweepObj.grainObject_.strokeHrz_.empty()) {    // horizontal stroke corresponding to the current grain object
        Polyline2d& strokeHrz = currentSweepObj.grainObject_.strokeHrz_;
        Vector2d pointLmost( DBL_MAX, 0);
        Vector2d pointRmost(-DBL_MAX, 0);
        glColor3d(0, 0 ,0);
        glBegin(GL_LINE_LOOP);
        for (size_t i = 0; i < strokeHrz.size(); ++i) {
            Vector2d point = strokeHrz[i];
            if (point[0] < pointLmost[0])
                pointLmost = point;
            if (pointRmost[0] < point[0])
                pointRmost = point;
            glVertex2dv(strokeHrz[i].ptr());
        }
        glEnd();
        glBegin(GL_POINTS);
        glColor3d(0, 1, 1);    glVertex2dv(pointLmost.ptr());
        glColor3d(1, 1, 0);    glVertex2dv(pointRmost.ptr());
        glEnd();
    }
    // temporary stroke points
    if (!tempPoints_.empty()) {
        glColor3d(0, 0.5, 1);
        glBegin(GL_LINE_STRIP);
        for (size_t i = 0; i < tempPoints_.size(); ++i)
            glVertex2dv(tempPoints_[i].ptr());
        glEnd();
    }
    {   // corresponding CsVrt info
        glPushMatrix();
        glTranslated(1.5, 1, 0);
        glScaled(0.5, 0.5, 1);
        BgImg& bgImgVrt = modeler.bgImgVrt_;
        if (!bgImgVrt.fname_.empty()) {
            bgImgVrt.tex_.enable();
            bgImgVrt.tex_.bind();
            Drawer::drawTexturedQuad(bgImgVrt.cornerBL_, bgImgVrt.cornerBR_, bgImgVrt.cornerTL_, bgImgVrt.cornerTR_);
            bgImgVrt.tex_.unbind();
            bgImgVrt.tex_.disable();
        }
        glColor3d(0, 0, 0);
        if (!isGrainMode) {
            Polyline2d& strokeVrt = modeler.sweepObjects_[currentObjectID_].strokeVrt_;
            glBegin(strokeVrt.isLoop() ? GL_LINE_LOOP : GL_LINE_STRIP);
            for (size_t j = 0; j < strokeVrt.size(); ++j)
                glVertex2dv(strokeVrt[j].ptr());
            glEnd();
        } else {
            GrainObject& grainObject = modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_;
            Polyline2d& strokeL = grainObject.strokeVrtLeft_;
            Polyline2d& strokeR = grainObject.strokeVrtRight_;
            glBegin(GL_LINE_STRIP);
            for (size_t j = 0; j < strokeL.size(); ++j)
                glVertex2dv(strokeL[j].ptr());
            glEnd();
            glBegin(GL_LINE_STRIP);
            for (size_t j = 0; j < strokeR.size(); ++j)
                glVertex2dv(strokeR[j].ptr());
            glEnd();
        }
        glPopMatrix();
    }
}
void StateCsHrz::OnLButtonDown(UINT nFlags, CPoint& point) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    SweepObject& currentSweepObj = modeler.sweepObjects_[currentObjectID_ - (isGrainMode ? sz_sweepObjects : 0)];
    
    Vector3d start, ori;
    core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
    Vector2d point2d(start + (-start[2] / ori[2]) * ori);
    if (mode_ == MODE_FOLD_ANGLE) {
        vector<double>& foldAngles = modeler.foldAngles_exemplar_;
        if (foldAngles.empty()) return;
        double theta0 = my_atan2(point2d[1], point2d[0]);
        double theta = foldAngles[0];
        for (size_t i = 1; i < foldAngles.size(); ++i) {
            Vector2d r0(cos(theta0), sin(theta0));
            Vector2d r (cos(theta ), sin(theta ));
            if ((r - r0).length() < Modeler::THRESHOLD_UI_DISTANCE) {
                dragFoldAngle_[0] = &foldAngles[i - 1];
                dragFoldAngle_[1] = &foldAngles[i];
                dragFoldAngle_begin_ = theta - foldAngles[i - 1];
                dragFoldAngle_end_   = theta + foldAngles[i];
            }
            theta += foldAngles[i];
        }
    } else if (mode_ == MODE_BGIMG) {
        BgImg& bgImg = modeler.bgImgHrz_;
        Vector2d* ptr[4] = { &bgImg.cornerBL_, &bgImg.cornerBR_, &bgImg.cornerTL_, &bgImg.cornerTR_ };
        draggedCorner_ = 0;
        double dist_min = DBL_MAX;
        for (int i = 0; i < 4; ++i) {
            double d = (point2d - *ptr[i]).length();
            if (d < dist_min) {
                dist_min = d;
                draggedCorner_ = ptr[i];
            }
        }
        if (dist_min < Modeler::THRESHOLD_UI_DISTANCE) {
            bgImgMode_ = BGIMGMODE_CORNER;
            return;
        }
        dragPrev_ = point2d;
        Vector2d triangles[2][3] = {
            { bgImg.cornerBL_, bgImg.cornerBR_, bgImg.cornerTR_ }, 
            { bgImg.cornerBL_, bgImg.cornerTR_, bgImg.cornerTL_ }
        };
        bool flag = false;
        for (int i = 0; i < 2; ++i) {
            Vector3d baryCoord = Util::calcBarycentricCoord<double, 2>(triangles[i], point2d);
            if (0 < baryCoord[0] && 0 < baryCoord[1] && 0 < baryCoord[2]) {
                flag = true;
                break;
            }
        }
        bgImgMode_ = flag ? BGIMGMODE_TRANSLATE : BGIMGMODE_ROTATE;
    } else if (mode_ == MODE_SMOOTH) {
    } else if (mode_ == MODE_DRAW) {
        if (!isGrainMode) {
            if (currentSweepObj.type_ == SweepObject::TYPE_NFOLD2) {
                if (currentSweepObj.strokeHrz_exemplar_xy_.size() == modeler.foldAngles_exemplar_.size())
                    return;
            } else if (!currentSweepObj.strokeHrz_exemplar_xy_.empty())
                return;
        } else {
            if (!currentSweepObj.grainObject_.strokeHrz_.empty())
                return;
        }
        tempPoints_.push_back(point2d);
    } else if (mode_ == MODE_DEFORM) {
        double dist_min = DBL_MAX;
        if (isGrainMode) {
            Polyline2d& strokeHrz = currentSweepObj.grainObject_.strokeHrz_;
            for (size_t j = 0; j < strokeHrz.size(); ++j) {
                double d = (point2d - strokeHrz[j]).length();
                if (d < dist_min) {
                    dist_min = d;
                    rigid_target_ = &strokeHrz;
                    rigid_dragid_ = j;
                }
            }
        } else {
            for (size_t i = 0; i < currentSweepObj.strokeHrz_exemplar_xy_.size(); ++i) {
                Polyline2d& strokeHrz = currentSweepObj.strokeHrz_exemplar_xy_[i];
                for (size_t j = 0; j < strokeHrz.size(); ++j) {
                    double d = (point2d - strokeHrz[j]).length();
                    if (d < dist_min) {
                        dist_min = d;
                        rigid_target_ = &strokeHrz;
                        rigid_dragid_ = j;
                    }
                }
            }
        }
        if (dist_min < Modeler::THRESHOLD_UI_DISTANCE) {
            rigid_.init(*rigid_target_);
            rigid_dragstart_ = point2d;
            rigid_peelsize_ = 0;
        } else {
            rigid_target_ = 0;
        }
    }
}
void StateCsHrz::OnLButtonUp  (UINT nFlags, CPoint& point) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    SweepObject& currentSweepObj = modeler.sweepObjects_[currentObjectID_ - (isGrainMode ? sz_sweepObjects : 0)];
    
    switch (mode_) {
    case MODE_DRAW:
        if (tempPoints_.empty())
            return;
        if ((tempPoints_.back() - tempPoints_.front()).length() < Modeler::THRESHOLD_UI_DISTANCE) {
            tempPoints_.pop_back();
            Polyline2d strokeHrz(tempPoints_, true);
            double length = strokeHrz.length();
            int numDiv = length / Modeler::STROKE_SEGMENT_LENGTH + 3;
            strokeHrz.resample(numDiv);
            if (isGrainMode)
                currentSweepObj.grainObject_.strokeHrz_ = strokeHrz;
            else
                currentSweepObj.strokeHrz_exemplar_xy_.push_back(strokeHrz);
        }
        tempPoints_.clear();
        break;
    case MODE_DEFORM:
        if (!rigid_target_)
            return;
        Polyline2d& strokeHrz = *rigid_target_;
        double length = strokeHrz.length();
        int numDiv = length / Modeler::STROKE_SEGMENT_LENGTH + 3;
        if ((nFlags & MK_SHIFT) == 0)
            strokeHrz.resample(numDiv);
        break;
    }
    core.ogl_.RedrawWindow();
}
void StateCsHrz::OnMouseMove  (UINT nFlags, CPoint& point) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    SweepObject& currentSweepObj = modeler.sweepObjects_[currentObjectID_ - (isGrainMode ? sz_sweepObjects : 0)];
    
    core.ogl_.MouseMove(point);
    if (!core.eventHandler_.isLButtonDown_)
        return;
    Vector3d start, ori;
    core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
    Vector2d point2d(start + (-start[2] / ori[2]) * ori);
    switch (mode_) {
    case MODE_BGIMG:
        if (bgImgMode_ == BGIMGMODE_CORNER) {
            *draggedCorner_ = point2d;
        } else if (bgImgMode_ == BGIMGMODE_ROTATE || bgImgMode_ == BGIMGMODE_TRANSLATE) {
            BgImg& bgImg = modeler.bgImgHrz_;
            Vector2d* ptr[4] = { &bgImg.cornerBL_, &bgImg.cornerBR_, &bgImg.cornerTL_, &bgImg.cornerTR_ };
            if (bgImgMode_ == BGIMGMODE_ROTATE) {
                double theta = point2d[0] - dragPrev_[0];
                Matrix2x2d R(
                    cos(theta), -sin(theta),
                    sin(theta),  cos(theta));
                Vector2d center;
                for (int i = 0; i < 4; ++i) center += *ptr[i];
                center *= 0.25;
                for (int i = 0; i < 4; ++i)
                    *ptr[i] = R * (*ptr[i] - center) + center;
            } else if (bgImgMode_ == BGIMGMODE_TRANSLATE) {
                Vector2d delta = point2d - dragPrev_;
                for (int i = 0; i < 4; ++i) *ptr[i] += delta;
            }
            dragPrev_ = point2d;
        }
        break;
    case MODE_FOLD_ANGLE:
        {
            double theta0 = my_atan2(point2d[1], point2d[0]);
            *dragFoldAngle_[0] = theta0             - dragFoldAngle_begin_;
            *dragFoldAngle_[1] = dragFoldAngle_end_ - theta0;
            core.ogl_.RedrawWindow();
        } 
        break;
    case MODE_DRAW:
        if (tempPoints_.empty())
            return;
        tempPoints_.push_back(point2d);
        break;
    case MODE_DEFORM:
        {
            if (!rigid_target_)
                return;
            double dist = (rigid_dragstart_ - point2d).length();
            int peelsize = static_cast<int>(dist / Modeler::THRESHOLD_UI_RIGID_PEEL) + 1;
            if (rigid_peelsize_ < peelsize) {
                rigid_peelsize_ = peelsize;
                size_t num_vtx = rigid_target_->size();
                vector<int> is_vtx_constrained(num_vtx, 1);
                int vtxid = rigid_dragid_;
                for (int i = 0; i <= rigid_peelsize_; ++i) {
                    is_vtx_constrained[vtxid] = 0;
                    if (vtxid == num_vtx - 1)
                        vtxid = 0;
                    else
                        ++vtxid;
                }
                vtxid = rigid_dragid_;
                for (int i = 0; i <= rigid_peelsize_; ++i) {
                    is_vtx_constrained[vtxid] = 0;
                    if (vtxid == 0)
                        vtxid = num_vtx - 1;
                    else
                        --vtxid;
                }
                is_vtx_constrained[rigid_dragid_] = 1;
                rigid_.compile(is_vtx_constrained);
            }
            (*rigid_target_)[rigid_dragid_] = point2d;
            *rigid_target_ = rigid_.deform(rigid_target_->points());
        }
        break;
    case MODE_SMOOTH:
        {
            double dist_min = DBL_MAX;
            Polyline2d* target_stroke = 0;
            size_t target_id;
            if (isGrainMode) {
                Polyline2d& strokeHrz = currentSweepObj.grainObject_.strokeHrz_;
                for (size_t j = 0; j < strokeHrz.size(); ++j) {
                    double dist = (point2d - strokeHrz[j]).length();
                    if (dist < dist_min) {
                        dist_min = dist;
                        target_stroke = &strokeHrz;
                        target_id = j;
                    }
                }
            } else {
                for (size_t i = 0; i < currentSweepObj.strokeHrz_exemplar_xy_.size(); ++i) {
                    Polyline2d& strokeHrz = currentSweepObj.strokeHrz_exemplar_xy_[i];
                    for (size_t j = 0; j < strokeHrz.size(); ++j) {
                        double dist = (point2d - strokeHrz[j]).length();
                        if (dist < dist_min) {
                            dist_min = dist;
                            target_stroke = &strokeHrz;
                            target_id = j;
                        }
                    }
                }
            }
            if (Modeler::THRESHOLD_UI_DISTANCE < dist_min)
                return;
            size_t target_id_prev = target_id == 0 ? target_stroke->size() - 1 : target_id - 1;
            size_t target_id_next = target_id == target_stroke->size() - 1 ? 0 : target_id + 1;
            Vector2d& target_point = (*target_stroke)[target_id];
            target_point = 0.5 * target_point + 0.25 * (*target_stroke)[target_id_prev] + 0.25 * (*target_stroke)[target_id_next];
        }
        break;
    }
    core.ogl_.RedrawWindow();
}
void StateCsHrz::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_2D(nFlags, point); }
void StateCsHrz::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp     (nFlags, point); }
void StateCsHrz::OnDropFiles(const std::string& fname, const std::string& ext) {
    if (ext == "step2") {
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_CsHrz(ifs)) {
            cout << "Error occurred in Modeler::load_CsHrz()" << endl;
            return;
        }
        core.ogl_.RedrawWindow();
        return;
    }
    if (ext == "jpg" || ext == "png" || ext == "bmp") {
        BgImg& bgImg = modeler.bgImgHrz_;
        bgImg.fname_ = fname;
        bgImg.load();
        core.ogl_.RedrawWindow();
        return;
    }
}
void StateCsHrz::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    bool isGrainMode = sz_sweepObjects <= currentObjectID_;
    SweepObject& currentSweepObj = modeler.sweepObjects_[currentObjectID_ - (isGrainMode ? sz_sweepObjects : 0)];
    
    switch (nChar) {
    case VK_F2:
    case VK_F3:
        Modeler::STROKE_SEGMENT_LENGTH *= nChar == VK_F2 ? (1/1.1) : 1.1;
        cout << "Modeler::STROKE_SEGMENT_LENGTH=" << Modeler::STROKE_SEGMENT_LENGTH << "\n";
        break;
    case VK_F4:
    case VK_F5:
        Modeler::THRESHOLD_UI_DISTANCE *= nChar == VK_F4 ? (1/1.1) : 1.1;
        cout << "Modeler::THRESHOLD_UI_DISTANCE=" << Modeler::THRESHOLD_UI_DISTANCE << "\n";
        break;
    case ' ':
        ++currentObjectID_;
        if (sz_sweepObjects <= currentObjectID_) {
            while (true) {
                if (currentObjectID_ == 2 * sz_sweepObjects) {
                    currentObjectID_ = 0;
                    break;
                }
                if (modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].hasGrain_)
                    break;
                ++currentObjectID_;
            }
        }
        core.ogl_.RedrawWindow();
        break;
    case VK_UP:
    case VK_DOWN:
        {
            size_t numFold = modeler.foldAngles_exemplar_.size();
            if (nChar == VK_UP) {
                ++numFold;
                if (numFold == 1)
                    numFold = 2;
            } else {    // (nChar == VK_DOWN)
                if (numFold == 0 ||
                    modeler.type_ == Modeler::TYPE_NFOLD && numFold == 2)
                    return;
                --numFold;
                if (numFold == 1)
                    numFold = 0;
            }
            modeler.foldAngles_exemplar_.resize(numFold);
            for (size_t i = 0; i < numFold; ++i)
                modeler.foldAngles_exemplar_[i] = 2 * M_PI / numFold;
            core.ogl_.RedrawWindow();
        }
        break;
    case 'S':
        {
            CFileDialog dlg(FALSE, "step2", "*.step2", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step2 files|*.step2||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_CsHrz(ofs);
        }
        break;
    case 'Q':
    case 'W':
    case 'E':
    case 'R':
    case 'T':
        mode_ = 
            nChar == 'Q' ? MODE_DRAW   :
            nChar == 'W' ? MODE_DEFORM :
            nChar == 'E' ? MODE_SMOOTH :
            nChar == 'R' ? MODE_BGIMG  : MODE_FOLD_ANGLE;
        core.ogl_.RedrawWindow();
        break;
    case VK_DELETE:
        if (isGrainMode) {
            currentSweepObj.grainObject_.strokeHrz_.clear();
        } else if (!currentSweepObj.strokeHrz_exemplar_xy_.empty()) {
            currentSweepObj.strokeHrz_exemplar_xy_.pop_back();
        } else if (mode_ == MODE_BGIMG) {
            modeler.bgImgHrz_.fname_.clear();
        }
        core.ogl_.RedrawWindow();
        break;
    }
}
