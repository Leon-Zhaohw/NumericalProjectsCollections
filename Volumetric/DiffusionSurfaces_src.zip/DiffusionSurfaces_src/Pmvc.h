#pragma once
#include <KLIB/GLUtil.h>
#include <KLIB/GLSLUtil.h>

template <class TDiffuseAlgorithm>
struct VolumeObjectT;

template <class TPmvcAlgorithm>
struct DiffusePmvcT;

struct Pmvc {
    typedef VolumeObjectT<DiffusePmvcT<Pmvc> > VolumeObject;
    
    struct ObjectInfo {
        KLIB::DisplayList displayList_;
        double zNear_, zFar_;
        ObjectInfo ()
            : zNear_()
            , zFar_()
        {}
        void gl_init() {}
        void gl_deinit() {}
        void preprocess(VolumeObject& volObj);
    };
    int resolution_;       // # of cube map pixels = 6 * resolution^2
    int maxTextureSize_;
    KLIB::FramebufferObject fbo_;
    KLIB::TextureObject texDepth_;
    KLIB::TextureObject texColor_[2];          // pair of buffers for ping-pong reduction
    KLIB::TextureObject texAreaWeight_;
    KLIB::ProgramObject shaderIntegralPrepare_;
    KLIB::ProgramObject shaderIntegralReduce_;
    
    Pmvc(unsigned int resolution = 32);
    void gl_init();
    void gl_deinit();
    std::vector<KLIB::Vector3d> getColor(const ObjectInfo& objInfo, const std::vector<KLIB::Vector3d>& posList) const;
private:
    std::vector<KLIB::Vector3d> integrate(const ObjectInfo& objInfo, size_t sampleNum) const;
};
