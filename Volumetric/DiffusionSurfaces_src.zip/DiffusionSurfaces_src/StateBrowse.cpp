#include "StdAfx.h"
#include "StateBrowse.h"
#include "Core.h"
#include <KLIB/GLSLNoise.h>
using namespace std;
using namespace KLIB;

namespace {

Core& core = Core::getInstance();
OGL& ogl = core.ogl_;
VolumeObject& volObj = core.volObj_;

template<class TMesh>
void drawSrfMesh(TMesh& mesh, bool isColorOpposite) {
    glBegin(GL_TRIANGLES);
    for (TMesh::FIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); ++f_it) {
        // front
        TMesh::HHandle hhandle = mesh.halfedge_handle(f_it);
        for (int i = 0; i < 3; ++i) {
            TMesh::VHandle vhandle = mesh.to_vertex_handle(hhandle);
            Vector3d& color = isColorOpposite ? mesh.data(vhandle).back_color_ : mesh.data(vhandle).color_;
            const Vector3d& normal = mesh.normal(vhandle);
            Vector3d& point = mesh.point(vhandle);
            glColor3d (color );
            glNormal3d(normal);
            glTexCoord3d(point);
            glVertex3d(point );
            hhandle = mesh.next_halfedge_handle(hhandle);
        }
        // back
        for (int i = 0; i < 3; ++i) {
            TMesh::VHandle vhandle = mesh.to_vertex_handle(hhandle);
            Vector3d& color = isColorOpposite ? mesh.data(vhandle).color_ : mesh.data(vhandle).back_color_;
            Vector3d  normal = -mesh.normal(vhandle);
            Vector3d& point  = mesh.point(vhandle);
            glColor3d (color );
            glNormal3d(normal);
            glTexCoord3d(point);
            glVertex3d(point );
            hhandle = mesh.prev_halfedge_handle(hhandle);
        }
    }
    glEnd();
}

}

void StateBrowse::initialize() {
    if (!volObj.srfMeshes_.empty()) {
        int total_n_vertices = 0;
        int total_n_faces    = 0;
        for (size_t i = 0; i < volObj.srfMeshes_.size(); ++i) {
            Mesh0& mesh0 = volObj.srfMeshes_[i].mesh0_;
            total_n_vertices += mesh0.n_vertices();
            total_n_faces    += mesh0.n_faces();
        }
        cout << "total number of vertices/faces: " << total_n_vertices << "/" << total_n_faces << "\n";
        currentMeshID_ = -1;
        volObj.calcAuxiliaryInfo();
        
        ogl.viewParam_.focusPoint_ = volObj.bbox_.center();
        ogl.viewParam_.eyePoint_   = ogl.viewParam_.focusPoint_ + Vector3d(0, 0, volObj.bbox_.diagonal() * 2);
        ogl.viewParam_.upDirection_.set(0, 1, 0);
        ogl.updateView();
        
        double bbmax = volObj.bbox_.max_.elemMax();
        double bbmin = volObj.bbox_.min_.elemMin();
        core.cutAlgorithm_.param_.slice_top_    = 0.5 * bbmax + 0.5 * bbmin;
        core.cutAlgorithm_.param_.slice_bottom_ = -0.1 * bbmax + 1.1 * bbmin;
    }
    volObj.cutDone_ = false;
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
}
void StateBrowse::draw() {
    if (onDrawCompute_) {
        volObj.updateSilhouette();
        onDrawCompute_ = false;
    }
    
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);
    glLineWidth(1);
    
    // enable noise shader
    core.noiseShader_.enable();
    core.noiseShader_.setUniform1f("u_time", 0.0f);
    core.noiseShader_.setUniform1i("u_flagNoise", showNoise_);
    GLSLNoise::bindPermTexture(core.noiseShader_, 0);
    GLSLNoise::bindGradTexture(core.noiseShader_, 1);
    core.noiseShader_.setUniform1i("u_texWeight0", 2);
    core.noiseShader_.setUniform1i("u_texWeight1", 3);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_3D, volObj.noiseWeight_.texID_[0]);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_3D, volObj.noiseWeight_.texID_[1]);
    
    if (!volObj.cutDone_) {
        if (showAllMesh_) {
            glEnable(GL_BLEND);
            glDisable(GL_DEPTH_TEST);
        }
        double alpha = showAllMesh_ ? 0.75 : 1.0;
        for (size_t meshid = 0; meshid < volObj.srfMeshes_.size(); ++meshid) {
            Mesh0& mesh0 = volObj.srfMeshes_[meshid].mesh0_;
            core.noiseShader_.setUniform1i("u_flagLighting", 1);
            Drawer::draw_mesh_colored(mesh0, alpha);
            if (showEdge_) {
                if (meshid == currentMeshID_)
                    glColor4d(1, 0, 0, alpha);
                else
                    glColor4d(0, 0, 0, alpha);
                core.noiseShader_.setUniform1i("u_flagLighting", 0);
                Drawer::draw_mesh_edge(mesh0);
            }
        }
    } else {
        // mesh0 or mesh3
        for (vector<SrfMesh>::iterator it = volObj.srfMeshes_.begin(); it != volObj.srfMeshes_.end(); ++it) {
            Mesh0& mesh0 = it->mesh0_;
            Mesh3& mesh3 = it->mesh3_;
            SrfMesh::ShowFlag& flag = it->showFlag_;
            if (flag.srf_ == SrfMesh::ShowFlag::NONE)
                continue;
            if (flag.srf_ == SrfMesh::ShowFlag::MESH0 || flag.srf_ == SrfMesh::ShowFlag::MESH0_OPPOSITE) {
                core.noiseShader_.setUniform1i("u_flagLighting", 1);
                drawSrfMesh(mesh0, flag.srf_ == SrfMesh::ShowFlag::MESH0_OPPOSITE);
                if (showEdge_) {
                    glColor3d(0, 0, 0);
                    core.noiseShader_.setUniform1i("u_flagLighting", 0);
                    Drawer::draw_mesh_edge(mesh0);
                }
            } else {
                core.noiseShader_.setUniform1i("u_flagLighting", 1);
                drawSrfMesh(mesh3, flag.srf_ == SrfMesh::ShowFlag::MESH3_OPPOSITE);
                if (showEdge_) {
                    glColor3d(0, 0, 0);
                    core.noiseShader_.setUniform1i("u_flagLighting", 0);
                    Drawer::draw_mesh_edge(mesh3);
                }
            }
        }
        // mesh2
        Mesh2& mesh2 = volObj.mesh2_;
        core.noiseShader_.setUniform1i("u_flagLighting", 1);
        glBegin(GL_TRIANGLES);
        for (Mesh2::FIter f_it = mesh2.faces_begin(); f_it != mesh2.faces_end(); ++f_it) {
            int label = mesh2.data(f_it).label_;
            assert(label != -2);
            if (label == -1)
                continue;
            if (!volObj.srfMeshes_[label].showFlag_.cs_)
                continue;
            for (Mesh2::FVIter fv_it = mesh2.fv_iter(f_it); fv_it; ++fv_it) {
                Mesh2::VertexData& vdata = mesh2.data(fv_it);
                glColor3d(mesh2.data(fv_it).color_);
                glNormal3d(mesh2.normal(fv_it));
                Vector3d& p = mesh2.point(fv_it);
                glTexCoord3d(p);
                glVertex3d(p);
            }
        }
        glEnd();
        if (showEdge_) {
            glDisable(GL_POLYGON_OFFSET_FILL);
            glColor3d(0, 0, 0);
            core.noiseShader_.setUniform1i("u_flagLighting", 0);
            for (Mesh2::FIter f_it = mesh2.faces_begin(); f_it != mesh2.faces_end(); ++f_it) {
                int label = mesh2.data(f_it).label_;
                assert(label != -2);
                if (label == -1)
                    continue;
                if (!volObj.srfMeshes_[label].showFlag_.cs_)
                    continue;
                glBegin(GL_LINE_LOOP);
                for (Mesh2::FVIter fv_it = mesh2.fv_iter(f_it); fv_it; ++fv_it)
                    glVertex3d(mesh2.point(fv_it));
                glEnd();
            }
            glEnable(GL_POLYGON_OFFSET_FILL);
        }
    }
    
    // disable noise shader
    glBindTexture(GL_TEXTURE_3D, 0);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_3D, 0);
    glActiveTexture(GL_TEXTURE0);
    GLSLNoise::unbindTexture(0);
    GLSLNoise::unbindTexture(1);
    core.noiseShader_.disable();
    
    // draw NPR curves
    if (showSilhouette_)
        volObj.silRenderer_.gl_draw();
    
    // cutting stroke
    glLineWidth(5);
    if (core.cutAlgorithm_.param_.mode_ == CutParam::FREEFORM && !volObj.cutDone_) {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor3d(1, 0, 0);
        glBegin(GL_LINE_STRIP);
        for (size_t i = 0; i < core.cutAlgorithm_.param_.freeform_stroke3d_.size(); ++i)
            glVertex3dv(core.cutAlgorithm_.param_.freeform_stroke3d_[i].ptr());
        glEnd();
    }
    
    glPopAttrib();
}
void StateBrowse::OnLButtonDown(UINT nFlags, CPoint& point) {
    Vector2d screenPos(point.x, point.y);
    Vector3d worldPos = ogl.unproject(screenPos);
    // initialize cut
    core.cutAlgorithm_.param_.freeform_stroke2d_.clear();
    core.cutAlgorithm_.param_.freeform_stroke3d_.clear();
    core.cutAlgorithm_.param_.mode_ = CutParam::FREEFORM;
    core.cutAlgorithm_.param_.freeform_stroke2d_.push_back(screenPos);
    core.cutAlgorithm_.param_.freeform_stroke3d_.push_back(worldPos);
    volObj.cutDone_ = false;
    volObj.silRenderer_.clear();
    if (showSilhouette_)
        onDrawCompute_ = true;
    ogl.RedrawWindow();
}
void StateBrowse::OnLButtonUp  (UINT nFlags, CPoint& point) {
    if (core.cutAlgorithm_.param_.freeform_stroke2d_.size() < 5) {   // clear cross section
        core.cutAlgorithm_.param_.freeform_stroke2d_.clear();
        core.cutAlgorithm_.param_.freeform_stroke3d_.clear();
    } else {    // create cross section
        core.cutAlgorithm_.cut(volObj);
        if (showSilhouette_)
            onDrawCompute_ = true;
    }
    ogl.RedrawWindow();
}
void StateBrowse::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateBrowse::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateBrowse::OnMButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnMButtonDown(nFlags, point); }
void StateBrowse::OnMButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnMButtonUp  (nFlags, point); }
void StateBrowse::OnMouseMove  (UINT nFlags, CPoint& point) {
    if (core.eventHandler_.isLButtonDown_) {
        Vector2d screenPos(point.x, point.y);
        Vector3d worldPos = ogl.unproject(screenPos);
        core.cutAlgorithm_.param_.freeform_stroke2d_.push_back(screenPos);
        core.cutAlgorithm_.param_.freeform_stroke3d_.push_back(worldPos);
        ogl.RedrawWindow();
    } else if (core.eventHandler_.isRButtonDown_) {
        if (showSilhouette_)
            onDrawCompute_ = true;
        core.eventHandler_.default_OnMouseMove(nFlags, point);
    }
}
void StateBrowse::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_srfMeshes = volObj.srfMeshes_.size();
    switch (nChar) {
    // change rendering options
    case 'Q':
        if (!showSilhouette_)
            onDrawCompute_ = true;
    case 'W':
    case 'E':
    case 'R':
        {
            bool& flag =
                nChar == 'Q' ? showSilhouette_ :
                nChar == 'W' ? showNoise_      :
                nChar == 'E' ? showAllMesh_    : showEdge_;
            flag = !flag;
            ogl.RedrawWindow();
        }
        break;
    // change which side of surface to show
    case ' ':
        currentMeshID_ = (currentMeshID_ == sz_srfMeshes - 1) ? -1 : (currentMeshID_ + 1);
        ogl.RedrawWindow();
        break;
    case 'T':
    case 'Y':
        if (currentMeshID_ != -1) {
            SrfMesh::ShowFlag& showFlag = volObj.srfMeshes_[currentMeshID_].showFlag_;
            if (nChar == 'T') {
                showFlag.srf_ = SrfMesh::ShowFlag::Srf((showFlag.srf_ + 1) % 5);
                char* flag_name[5] = { "MESH0", "MESH3", "MESH0_OPPOSITE", "MESH3_OPPOSITE", "NONE" };
                cout << "ShowFlag::Srf = " << flag_name[int(showFlag.srf_)] << endl;
                volObj.updateSilhouette();
            } else
                showFlag.cs_ = !showFlag.cs_;
            ogl.RedrawWindow();
        }
        break;
    // change cutting mode
    case VK_LEFT:
    case VK_RIGHT:
        paramDelta_ *= nChar == VK_RIGHT ? 10 : 0.1;
        cout << "paramDelta: " << paramDelta_ << endl;
        break;
    case VK_UP:
    case VK_DOWN:
    case 'U':
        {
            CutParam& param = core.cutAlgorithm_.param_;
            if (nChar == 'U') {
                param.mode_ = CutParam::Mode((param.mode_ + 1) % 5);
                char* mode_name[5] = { "freeform", "x-slice", "y-slice", "z-slice", "wedge" };
                cout << "CutParam mode: " << mode_name[int(param.mode_)] << endl;
            } else if (param.mode_ != CutParam::FREEFORM) {
                double& target = param.mode_ == CutParam::WEDGE ? param.wedge_end_ : param.slice_top_;
                target += nChar == VK_UP ? paramDelta_ : -paramDelta_;
                cout << "CutParam " << (param.mode_ == CutParam::WEDGE ? "wedge_end" : "slice_top") << ": " << target << endl;
            }
        }
        break;
    case VK_RETURN:
        if (core.cutAlgorithm_.param_.mode_ == CutParam::FREEFORM)
            return;
        core.cutAlgorithm_.cut(volObj);
        if (showSilhouette_)
            onDrawCompute_ = true;
        ogl.RedrawWindow();
        break;
    case 'S':   // save to *.piece file
        {
            CFileDialog dlg(FALSE, "piece", "*.piece", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "piece files|*.piece||");
            if (dlg.DoModal() != IDOK)
                return;
            Piece piece = volObj.convertToPiece();
            piece.save(dlg.GetPathName());
        }
        break;
    case 'C':       // save freeform cutting and following view info
        {
            CFileDialog dlg(FALSE, "cutinfo", "*.cutinfo", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "cutinfo files|*.cutinfo||");
            if (dlg.DoModal() != IDOK)
                return;
            ofstream ofs(dlg.GetPathName(), ios::binary);
            core.cutAlgorithm_.param_.save(ofs);
        }
        break;
    }
}
void StateBrowse::OnDropFiles(const string& fname, const string& ext) {
    if (ext == "xml" || ext == "dss") {
        if (ext == "xml")
            volObj.loadXML(fname.c_str());
        else
            volObj.loadDSS(fname.c_str());
        initialize();
        ogl.RedrawWindow();
    } else if (ext == "noise") {
        volObj.noiseWeight_.load(fname.c_str());
        ogl.RedrawWindow();
    } else if (ext == "cutinfo") {
        ifstream ifs(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        core.cutAlgorithm_.param_.load(ifs);
        core.cutAlgorithm_.cut(volObj);
        if (showSilhouette_)
            onDrawCompute_ = true;
        ogl.RedrawWindow();
    }
}

StateBrowse::StateBrowse()
    : showSilhouette_(false)
    , showNoise_     (false)
    , showAllMesh_   (false)
    , showEdge_      (false)
    , onDrawCompute_(false)
    , currentMeshID_(-1)
    , paramDelta_(1.0)
{}

