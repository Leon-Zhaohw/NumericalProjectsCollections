#pragma once
#include <KLIB/Vector.h>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

// Mesh1: intermediate mesh data before making mesh2 (edge is not yet duplicated, has two-sided colors)
struct Mesh1Traits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3d Point;
    typedef KLIB::Vector3d Normal;
    enum VertexType { VERTEX_INTERIOR, VERTEX_BOUNDARY, VERTEX_BOUNDARY_SPLIT };
    struct VertexOrientInfo {       // information required for determining which side is which for Mesh2 face
        std::vector<KLIB::Vector2d> normal2ds_;      // 2d normal of adjacent 2 split edges
        std::vector<KLIB::Vector2d> outEdge2ds_;     // 2d outward edge vector of adjacent 2 split edges
        enum Strategy { STRATEGY_AND, STRATEGY_OR } strategy_;         // strategy of how to detemine isFront (if (strategy == AND) isFront = (normal2ds_[0] | d) > 0 && (normal2ds_[1] | d) > 0)
        VertexOrientInfo() : strategy_(STRATEGY_AND) {}
    };
    VertexTraits {
    public:
        VertexType type_;                   // Boundary or Interior
        KLIB::Vector2d point2d_;            // 2D parameterized position
        VertexOrientInfo orientInfo_;       // orientInfo 
        KLIB::Vector3d color_;
        KLIB::Vector3d back_color_;
        int mesh2_vid_;
        int back_mesh2_vid_;
        int mesh0_id_;          // ID of Mesh0 from which this vertex is derived
        VertexT()
            : type_(VERTEX_INTERIOR)
            , mesh2_vid_(-1)
            , back_mesh2_vid_(-1)
            , mesh0_id_(-1)
        {}
        // debug
        int              dbg_id_;
        std::vector<int> dbg_vf_;
        std::vector<int> dbg_ve_;
        std::vector<int> dbg_vv_;
        bool             dbg_isOpenEnd_;
        bool             dbg_isSteiner_;
        int              dbg_mesh0_id_;         // id of mesh0
        int              dbg_mesh0_eid_;        // if this vertex comes from crossing on mesh0 edge, holds its index, otherwise -1
        std::vector<KLIB::Vector3d> dbg_normal3ds_;
    };
    enum EdgeType { EDGE_INTERIOR, EDGE_BOUNDARY, EDGE_BOUNDARY_SPLIT };
    EdgeTraits {
    public:
        EdgeType type_;
        KLIB::Vector2d normal2d_;     // normal direction derived from mesh0 face's normal
        int mesh0_id_;          // ID of Mesh0 from which this vertex is derived
        EdgeT()
            : type_(EDGE_INTERIOR)
            , mesh0_id_(-1)
        {}
        // debug
        int dbg_id_;
        std::vector<int> dbg_ev_;
        std::vector<int> dbg_ef_;
        KLIB::Vector3d dbg_normal3d_;     // normal direction derived from mesh0 face's normal
    };
    FaceTraits {
    public:
        KLIB::Vector2d barycenter2d_;
        int mesh2_fid_;         // needed for NPR line drawing of wedge cut
        FaceT() : mesh2_fid_(-1) {}
        // debug
        int              dbg_id_;
        std::vector<int> dbg_fv_;
        std::vector<int> dbg_fe_;
        std::vector<int> dbg_ff_;
        KLIB::Vector3d   dbg_barycenter3d_;
    };
};
//typedef OpenMesh::TriMesh_ArrayKernelT<Mesh1Traits> Mesh1;
struct Mesh1 : public OpenMesh::TriMesh_ArrayKernelT<Mesh1Traits> {};

