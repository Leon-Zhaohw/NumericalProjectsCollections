Diffusion Surfaces demo software usage (January 2011)
    Kenshi Takayama
    kenshi84@gmail.com
    http://www-ui.is.s.u-tokyo.ac.jp/~kenshi/

1. Overview

    In this document, a term `VolumeObject' refers to the data structure representing a volumetric object defined by diffusion surfaces (i.e., a VolumeObject consists of a set of 3D surfaces with colors on both sides). This demo has three modes: modeling, browsing, and salad. The modeling mode allows you to create a VolumeObject representing rotationally symmetric objects (e.g., fruit and veggie) by skething and painting. The browsing mode allows you to load a VolumeObject and see its cross-section. You can save the cut pieces of VolumeObject and load them in the salad mode to create interesting 3D scenes (e.g., fruit salad) with many cut pieces of VolumeObjects.

2. Camera control, common operations

    Both in 2D/3D, the camera control is always done by dragging with the right mouse button. In 3D, you can rotate the view by simply dragging, and pan the view by dragging while holding [CTRL]. In 2D, you can pan the view by simply dragging. Both in 2D/3D, you can zoom in/out by dragging vertically at the rightmost part of the canvas. All the other operations (e.g., freeform cutting, curve sketching) are done through the left mouse button. Loading of any data from files to the system is always done by dragging a file from the Explorer and dropping it to the canvas.

3. Browsing mode

    You can load an *.xml file describing a VolumeObject (or a *.dss file which is the binary version of the same data). You can cut the VolumeObject by drawing a freeform stroke; the left side of the stroke will be cut away. You can save the current cut piece as a *.piece file by pressing [S]. You can toggle the artistic silhouette and the Perlin noise effects on/off by pressing [Q] and [W] respectively (this is also common to the Salad mode). You can change the noise parameter by loading a *.noise file. You can discard the current cut piece by clicking anywhere on the canvas. Before cutting, You can enable/disable the transparent visualization of diffuion surfaces by pressing [E]. You can visualize the mesh edges by pressing [R].

4. Modeling mode

    Our interface is designed specifically for modeling rotationally symmetric objects; please refer to the paper for more details. In this demo, the modeling process consists of several steps which are detailed below. When you are done in each step, you can proceed to the next step by clicking the `Next' button on the toolbar (or by pressing [TAB]). You can return to the first step at any time by clicking the `Home' button. In each step, you can save the intermediate modeling data as *.stepX files by pressing [S].

4.1. Step 1: Sketch vertical profiles

    The system shows a vertical line in green representing the axis of symmetry. You can draw curves only on its right. This step has 5 modes in which you can: (1)draw curves[Q], (2)deform curves[W], (3)smooth curves[E], (4)position the background image[R], and (5)draw curves for grains[T] (press the corresponding keys to switch between these modes). You can load any bmp/jpg/png file as a guide image.
    In the `Draw' mode, you can draw either open or closed curves. Drawing a closed curve means you are creating a geometry of TYPE-II in N-fold symmetry (see the paper for more details). You can delete the most recently created curve by pressing [DELETE].
    In the `Deform' mode, you can deform any existing curves by dragging curve vertices. After every deformation applied to a curve, the curve vertices are resampled evenly with a specified segment length (you can avoid this resampling by releasing the mouse button while holding [SHIFT]). You can decrease/increase the curve resampling segment length by pressing [F2]/[F3] (the value appears in the prompt).
    In the `Smooth' mode, you can smooth curves by dragging (or rubbing) over them. No resampling is invoked after smoothing.
    In the `BgImg' mode, you can translate the background image by dragging on the image. If you drag outside the image, it will be rotated. You can also drag the four corners of the image individually. You can clear the loaded image by pressing [DELETE].
    The `Draw grain' mode is a bit complicated. First you select a `base' geometry on which the grain will be distributed later. You can change the currently selected base curve shown in purple by pressing [SPACE]. Then you draw a pair of open curves near the base curve.

4.2. Step 2: Sketch horizontal profiles

    The system shows a green point representing the axis of symmetry, and N (initially N=3) blue lines emanating from the green point representing the separators of N symmetry folds. On the upper right you see one of the vertical curves you have sketched in Step 1. For each vertical curve, you can draw a closed curve (for the case of cylindrical symmetry, Type-I geometry in N-fold symmetry, or grains) or a set of N closed curves (for the case of Type-II geometry in N-fold symmetry). Press [SPACE] to switch the currently selected vertical curve. This step has 5 modes in which you can: (1)draw curves[Q], (2)deform curves[W], (3)smooth curves[E], (4)position the background image[R], and (5)adjust the fold angles[T]. Operations for drawing curves and manipulating the background image are the same as in Step 1. You must always draw closed curves in a counterclockwise way.
    In the `Fold angle' mode, you can move the blue separators by dragging them. You can increase/decrease the number of symmetry folds N by pressing [UP]/[DOWN]. N=0 means that the object is of cylindrical symmetry.

4.3. Step 3: Delete unwanted surface regions

    This is an optional step where you can delete some unwanted regions of the surfaces. You can switch the current surface by pressing [SPACE] (this is common to the later steps). You can draw a freeform stroke to delete the surface part that falls on the left side of the stroke. This can be repeated as many times as desired. You can revert all the deletion applied to the current surface by clicking anywhere on the canvas.

4.4. Step 4: Distribute grains

    If you have defined any grains in Step 1, in this step you have to set parameters for distributing those grains. This step has 6 modes in which you can: (1)mark surface region as the base region of distributing grains[Q], (2)unmark surface region[W], (3)adjust the radius of Poisson disk[E], (4)adjust the offset along surface normal direction[R], (5)adjust the scaling of grains[T], and (6)move the reference grain[Y]. You can have the system update the grain distribution using the current parameter by pressing [ENTER].
    In the `Mark' and `Unmark' mode, you can mark/unmark surface regions by drawing a freeform stroke. The operation is similar to that in Step 3. Marked regions are shown in red.
    In the `Radius' mode, you can adjust the Poisson disk radius which controls the distribution density by dragging horizontally on the canvas. The radius is displayed as a blue sphere in wireframe.
    In the `Offset' or `Scale' mode, you can either translate the grain along the base surface normal or apply uniform scaling to the grain geometry by dragging horizontally on the canvas.
    The `Move reference' mode is just for changing the position of the reference grain, not for setting any parameters of distribution. You can move the reference grain by dragging on the base surface.

4.5. Step 5: Paint colors

    You can paint colors to the surface mesh vertices. You only need to give colors to a few vertices as constraints; the system interpolates them over the mesh. This step has 3 modes in which you can: (1)paint color constraints to the mesh vertices[Q], (2)erase existing color constraints[W], and (3)pick up a color from an image[E] (you can load any bmp/jpg/png file). You can use the color picker dialog by pressing [R]. You can enable/disable two-sided colors for the current surface by pressing [T]. If the surface has two-sided colors, you can paint colors for its front and back sides independently (except for the surface's open boundaries, if any). You can flip the front and back side colors by pressing [F]. If the surface is closed, you can mark it as a boundary of solid and empty space by pressing [H] (i.e., you can make a hole).

4.6. Step 6: Paint blur values

    Similar to the previous step, you can give blur value constraints to some mesh vertices, and the system interpolates them over the mesh. You can add/remove a constraint to a vertex by double-clicking on it. You can change the blur amount by clicking the green sphere and dragging horizontally.

4.7. Step 7: Synthesize random variations

    You can have the system generate random variations of the resulting VolumeObject by pressing [ENTER]. In the case of N-fold symmetry, you can increase/decrease N (the number of symmetry folds) by pressing [UP]/[DOWN]. You can save the currently synthesized VolumeObject as an *.xml or *.dss file by pressing [S].

5. Salad mode

    You can load cut pieces (*.piece files) created in the Browsing mode and assemble them to create a 3D scene. The current piece is rendered with red edges (you can change the rendering switch (face/edge/face+edge) by pressing [E]). Press [SPACE] to change the currently selected piece. You can translate the current piece parallel to the XZ-plane and along the Y-axis by dragging with nothing and [SHIFT] respectively. You can rotate/scale the current piece by dragging with [CTRL]/[SHIFT+CTRL]. Press [Q]/[W] to toggle the silhouette/noise effect. You can also load any *.obj file. Press [DELETE]/[ESCAPE] to remove the most currently added piece/all pieces. Press [S] to save the whole scene as *.scene file.
