#pragma once
//--------------------------------------------------------------------------+
// PmvcMr: computing PMVC with parallel Micro-Rendering on GPU              |
// For more details, refer to Tobias Ritschel's paper in SIGGRAPH Asia 2009 |
// !!!WARNING!!! - Because this algorithm runs long loops on the GPU, it    |
// may cause a GPU stall. The code is __very__ experimental, do experiments |
// at your own risk:-)                                                      |
//--------------------------------------------------------------------------+
#include <vector>
#include <KLIB/Vector.h>
#include "BoundingBox.h"

template <class TDiffuseAlgorithm>
struct VolumeObjectT;

template <class TPmvcAlgorithm>
struct DiffusePmvcT;

struct PmvcMr {
    typedef VolumeObjectT<DiffusePmvcT<PmvcMr> > VolumeObject;
    
    struct Node {
        KLIB::Vector3d position_;
        KLIB::Vector3d normal_;
        double radius_;
        KLIB::Vector3d colorf_; // front
        KLIB::Vector3d colorb_; // back
        Node(
            const KLIB::Vector3d& position = KLIB::Vector3d(),
            const KLIB::Vector3d& normal = KLIB::Vector3d(),
            double radius = 0,
            const KLIB::Vector3d& colorf = KLIB::Vector3d(),
            const KLIB::Vector3d& colorb = KLIB::Vector3d())
            : position_(position)
            , normal_(normal)
            , radius_(radius)
            , colorf_(colorf)
            , colorb_(colorb)
        {}
        Node operator+(const Node& rhs) const;
    };
    struct ObjectInfo {
        BoundingBox bbox_;
        KLIB::TextureBuffer3f bufHierarchy_;
        std::vector<Node> hierarchy_;
        std::vector<Node> leafNodes_;
        
        void gl_init();
        void gl_deinit();
        void preprocess(VolumeObject& volObj);
        void preprocess_step1_generatePoints(VolumeObject& volObj);
        void preprocess_step2_buildHierarchy(VolumeObject& volObj);
    };
    
    int resolution_;       // microbuffer resolution
    KLIB::FramebufferObject fbo_;
    KLIB::TextureBuffer3f bufInput_;        // input position list
    KLIB::TextureBuffer3f bufOutput_;       // output color list
    KLIB::ProgramObject shader_;
    std::vector<double> areaWeight_;
    
    PmvcMr(int resolution = 8);
    void gl_init();
    void gl_deinit();
    std::vector<KLIB::Vector3d> getColor(const ObjectInfo& objInfo, const std::vector<KLIB::Vector3d>& posList);
private:
    std::vector<KLIB::Vector3d> getColor_glsl(const ObjectInfo& objInfo, const std::vector<KLIB::Vector3d>& posList);
    std::vector<KLIB::Vector3d> getColor_glsl(const ObjectInfo& objInfo, const std::vector<KLIB::Vector3d>& posListLong, size_t unitSize);
    std::vector<KLIB::Vector3d> getColor_cpu (const ObjectInfo& objInfo, const std::vector<KLIB::Vector3d>& posList);
                KLIB::Vector3d  getColor_cpu (const ObjectInfo& objInfo, const             KLIB::Vector3d & pos);
};
