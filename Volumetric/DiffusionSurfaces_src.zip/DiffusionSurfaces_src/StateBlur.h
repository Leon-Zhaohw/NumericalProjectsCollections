#pragma once
#include "state.h"
#include <KLIB/Vector.h>
#include <GL/glew.h>

struct Mesh0;

class StateBlur : public State {
    StateBlur(void) {}
    ~StateBlur(void) {}
public:
    static StateBlur* getInstance() {
        static StateBlur p;
        return &p;
    }
    std::string message() { return "Step 6: Paint blur values"; }
    void initialize();
    void finalize();
    bool isReady() { return true; }
    State* next();
    
    void draw();
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    void OnLButtonDblClk(UINT nFlags, CPoint point);
    
    int currentObjectID_;
    
    CPoint point_old_;
    int dragged_v_idx_;
    int findIntersection(CPoint point);

    Mesh0& currentMesh0() const;
};
