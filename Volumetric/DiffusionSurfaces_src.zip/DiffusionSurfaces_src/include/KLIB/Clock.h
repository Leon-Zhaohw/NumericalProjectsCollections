#pragma once
#include <ctime>
#include <vector>
#include <iostream>
#include <iomanip>
#include <string>

namespace KLIB {
class ClkStart;
class ClkData
{
    friend ClkStart;
    std::vector<clock_t    > ticks_;
    std::string clkName_;
    std::vector<std::string> names_;
public:
    void setClkName(const std::string& clkName) { clkName_ = clkName; }
    std::string getClkName() const { return clkName_; }
    void addEntry(const std::string& name)
    {
        names_.push_back(name);
        ticks_.push_back(0);
    }
    void resetTick() {
        for (std::vector<clock_t>::iterator it = ticks_.begin(); it != ticks_.end(); ++it)
            *it = 0;
    }
    clock_t     getTick(int index) const { return ticks_[index]; }
    std::string getName(int index) const { return names_[index]; }
    void print(bool showInPercent = true)
    {
        double total = 0.0;
        for (size_t i = 0; i < ticks_.size(); ++i)
            total += static_cast<double>(ticks_[i]);
        std::cout << "[";
        if (!clkName_.empty())
            std::cout << clkName_ << " | ";
        for (size_t i = 0; i < ticks_.size(); ++i) {
            std::cout << names_[i] << ":";
            if (showInPercent) {
                double percent = total == 0.0 ? 0.0 : (100 * ticks_[i] / total);
                std::cout << std::setprecision(3) << percent << "%, ";
            } else {
                std::cout << (1000 * ticks_[i] / static_cast<double>(CLOCKS_PER_SEC)) << "msec, ";
            }
        }
        std::cout << "total:" << (1000 * total / CLOCKS_PER_SEC) << "msec]\n";
    }
    ClkData(const std::string& clkName = "")
        : clkName_(clkName)
    {}
};

class ClkStart
{
    ClkData* clkData_;
    int currentIndex_;
    clock_t clk_;
public:
    ClkStart(ClkData* clkData, int currentIndex = 0)
        : clkData_(clkData)
        , currentIndex_(currentIndex)
        , clk_(clock())
    {}
    void setCurrentIndex(int index)
    {
        clock_t clk_old = clk_;
        clk_ = clock();
        clkData_->ticks_[currentIndex_] += clk_ - clk_old;
        currentIndex_ = index;
    }
    ~ClkStart()
    {
        clock_t clk_old = clk_;
        clk_ = clock();
        clkData_->ticks_[currentIndex_] += clk_ - clk_old;
    }
};
class ClkSimple
{
    std::string message_;
    clock_t clk_;
public:
    ClkSimple(const std::string& message = "")
        : message_(message)
        , clk_(clock())
    {
        std::cout << "Start " << message_ << "...";
    }
    ~ClkSimple()
    {
        std::cout << "done!" << "(" << (1000 * (clock() - clk_) / CLOCKS_PER_SEC) << "msec)\n";
    }
};

}
