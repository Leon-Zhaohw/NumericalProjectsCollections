#pragma once
#include <vector>
extern "C" {
#include <triangle.h>
}

namespace KLIB {

class TriangleUtil {
    TriangleUtil();     // no instance
    ~TriangleUtil();
public:
    static void Delaunay(
        std::vector<int>& out_trianglelist,
        const std::vector<double>& in_pointlist)
    {
        triangulateio in, out;
        initData(in);
        initData(out);
        in.pointlist = const_cast<double*>(&in_pointlist[0]);
        in.numberofpoints = static_cast<int>(in_pointlist.size()) / 2;
        triangulate("z", &in, &out, 0);
        out_trianglelist.resize(3 * out.numberoftriangles);
        for (size_t i = 0; i < out_trianglelist.size(); ++i) out_trianglelist[i] = out.trianglelist[i];
        trifree(out.trianglelist);
    }
    static void ConstrainedDelaunay(
        std::vector<int>& out_trianglelist,
        const std::vector<double>& in_pointlist,
        const std::vector<int   >& in_segmentlist)
    {
        triangulateio in, out;
        initData(in);
        initData(out);
        in.pointlist = const_cast<double*>(&in_pointlist[0]);
        in.numberofpoints = static_cast<int>(in_pointlist.size()) / 2;
        in.segmentlist = in_segmentlist.empty() ? 0 : const_cast<int*>(&in_segmentlist[0]);
        in.numberofsegments = static_cast<int>(in_segmentlist.size()) / 2;
        triangulate("pz", &in, &out, 0);
        out_trianglelist.resize(3 * out.numberoftriangles);
        for (size_t i = 0; i < out_trianglelist.size(); ++i) out_trianglelist[i] = out.trianglelist[i];
        trifree(out.trianglelist);
    }
    static void ConformingConstrainedDelaunay(
        std::vector<double>& out_pointlist,
        std::vector<int>& out_trianglelist,
        const std::vector<double>& in_pointlist,
        const std::vector<int   >& in_segmentlist,
        const std::vector<double>& in_holelist,
        char* option = "pzq32.0")
    {
        triangulateio in, out;
        initData(in);
        initData(out);
        in.pointlist = const_cast<double*>(&in_pointlist[0]);
        in.numberofpoints = static_cast<int>(in_pointlist.size()) / 2;
        in.segmentlist = in_segmentlist.empty() ? 0 : const_cast<int*>(&in_segmentlist[0]);
        in.numberofsegments = static_cast<int>(in_segmentlist.size()) / 2;
        in.holelist = in_holelist.empty() ? 0 : const_cast<double*>(&in_holelist[0]);
        in.numberofholes = static_cast<int>(in_holelist.size()) / 2;
        //char buf[64];
        //sprintf(buf, "pz%s", in_quality);
        triangulate(option, &in, &out, 0);
        out_pointlist.resize(2 * out.numberofpoints);
        for (size_t i = 0; i < out_pointlist.size(); ++i) out_pointlist[i] = out.pointlist[i];
        out_trianglelist.resize(3 * out.numberoftriangles);
        for (size_t i = 0; i < out_trianglelist.size(); ++i) out_trianglelist[i] = out.trianglelist[i];
        trifree(out.trianglelist);
        trifree(out.pointlist);
    }
    static void initData(triangulateio& arg) {
        arg.pointlist                  = 0;
        arg.pointattributelist         = 0;
        arg.pointmarkerlist            = 0;
        arg.numberofpoints             = 0;
        arg.numberofpointattributes    = 0;
        arg.trianglelist               = 0;
        arg.triangleattributelist      = 0;
        arg.trianglearealist           = 0;
        arg.neighborlist               = 0;
        arg.numberoftriangles          = 0;
        arg.numberofcorners            = 0;
        arg.numberoftriangleattributes = 0;
        arg.segmentlist                = 0;
        arg.segmentmarkerlist          = 0;
        arg.numberofsegments           = 0;
        arg.holelist                   = 0;
        arg.numberofholes              = 0;
        arg.regionlist                 = 0;
        arg.numberofregions            = 0;
        arg.edgelist                   = 0;
        arg.edgemarkerlist             = 0;
        arg.normlist                   = 0;
        arg.numberofedges              = 0;
    }
    static void freeData(triangulateio& arg) {
        trifree(arg.pointlist                 );
        trifree(arg.pointattributelist        );
        trifree(arg.pointmarkerlist           );
        trifree(arg.trianglelist              );
        trifree(arg.triangleattributelist     );
        trifree(arg.trianglearealist          );
        trifree(arg.neighborlist              );
        trifree(arg.segmentlist               );
        trifree(arg.segmentmarkerlist         );
        trifree(arg.holelist                  );
        trifree(arg.regionlist                );
        trifree(arg.edgelist                  );
        trifree(arg.edgemarkerlist            );
        trifree(arg.normlist                  );
    }
    static void save_poly (
        const std::vector<double>& in_pointlist,
        const std::vector<int   >& in_segmentlist,
        const std::vector<double>& in_holelist,
        const char* filename);
};

}
