#include "stdafx.h"
#include "TriangleUtil.h"
#include <fstream>

using namespace KLIB;
using namespace std;

void TriangleUtil::save_poly (
    const vector<double>& in_pointlist,
    const vector<int   >& in_segmentlist,
    const vector<double>& in_holelist,
    const char* filename)
{
    ofstream ofs(filename);
    size_t n_point = in_pointlist.size() / 2;
    ofs << n_point << " 2 0 0\n";
    for (size_t i = 0; i < n_point; ++i)
        ofs << (i + 1) << " " << in_pointlist[2 * i] << " " << in_pointlist[2 * i + 1] << endl;
    size_t n_segment = in_segmentlist.size() / 2;
    ofs << n_segment << " 0\n";
    for (size_t i = 0; i < n_segment; ++i)
        ofs << (i + 1) << " " << (in_segmentlist[2 * i] + 1) << " " << (in_segmentlist[2 * i + 1] + 1) << endl;
    size_t n_hole = in_holelist.size() / 2;
    ofs << n_hole << endl;
    for (size_t i = 0; i < n_hole; ++i)
        ofs << (i + 1) << " " << in_holelist[2 * i] << " " << in_holelist[2 * i + 1] << endl;
    ofs.close();
}
