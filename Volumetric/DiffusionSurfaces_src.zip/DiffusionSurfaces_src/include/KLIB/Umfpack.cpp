#include "stdafx.h"
#include "Umfpack.h"

namespace {
// UMFPACK internal data structure (for copying opaque objects, too bad...)
typedef int Int;
//typedef struct
//{
//    double component [2] ;	/* real and imaginary parts */
//
//} DoubleComplex ;
//typedef DoubleComplex Entry;
typedef double Entry;
struct Unit
{
    Int
        size,	/* size, in Units, of the block, excl. header block */
        /* size >= 0: block is in use */
        /* size < 0: block is free, of |size| Units */
        prevsize ;	/* size, in Units, of preceding block in S->Memory */
    /* during garbage_collection, prevsize is set to -e-1 */
    /* for element e, or positive (and thus a free block) */
    /* otherwise */
};		/* block header */
typedef struct	/* NumericType */
{
    double
        flops,		/* "true" flop count */
        relpt,		/* relative pivot tolerance used */
        relpt2,		/* relative pivot tolerance used for sym. */
        droptol,
        alloc_init,	/* initial allocation of Numeric->memory */
        front_alloc_init, /* frontal matrix allocation parameter */
        rsmin,		/* smallest row sum */
        rsmax,		/* largest row sum  */
        min_udiag,	/* smallest abs value on diagonal of D */
        max_udiag,	/* smallest abs value on diagonal of D */
        rcond ;		/* min (D) / max (D) */

    Int
        scale ;

    Int valid ;		/* set to NUMERIC_VALID, for validity check */

    /* Memory space for A and LU factors */
    Unit
        *Memory ;	/* working memory for A and LU factors */
    Int
        ihead,		/* pointer to tail of LU factors, in Numeric->Memory */
        itail,		/* pointer to top of elements & tuples,  */
        /* in Numeric->Memory */
        ibig,		/* pointer to largest free block seen in tail */
        size ;		/* size of Memory, in Units */

    Int
        *Rperm,		/* pointer to row perm array, size: n+1 */
        /* after UMF_kernel:  Rperm [new] = old */
        /* during UMF_kernel: Rperm [old] = new */
        *Cperm,		/* pointer to col perm array, size: n+1 */
        /* after UMF_kernel:  Cperm [new] = old */
        /* during UMF_kernel: Cperm [old] = new */

        *Upos,		/* see UMFPACK_get_numeric for a description */
        *Lpos,
        *Lip,
        *Lilen,
        *Uip,
        *Uilen,
        *Upattern ;	/* pattern of last row of U (if singular) */

    Int
        ulen,		/* length of Upattern */
        npiv,		/* number of structural pivots found (sprank approx) */
        nnzpiv ;	/* number of numerical (nonzero) pivots found */

    Entry
        *D ;		/* D [i] is the diagonal entry of U */

    Int do_recip ;
    double *Rs ;	/* scale factors for the rows of A and b */
    /* do_recip FALSE: Divide row i by Rs [i] */
    /* do_recip TRUE:  Multiply row i by Rs [i] */

    Int
        n_row, n_col,	/* A is n_row-by-n_row */
        n1 ;		/* number of singletons */

    /* for information only: */
    Int
        tail_usage,	/* amount of memory allocated in tail */
        /* head_usage is Numeric->ihead */
        init_usage,	/* memory usage just after UMF_kernel_init */
        max_usage,	/* peak memory usage (excludes internal and external */
        /* fragmentation in the tail) */
        ngarbage,	/* number of garbage collections performed */
        nrealloc,	/* number of reallocations performed */
        ncostly,	/* number of costly reallocations performed */
        isize,		/* size of integer pattern of L and U */
        nLentries,	/* number of entries in L, excluding diagonal */
        nUentries,	/* number of entries in U, including diagonal */
        /* Some entries may be numerically zero. */
        lnz,		/* number of nonzero entries in L, excl. diagonal */
        all_lnz,	/* lnz plus entries dropped from L */
        unz,		/* number of nonzero entries in U, excl. diagonal */
        all_unz,	/* unz plus entries dropped form U */
        maxfrsize ;	/* largest actual front size */

    Int maxnrows, maxncols ;	/* not the same as Symbolic->maxnrows/cols* */

} NumericType ;
typedef struct	/* SymbolicType */
{

    double
        num_mem_usage_est,	/* estimated max Numeric->Memory size */
        num_mem_size_est,	/* estimated final Numeric->Memory size */
        peak_sym_usage,		/* peak Symbolic and SymbolicWork usage */
        sym,			/* symmetry of pattern */
        dnum_mem_init_usage,	/* min Numeric->Memory for UMF_kernel_init */
        amd_lunz,	/* nz in LU for AMD, with symmetric pivoting */
        lunz_bound ;	/* max nx in LU, for arbitrary row pivoting */

    Int valid,		/* set to SYMBOLIC_VALID, for validity check */
        max_nchains,
        nchains,
        *Chain_start,
        *Chain_maxrows,
        *Chain_maxcols,
        maxnrows,		/* largest number of rows in any front */
        maxncols,		/* largest number of columns in any front */
        *Front_npivcol,		/* Front_npivcol [j] = size of jth supercolumn*/
        *Front_1strow,		/* first row index in front j */
        *Front_leftmostdesc,	/* leftmost desc of front j */
        *Front_parent,		/* super-column elimination tree */
        *Cperm_init,		/* initial column ordering */
        *Rperm_init,		/* initial row ordering */
        *Cdeg, *Rdeg,
        *Esize,
        dense_row_threshold,
        n1,			/* number of singletons */
        nempty,			/* MIN (nempty_row, nempty_col) */
        *Diagonal_map,		/* initial "diagonal" (after 2by2) */
        esize,			/* size of Esize array */
        nfr,
        n_row, n_col,		/* matrix A is n_row-by-n_col */
        nz,			/* nz of original matrix */
        nb,			/* block size for BLAS 3 */
        num_mem_init_usage,	/* min Numeric->Memory for UMF_kernel_init */
        nempty_row, nempty_col,

        strategy,
        ordering,
        fixQ,
        prefer_diagonal,
        nzaat,
        nzdiag,
        amd_dmax ;

} SymbolicType ;
void UMFPACK_free_symbolic(void **SymbolicHandle) {
    SymbolicType *Symbolic ;
    if (!SymbolicHandle)
    {
        return ;
    }
    Symbolic = *((SymbolicType **) SymbolicHandle) ;
    if (!Symbolic)
    {
        return ;
    }

    (void) free ((void *) Symbolic->Cperm_init) ;
    (void) free ((void *) Symbolic->Rperm_init) ;
    (void) free ((void *) Symbolic->Front_npivcol) ;
    (void) free ((void *) Symbolic->Front_parent) ;
    (void) free ((void *) Symbolic->Front_1strow) ;
    (void) free ((void *) Symbolic->Front_leftmostdesc) ;
    (void) free ((void *) Symbolic->Chain_start) ;
    (void) free ((void *) Symbolic->Chain_maxrows) ;
    (void) free ((void *) Symbolic->Chain_maxcols) ;
    (void) free ((void *) Symbolic->Cdeg) ;
    (void) free ((void *) Symbolic->Rdeg) ;

    /* only when dense rows are present */
    (void) free ((void *) Symbolic->Esize) ;

    /* only when diagonal pivoting is prefered */
    (void) free ((void *) Symbolic->Diagonal_map) ;

    (void) free ((void *) Symbolic) ;
    *SymbolicHandle = (void *) NULL ;
}

void UMFPACK_free_numeric(void **NumericHandle) {
    NumericType *Numeric ;
    if (!NumericHandle)
    {
        return ;
    }
    Numeric = *((NumericType **) NumericHandle) ;
    if (!Numeric)
    {
        return ;
    }

    /* these 9 objects always exist */
    (void) free ((void *) Numeric->D) ;
    (void) free ((void *) Numeric->Rperm) ;
    (void) free ((void *) Numeric->Cperm) ;
    (void) free ((void *) Numeric->Lpos) ;
    (void) free ((void *) Numeric->Lilen) ;
    (void) free ((void *) Numeric->Lip) ;
    (void) free ((void *) Numeric->Upos) ;
    (void) free ((void *) Numeric->Uilen) ;
    (void) free ((void *) Numeric->Uip) ;

    /* Rs does not exist if scaling was not performed */
    (void) free ((void *) Numeric->Rs) ;

    /* Upattern can only exist for singular or rectangular matrices */
    (void) free ((void *) Numeric->Upattern) ;

    /* these 2 objects always exist */
    (void) free ((void *) Numeric->Memory) ;
    (void) free ((void *) Numeric) ;

    *NumericHandle = (void *) NULL ;
}

template <typename type>
void READ_SYMBOLIC(type** object, type* object_src, size_t n, void** Symbolic)
{
    *object = (type *) malloc (n * sizeof (type)) ;
    if (*object == (type *) NULL)
    {
        UMFPACK_free_symbolic (Symbolic) ;
        //return (UMFPACK_ERROR_out_of_memory) ;
    }
    memcpy(*object, object_src, sizeof (type) * n);
}

template <typename type>
void READ_NUMERIC(type** object, type* object_src, size_t n, void** Numeric)
{
    *object = (type *) malloc (n * sizeof (type)) ;
    if (*object == (type *) NULL)
    {
        UMFPACK_free_numeric (Numeric) ;
        //return (UMFPACK_ERROR_out_of_memory) ;
    }
    memcpy(*object, object_src, sizeof (type) * n);
}


const int SYMBOLIC_VALID = 41937;
const int NUMERIC_VALID  = 15977;
}

namespace KLIB {
int Umfpack::copy_symbolic(void** dst, void* src) {
    *dst = (void *) NULL ;
    SymbolicType *Symbolic = (SymbolicType *) malloc (sizeof (SymbolicType)) ;
    if (Symbolic == (SymbolicType *) NULL)
        return (UMFPACK_ERROR_out_of_memory) ;
    SymbolicType *Symbolic_src = (SymbolicType *) src;
    memcpy(Symbolic, Symbolic_src, sizeof (SymbolicType));
    if (Symbolic->valid != SYMBOLIC_VALID || Symbolic->n_row <= 0 ||
        Symbolic->n_col <= 0 || Symbolic->nfr < 0 || Symbolic->nchains < 0 ||
        Symbolic->esize < 0)
    {
        free ((void *) Symbolic) ;
        return (UMFPACK_ERROR_invalid_Symbolic_object) ;
    }
    
    Symbolic->Cperm_init         = (Int *) NULL ;
    Symbolic->Rperm_init         = (Int *) NULL ;
    Symbolic->Front_npivcol      = (Int *) NULL ;
    Symbolic->Front_parent       = (Int *) NULL ;
    Symbolic->Front_1strow       = (Int *) NULL ;
    Symbolic->Front_leftmostdesc = (Int *) NULL ;
    Symbolic->Chain_start        = (Int *) NULL ;
    Symbolic->Chain_maxrows      = (Int *) NULL ;
    Symbolic->Chain_maxcols      = (Int *) NULL ;
    Symbolic->Cdeg               = (Int *) NULL ;
    Symbolic->Rdeg               = (Int *) NULL ;
    Symbolic->Esize              = (Int *) NULL ;
    Symbolic->Diagonal_map       = (Int *) NULL ;
    
    READ_SYMBOLIC <Int>(&Symbolic->Cperm_init,         Symbolic_src->Cperm_init,         Symbolic->n_col+1  , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Rperm_init,         Symbolic_src->Rperm_init,         Symbolic->n_row+1  , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Front_npivcol,      Symbolic_src->Front_npivcol,      Symbolic->nfr+1    , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Front_parent,       Symbolic_src->Front_parent,       Symbolic->nfr+1    , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Front_1strow,       Symbolic_src->Front_1strow,       Symbolic->nfr+1    , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Front_leftmostdesc, Symbolic_src->Front_leftmostdesc, Symbolic->nfr+1    , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Chain_start,        Symbolic_src->Chain_start,        Symbolic->nchains+1, (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Chain_maxrows,      Symbolic_src->Chain_maxrows,      Symbolic->nchains+1, (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Chain_maxcols,      Symbolic_src->Chain_maxcols,      Symbolic->nchains+1, (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Cdeg,               Symbolic_src->Cdeg,               Symbolic->n_col+1  , (void **)&Symbolic) ;
    READ_SYMBOLIC <Int>(&Symbolic->Rdeg,               Symbolic_src->Rdeg,               Symbolic->n_row+1  , (void **)&Symbolic) ;
    if (Symbolic->esize > 0)
    {
        /* only when dense rows are present */
        READ_SYMBOLIC <Int>(&Symbolic->Esize, Symbolic_src->Esize, Symbolic->esize, (void **)&Symbolic) ;
    }
    if (Symbolic->prefer_diagonal)
    {
        /* only when diagonal pivoting is prefered */
        READ_SYMBOLIC <Int>(&Symbolic->Diagonal_map, Symbolic_src->Diagonal_map, Symbolic->n_col+1, (void **)&Symbolic) ;
    }
    
    *dst = (void *) Symbolic ;
    return (UMFPACK_OK) ;
}


int Umfpack::copy_numeric (void** dst, void* src) {
    *dst = (void *) NULL ;
    NumericType *Numeric = (NumericType *) malloc (sizeof (NumericType)) ;
    if (Numeric == (NumericType *) NULL)
    	return (UMFPACK_ERROR_out_of_memory) ;
    NumericType* Numeric_src = (NumericType *) src;
    memcpy(Numeric, Numeric_src, sizeof (NumericType));
    if (Numeric->valid != NUMERIC_VALID || Numeric->n_row <= 0 ||
        Numeric->n_col <= 0 || Numeric->npiv < 0 || Numeric->ulen < 0 ||
        Numeric->size <= 0)
    {
        /* Numeric does not point to a NumericType object */
        (void) free ((void *) Numeric) ;
        return (UMFPACK_ERROR_invalid_Numeric_object) ;
    }
    
    Numeric->D        = (Entry *) NULL ;
    Numeric->Rperm    = (Int *) NULL ;
    Numeric->Cperm    = (Int *) NULL ;
    Numeric->Lpos     = (Int *) NULL ;
    Numeric->Lilen    = (Int *) NULL ;
    Numeric->Lip      = (Int *) NULL ;
    Numeric->Upos     = (Int *) NULL ;
    Numeric->Uilen    = (Int *) NULL ;
    Numeric->Uip      = (Int *) NULL ;
    Numeric->Rs       = (double *) NULL ;
    Numeric->Memory   = (Unit *) NULL ;
    Numeric->Upattern = (Int *) NULL ;
    
    READ_NUMERIC <Entry>(&Numeric->D,     Numeric_src->D,     (Numeric->n_row < Numeric->n_col ? Numeric->n_row : Numeric->n_col )+1, (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Rperm, Numeric_src->Rperm, Numeric->n_row+1, (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Cperm, Numeric_src->Cperm, Numeric->n_col+1, (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Lpos,  Numeric_src->Lpos,  Numeric->npiv+1 , (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Lilen, Numeric_src->Lilen, Numeric->npiv+1 , (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Lip,   Numeric_src->Lip,   Numeric->npiv+1 , (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Upos,  Numeric_src->Upos,  Numeric->npiv+1 , (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Uilen, Numeric_src->Uilen, Numeric->npiv+1 , (void**)&Numeric) ;
    READ_NUMERIC <Int>(&Numeric->Uip,   Numeric_src->Uip,   Numeric->npiv+1 , (void**)&Numeric) ;
    if (Numeric->scale != UMFPACK_SCALE_NONE)
    {
        READ_NUMERIC <double>(&Numeric->Rs, Numeric_src->Rs, Numeric->n_row, (void**)&Numeric) ;
    }
    if (Numeric->ulen > 0)
    {
        READ_NUMERIC <Int>(&Numeric->Upattern, Numeric_src->Upattern, Numeric->ulen+1, (void**)&Numeric) ;
    }
    READ_NUMERIC <Unit>(&Numeric->Memory, Numeric_src->Memory, Numeric->size, (void**)&Numeric) ;
    
    *dst = (void *) Numeric ;
    return (UMFPACK_OK) ;
}


Umfpack::Umfpack(const Umfpack& src) : symbolic_(0), numeric_(0) {
    *this = src;
}

Umfpack& Umfpack::operator=(const Umfpack& rhs) {
    n_ = rhs.n_;
    Ap_ = rhs.Ap_;
    Ai_ = rhs.Ai_;
    Ax_ = rhs.Ax_;
    memcpy(info_, rhs.info_, sizeof(double) * UMFPACK_INFO);
    
    // copy symbolic data
    free_symbolic();
    if (rhs.symbolic_)
        copy_symbolic(&symbolic_, rhs.symbolic_);
    else
        symbolic_ = 0;
    
    // copy numeric data
    free_numeric();
    if (rhs.numeric_)
        copy_numeric(&numeric_, rhs.numeric_);
    else
        numeric_ = 0;
    
    isVerbose_ = rhs.isVerbose_;
    return *this;
}
}