#pragma once
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <vector>
#include <algorithm>
#include "Util.h"
#include "Matrix.h"

namespace KLIB {
    
template<typename Mesh, typename Scalar = double, int Dim = 3>
struct OpenMeshUtil {
    typedef typename Mesh::Point Point;
    
    static Scalar calcArea(const Mesh& mesh) {
        Scalar result = 0;
        for (Mesh::CFIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
            Point face[3];
            Mesh::CFVIter v = mesh.cfv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                face[i] = mesh.point(v);
            result += Util::calcArea(face[0], face[1], face[2]);
        }
        return result;
    }
    
    static void calcDartThrowing(
        const Mesh& in_mesh, Scalar in_poissonRadius,
        std::vector<typename Mesh::FHandle>& out_fhandles, std::vector<Vector<Scalar, 3> >& out_baryCoords)
    {
        typedef Matrix<Scalar, 4, 4> Matrix4x4;
        typedef Vector<Scalar, 4> Vector4;
        /* [pseudocode]
        (1) store all triangles in an "active" list Fs
        (2) empty sampled point list Ps
        do {
            (3) take out an active triangle F randomly from Fs (probability proportional to area, strictly speaking)
            (4) choose a random point P on F (barycentric cood)
            (5) if P is at least R away from the rest of points in Ps, add P to Ps
            (6) if F is not fully covered by any single point in Ps, subdivide F into F0, F1, F2, and F3, and add them to Fs
        } while (Fs is not empty)
        */
        // (1) store all triangles in an "active" list Fs
        std::vector<std::pair<Mesh::FHandle, Matrix4x4> > activeList;
        activeList.reserve(in_mesh.n_faces() * 2);
        for (Mesh::CFIter f = in_mesh.faces_begin(); f != in_mesh.faces_end(); ++f)
            activeList.push_back(std::pair<Mesh::FHandle, Matrix4x4>(f, Matrix4x4::identity()));
        // (2) empty sampled point list Ps
        out_fhandles  .clear();
        out_baryCoords.clear();
        std::vector<Point> out_points;
        while (!activeList.empty()) {
            std::random_shuffle(activeList.begin(), activeList.end());
            // (3) take out an active triangle F randomly from Fs (probability proportional to area, strictly speaking)
            Mesh::FHandle f  = activeList.back().first;
            Matrix4x4     t  = activeList.back().second;
            activeList.pop_back();
            // (4) choose a random point P on F (barycentric cood)
            Vector<Scalar, 3> baryCoord;
            baryCoord.set_random(0, 1);
            baryCoord /= baryCoord.elemSum();
            Vector4 baryCoordHomo(baryCoord, 1);
            baryCoord = (t * baryCoordHomo).xyz();
            Point point;
            Mesh::CFVIter v = in_mesh.cfv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                point += baryCoord[i] * in_mesh.point(v);
            // (5) if P is at least R away from the rest of points in Ps, add P to Ps
            bool isValidPoint = true;
            for (size_t i = 0; i < out_points.size(); ++i) {
                Scalar d = (point - out_points[i]).length();
                if (d < in_poissonRadius) {
                    isValidPoint = false;
                    break;
                }
            }
            if (isValidPoint) {
                out_points    .push_back(point);
                out_fhandles  .push_back(f);
                out_baryCoords.push_back(baryCoord);
            }
            bool b = t == Matrix4x4::identity();
            Point face_root[3];
            Point face_child[3];
            v = in_mesh.cfv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                face_root[i] = in_mesh.point(v);
            for (int i = 0; i < 3; ++i, ++v) {
                v = in_mesh.cfv_iter(f);
                for (int j = 0; j < 3; ++j, ++v)
                    face_child[i] += (t(j, i) + t(j, 3)) * in_mesh.point(v);
            }
            // (6) if F is not fully covered by any single point in Ps, subdivide F into F0, F1, F2, and F3, and add them to Fs
            bool isCovered = false;
            for (size_t i = 0; i < out_points.size(); ++i) {
                bool isValid = true;
                for (int j = 0; j < 3; ++j) {
                    point = Point();
                    v = in_mesh.cfv_iter(f);
                    for (int k = 0; k < 3; ++k, ++v)
                        point += (t(k, j) + t(k, 3)) * in_mesh.point(v);
                    Scalar d = (point - out_points[i]).length();
                    if (in_poissonRadius < d) {
                        isValid = false;
                        break;
                    }
                }
                if (isValid) {
                    isCovered = true;
                    break;
                }
            }
            if (!isCovered) {           // coordinate transformation trick to mimic subdivision of F
                const Matrix4x4 t0(
                    0.5,   0,   0, 0.5,
                      0, 0.5,   0,   0,
                      0,   0, 0.5,   0,
                      0,   0,   0,   1);
                const Matrix4x4 t1(
                    0.5,   0,   0,   0,
                      0, 0.5,   0, 0.5,
                      0,   0, 0.5,   0,
                      0,   0,   0,   1);
                const Matrix4x4 t2(
                    0.5,   0,   0,   0,
                      0, 0.5,   0,   0,
                      0,   0, 0.5, 0.5,
                      0,   0,   0,   1);
                const Matrix4x4 t3(
                    -0.5,    0,    0,   0.5,
                       0, -0.5,    0,   0.5,
                       0,    0, -0.5,   0.5,
                       0,    0,    0,     1);
                activeList.push_back(std::pair<Mesh::FHandle, Matrix4x4>(f, t * t0));
                activeList.push_back(std::pair<Mesh::FHandle, Matrix4x4>(f, t * t1));
                activeList.push_back(std::pair<Mesh::FHandle, Matrix4x4>(f, t * t2));
                activeList.push_back(std::pair<Mesh::FHandle, Matrix4x4>(f, t * t3));
            }
        }
    }
};


}
