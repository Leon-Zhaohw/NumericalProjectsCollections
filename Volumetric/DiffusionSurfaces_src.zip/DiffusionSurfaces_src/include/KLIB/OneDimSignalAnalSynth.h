// One dimensional signal analyzer / synthesizer using pyramids
#pragma once
#include <vector>
#include <algorithm>

namespace KLIB {

template <typename T>
class OneDimSignalAnalSynth {
private:
	std::vector<std::vector<T> > anal_pyramid_;
	std::vector<std::vector<T> > anal_residua_;
public:
    OneDimSignalAnalSynth() {}
    ~OneDimSignalAnalSynth() {}
    OneDimSignalAnalSynth(const std::vector<T>& signal) {
        analyze(signal);
    }
    void analyze(const std::vector<T>& signal) {
        anal_pyramid_.clear();
        anal_residua_.clear();
        anal_pyramid_.push_back(signal);
        while (anal_pyramid_.back().size() > 1) {
            std::vector<T>& signal_u = anal_pyramid_.back();
            std::vector<T>& signal_d = downsample(signal_u);
            std::vector<T>& signal_ud = upsample(signal_d, signal_u.size() % 2 == 1);
            std::vector<T> residual(signal_u.size());
            for (size_t i = 0; i < signal_u.size(); ++i)
                residual[i] = signal_u[i] - signal_ud[i];
            anal_residua_.push_back(residual);
            anal_pyramid_.push_back(signal_d);
        }
    }
    std::vector<T> synthesize() const {
        // copy
        std::vector<std::vector<T> > synth_pyramid = anal_pyramid_;
        std::vector<std::vector<T> > synth_residua = anal_residua_;
	    // randomize residua
	    for (size_t i = 0; i < synth_residua.size(); ++i)
            std::random_shuffle(synth_residua[i].begin(), synth_residua[i].end());
	    for (size_t i = synth_pyramid.size() - 1; i > 0; --i) {
            std::vector<T>& signal_d = synth_pyramid[i];
		    std::vector<T>& signal_u = synth_pyramid[i - 1];
		    signal_u = upsample(signal_d, signal_u.size() % 2 == 1);
		    for (size_t j = 0; j < signal_u.size(); ++j)
			    signal_u[j] += synth_residua[i - 1][j];
	    }
        return synth_pyramid.front();
    }
private:
    static std::vector<T> downsample(const std::vector<T>& signal_u) {
	    size_t size_d = static_cast<size_t>(ceil(signal_u.size() * 0.5));
        std::vector<T> signal_d(size_d);
	    for (size_t i_d = 0; i_d < size_d; ++i_d) {
            size_t i_u_prev = i_d == 0 ? signal_u.size() - 1 : 2 * i_d - 1;
		    size_t i_u      = 2 * i_d;
		    size_t i_u_next = 2 * i_d + 1;
		    if (signal_u.size() <= i_u_next) i_u_next = 0;
		    signal_d[i_d] = 
			    0.25 * signal_u[i_u_prev] +
			    0.5  * signal_u[i_u     ] +
			    0.25 * signal_u[i_u_next];
	    }
	    return signal_d;
    }
    static std::vector<T> upsample(const std::vector<T>& signal_d, bool is_odd) {
	    size_t size_u = signal_d.size() * 2 - (is_odd ? 1 : 0);
        std::vector<T> signal_u(size_u);
	    for (size_t i_u = 0; i_u < size_u; ++i_u) {
		    size_t i_d = i_u / 2;
		    if (i_d * 2 != i_u) {
			    size_t i_d_next = (i_d + 1) % signal_d.size();
			    signal_u[i_u] =
				    0.5 * signal_d[i_d] +
				    0.5 * signal_d[i_d_next];
		    } else {
			    signal_u[i_u] = signal_d[i_d];
		    }
	    }
	    return signal_u;
    }
};

}
