#pragma once
#include "VectorVL.h"
#include "PCA.h"
#include <vector>

namespace KLIB {

class PcaMorph {
    VectorVLd mean_;
    std::vector<VectorVLd> eigenvectors_;
    std::vector<double>    eigenvalues_;
public:
    void analyze(const std::vector<VectorVLd>& samples) {
        PCA::go(samples, mean_, eigenvectors_, eigenvalues_);
    }
    VectorVLd synthesize(double threshold_min = 0, double threshold_max = 1) {        // theshold range: (0, 1]. smaller = far from mean, larger = close to mean
        size_t M = eigenvectors_.size();
        std::vector<double> coefficients(M);
        while (true) {
            double sum = 0;
            for (size_t i = 0; i < M; ++i) {
                coefficients[i] = rand() * 4. / RAND_MAX - 2;
                sum += coefficients[i] * coefficients[i];
            }
            double threshold = exp(-0.5 * sum);
            if (threshold_min < threshold && threshold < threshold_max)
                break;
        }
        VectorVLd result(mean_);
        for (size_t i = 0; i < M; ++i)
            result += (coefficients[i] * eigenvalues_[i]) * eigenvectors_[i];
        return result;
    }
};
}   // namespace KLIB
