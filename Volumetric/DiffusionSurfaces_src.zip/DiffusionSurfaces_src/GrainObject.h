#pragma once
#include <KLIB/Polyline.h>
#include "Mesh0.h"
#include "Mesh4.h"

struct GrainObject {
    KLIB::Polyline2d strokeVrtLeft_;
    KLIB::Polyline2d strokeVrtRight_;
    KLIB::Polyline2d strokeHrz_;
    Mesh4 mesh4_ref_;
    Mesh0 mesh0_ref_;
    
    double poissonRadius_;
    GrainObject() : poissonRadius_(0) {}
};
