#include "StdAfx.h"
#include "StateCsVrt.h"
#include "Core.h"
#include <KLIB/Util.h>
#include <fstream>
#include <iostream>
#include "StateCsHrz.h"
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;
}

void StateCsVrt::initialize() {
    core.ogl_.makeOpenGLCurrent();
    modeler.bgImgVrt_.fname_.clear();
    
    modeler.sweepObjects_.clear();
    mode_ = MODE_DRAW;
    core.ogl_.setView(0, 0, 5, 0, 0, 0, 0, 1, 0);
    glLineWidth(5);
    glEnable(GL_BLEND);
    glDisable(GL_DEPTH_TEST);
}
string StateCsVrt::message() {
    string msg;
    msg += "Step 1: Sketch vertical profiles\n";
    msg += "Mode: ";
    msg +=
        mode_ == MODE_DRAW       ? "Draw"       :
        mode_ == MODE_DEFORM     ? "Deform"     :
        mode_ == MODE_SMOOTH     ? "Smooth"     :
        mode_ == MODE_BGIMG      ? "BgImg"      : "Draw grain";
    return msg;
}
State* StateCsVrt::next() {
    snapStrokeEndpoints();
    modeler.type_ = Modeler::TYPE_CYLIND;
    for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
        if (modeler.sweepObjects_[i].type_ == SweepObject::TYPE_NFOLD2) {
            modeler.type_ = Modeler::TYPE_NFOLD;
            break;
        }
    }
    if (modeler.type_ == Modeler::TYPE_NFOLD) {
        for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i)
            if (modeler.sweepObjects_[i].type_ == SweepObject::TYPE_CYLIND)
                modeler.sweepObjects_[i].type_ = SweepObject::TYPE_NFOLD1;
    }
    for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        GrainObject& grainObj = sweepObj.grainObject_;
        Polyline2d& strokeL = grainObj.strokeVrtLeft_;
        Polyline2d& strokeR = grainObj.strokeVrtRight_;
        sweepObj.hasGrain_ = !strokeR.empty();
        if (!sweepObj.hasGrain_) {
            strokeL.clear();
            continue;
        }
        if (strokeL.size() < strokeR.size())
            strokeL.resample(strokeR.size());
        else if (strokeR.size() < strokeL.size())
            strokeR.resample(strokeL.size());
    }
    return StateCsHrz::getInstance();
}
bool StateCsVrt::isReady() {
    return !modeler.sweepObjects_.empty();
}
void StateCsVrt::draw() {
    BgImg& bgImg = modeler.bgImgVrt_;
    glDisable(GL_LIGHTING);
    //glEnable(GL_BLEND);
    if (!bgImg.fname_.empty()) {
        // draw textured quad
        bgImg.tex_.enable();
        bgImg.tex_.bind();
        Drawer::drawTexturedQuad(bgImg.cornerBL_, bgImg.cornerBR_, bgImg.cornerTL_, bgImg.cornerTR_);
        bgImg.tex_.unbind();
        bgImg.tex_.disable();
        // draw frame
        Vector2d* ptr[4] = { &bgImg.cornerBL_, &bgImg.cornerBR_, &bgImg.cornerTR_, &bgImg.cornerTL_ };
        glColor3d(0.5, 0.5, 0.5);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < 4; ++i)
            glVertex2dv(ptr[i]->ptr());
        glEnd();
        glBegin(GL_POINTS);
        for (int i = 0; i < 4; ++i)
            glVertex2dv(ptr[i]->ptr());
        glEnd();
    }
    // XY-axis
    glBegin(GL_LINES);
    glColor3d(1, 0, 0); glVertex2d(0, 0); glVertex2d(1, 0);
    glColor3d(0, 1, 0); glVertex2d(0, -10); glVertex2d(0, 10);
    glEnd();
    glBegin(GL_QUADS);
    glColor4d(0, 0, 0, 0.25);
    glVertex2d(-20, -10);    glVertex2d(  0, -10);    glVertex2d(  0,  10);    glVertex2d(-20,  10);
    glEnd();
    // registered stroke points
    for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        if (mode_ == MODE_DRAW_GRAIN && i == currentSweepObjID_)
            glColor3d(1, 0, 1);
        else
            glColor3d(0, 0, 0);
        Polyline2d& strokeVrt = sweepObj.strokeVrt_;
        glBegin(strokeVrt.isLoop() ? GL_LINE_LOOP : GL_LINE_STRIP);
        for (size_t j = 0; j < strokeVrt.size(); ++j)
            glVertex2dv(strokeVrt[j].ptr());
        glEnd();
        if (!strokeVrt.isLoop()) {
            glBegin(GL_POINTS);
            if (strokeVrt.front().x_ < Modeler::THRESHOLD_UI_DISTANCE)
                glVertex2dv(strokeVrt.front().ptr());
            if (strokeVrt.back ().x_ < Modeler::THRESHOLD_UI_DISTANCE)
                glVertex2dv(strokeVrt.back ().ptr());
            glEnd();
        }
        
        // grain stroke points
        GrainObject& grainObj = sweepObj.grainObject_;
        Polyline2d& strokeL = grainObj.strokeVrtLeft_;            // left
        glColor3d(0, 1, 1);
        glBegin(GL_LINE_STRIP);
        for (size_t j = 0; j < strokeL.size(); ++j)
            glVertex2dv(strokeL[j].ptr());
        glEnd();
        Polyline2d& strokeR = grainObj.strokeVrtRight_;            // right
        glColor3d(1, 1, 0);
        glBegin(GL_LINE_STRIP);
        for (size_t j = 0; j < strokeR.size(); ++j)
            glVertex2dv(strokeR[j].ptr());
        glEnd();
        // draw dots if the endpoints meed
        if (!strokeL.empty() && !strokeR.empty()) {
            glColor3d(0, 0, 0);
            glBegin(GL_POINTS);
            if ((strokeL.front() - strokeR.front()).length() < Modeler::THRESHOLD_UI_DISTANCE)
                glVertex2dv(strokeL.front().ptr());
            if ((strokeL.back() - strokeR.back()).length() < Modeler::THRESHOLD_UI_DISTANCE)
                glVertex2dv(strokeL.back().ptr());
            glEnd();
        }
    }
    // temporary stroke points
    if (!tempStroke_.empty()) {
        glColor3d(0, 0.5, 1);
        glBegin(GL_LINE_STRIP);
        for (size_t i = 0; i < tempStroke_.size(); ++i)
            glVertex2dv(tempStroke_[i].ptr());
        glEnd();
    }
}
void StateCsVrt::OnLButtonDown(UINT nFlags, CPoint& point) {
    Vector3d start, ori;
    core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
    Vector2d point2d(start + (-start[2] / ori[2]) * ori);
    if (mode_ == MODE_DRAW) {
        tempStroke_.push_back(point2d);
    } else if (mode_ == MODE_DRAW_GRAIN) {
        GrainObject& grainObj = modeler.sweepObjects_[currentSweepObjID_].grainObject_;
        Polyline2d& strokeL = grainObj.strokeVrtLeft_;
        Polyline2d& strokeR = grainObj.strokeVrtRight_;
        if (!strokeL.empty() && !strokeR.empty()) {    // clear previous pair
            strokeL.clear();
            strokeR.clear();
        }
        tempStroke_.push_back(point2d);
    } else if (mode_ == MODE_DEFORM) {
        double dist_min = DBL_MAX;
        rigid_target_ = 0;
        // SweepObject strokes
        for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
            SweepObject& sweepObj = modeler.sweepObjects_[i];
            Polyline2d& strokeVrt = sweepObj.strokeVrt_;
            for (size_t j = 0; j < strokeVrt.size(); ++j) {
                double d = (point2d - strokeVrt[j]).length();
                if (d < dist_min) {
                    dist_min = d;
                    rigid_target_ = &strokeVrt;
                    rigid_dragid_ = j;
                }
            }
            Polyline2d& strokeL = sweepObj.grainObject_.strokeVrtLeft_;
            for (size_t j = 0; j < strokeL.size(); ++j) {
                double d = (point2d - strokeL[j]).length();
                if (d < dist_min) {
                    dist_min = d;
                    rigid_target_ = &strokeL;
                    rigid_dragid_ = j;
                }
            }
            Polyline2d& strokeR = sweepObj.grainObject_.strokeVrtRight_;
            for (size_t j = 0; j < strokeR.size(); ++j) {
                double d = (point2d - strokeR[j]).length();
                if (d < dist_min) {
                    dist_min = d;
                    rigid_target_ = &strokeR;
                    rigid_dragid_ = j;
                }
            }
        }
        if (dist_min < Modeler::THRESHOLD_UI_DISTANCE) {
            rigid_.init(*rigid_target_);
            rigid_dragstart_ = point2d;
            rigid_peelsize_ = 0;
        } else {
            rigid_target_ = 0;
        }
    } else if (mode_ == MODE_SMOOTH) {
        // do nothing
    } else if (mode_ == MODE_BGIMG) {
        BgImg& bgImg = modeler.bgImgVrt_;
        Vector2d* ptr[4] = { &bgImg.cornerBL_, &bgImg.cornerBR_, &bgImg.cornerTL_, &bgImg.cornerTR_ };
        draggedCorner_ = 0;
        double dist_min = DBL_MAX;
        for (int i = 0; i < 4; ++i) {
            double d = (point2d - *ptr[i]).length();
            if (d < dist_min) {
                dist_min = d;
                draggedCorner_ = ptr[i];
            }
        }
        if (dist_min < Modeler::THRESHOLD_UI_DISTANCE) {
            bgImgMode_ = BGIMGMODE_CORNER;
            return;
        }
        dragPrev_ = point2d;
        Vector2d triangles[2][3] = {
            { bgImg.cornerBL_, bgImg.cornerBR_, bgImg.cornerTR_ }, 
            { bgImg.cornerBL_, bgImg.cornerTR_, bgImg.cornerTL_ }
        };
        bool flag = false;
        for (int i = 0; i < 2; ++i) {
            Vector3d baryCoord = Util::calcBarycentricCoord<double, 2>(triangles[i], point2d);
            if (0 < baryCoord[0] && 0 < baryCoord[1] && 0 < baryCoord[2]) {
                flag = true;
                break;
            }
        }
        bgImgMode_ = flag ? BGIMGMODE_TRANSLATE : BGIMGMODE_ROTATE;
    }
}
void StateCsVrt::OnLButtonUp  (UINT nFlags, CPoint& point) {
    switch (mode_) {
    case MODE_DRAW:
    case MODE_DRAW_GRAIN:
        {
            if (tempStroke_.size() < 3) {
                tempStroke_.clear();
                break;
            }
            if (mode_ == MODE_DRAW) {
                bool isLoop = (tempStroke_.back() - tempStroke_.front()).length() < Modeler::THRESHOLD_UI_DISTANCE;
                if (isLoop)
                    tempStroke_.pop_back();
                SweepObject sweepObj;
                Polyline2d& strokeVrt = sweepObj.strokeVrt_;
                strokeVrt = tempStroke_;
                strokeVrt.setLoop(isLoop);
                double length = strokeVrt.length();
                int numDiv = length / Modeler::STROKE_SEGMENT_LENGTH + 3;
                strokeVrt.resample(numDiv);
                if (isLoop)
                    sweepObj.type_ = SweepObject::TYPE_NFOLD2;
                modeler.sweepObjects_.push_back(sweepObj);
            } else {    // vertical stroke of grain object
                GrainObject& grainObj = modeler.sweepObjects_[currentSweepObjID_].grainObject_;
                Polyline2d& strokeL = grainObj.strokeVrtLeft_;
                Polyline2d& strokeR = grainObj.strokeVrtRight_;
                Polyline2d& strokeDst = strokeL.empty() ? strokeL : strokeR;
                strokeDst = tempStroke_;
                strokeDst.setLoop(false);
                double length = strokeDst.length();
                int numDiv = length / Modeler::STROKE_SEGMENT_LENGTH + 3;
                strokeDst.resample(numDiv);
            }
            tempStroke_.clear();
        }
        break;
    case MODE_DEFORM:
        {
            if (!rigid_target_)
                return;
            Polyline2d& strokeDst = *rigid_target_;
            double length = strokeDst.length();
            int numDiv = length / Modeler::STROKE_SEGMENT_LENGTH + 3;
            if ((nFlags & MK_SHIFT) == 0)
                strokeDst.resample(numDiv);
        }
        break;
    case MODE_SMOOTH:
        break;
    case MODE_BGIMG:
        break;
    }
    core.ogl_.RedrawWindow();
}
void StateCsVrt::OnMouseMove  (UINT nFlags, CPoint& point) {
    core.ogl_.MouseMove(point);
    if (!core.eventHandler_.isLButtonDown_)
        return;
    Vector3d start, ori;
    core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
    Vector2d point2d(start + (-start[2] / ori[2]) * ori);
    switch (mode_) {
    case MODE_DRAW:
    case MODE_DRAW_GRAIN:
        tempStroke_.push_back(point2d);
        break;
    case MODE_DEFORM:
        {
            if (!rigid_target_)
                return;
            double dist = (rigid_dragstart_ - point2d).length();
            int peelsize = static_cast<int>(dist / Modeler::THRESHOLD_UI_RIGID_PEEL) + 1;
            if (rigid_peelsize_ < peelsize) {
                rigid_peelsize_ = peelsize;
                size_t num_vtx = rigid_target_->size();
                vector<int> is_vtx_constrained(num_vtx, 1);
                int vtxid = rigid_dragid_;
                for (int i = 0; i <= rigid_peelsize_; ++i) {
                    is_vtx_constrained[vtxid] = 0;
                    if (vtxid == num_vtx - 1) {
                        if (rigid_target_->isLoop())
                            vtxid = 0;
                        else
                            break;
                    } else
                        ++vtxid;
                }
                vtxid = rigid_dragid_;
                for (int i = 0; i <= rigid_peelsize_; ++i) {
                    is_vtx_constrained[vtxid] = 0;
                    if (vtxid == 0) {
                        if (rigid_target_->isLoop())
                            vtxid = num_vtx - 1;
                        else
                            break;
                    } else
                        --vtxid;
                }
                if (!rigid_target_->isLoop())
                    is_vtx_constrained.front() = is_vtx_constrained.back() = 1;
                is_vtx_constrained[rigid_dragid_] = 1;
                rigid_.compile(is_vtx_constrained);
            }
            (*rigid_target_)[rigid_dragid_] = point2d;
            *rigid_target_ = rigid_.deform(rigid_target_->points());
        }
        break;
    case MODE_SMOOTH:
        {
            double dist_min = DBL_MAX;
            Polyline2d* target_stroke = 0;
            size_t target_id;
            for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
                SweepObject& sweepObj = modeler.sweepObjects_[i];
                Polyline2d& strokeVrt = sweepObj.strokeVrt_;
                for (size_t j = 0; j < strokeVrt.size(); ++j) {
                    double dist = (point2d - strokeVrt[j]).length();
                    if (dist < dist_min) {
                        dist_min = dist;
                        target_stroke = &strokeVrt;
                        target_id = j;
                    }
                }
                GrainObject& grainObj = sweepObj.grainObject_;
                Polyline2d& strokeVrtLeft = grainObj.strokeVrtLeft_;
                for (size_t j = 0; j < strokeVrtLeft.size(); ++j) {
                    double dist = (point2d - strokeVrtLeft[j]).length();
                    if (dist < dist_min) {
                        dist_min = dist;
                        target_stroke = &strokeVrtLeft;
                        target_id = j;
                    }
                }
                Polyline2d& strokeVrtRight = grainObj.strokeVrtRight_;
                for (size_t j = 0; j < strokeVrtRight.size(); ++j) {
                    double dist = (point2d - strokeVrtRight[j]).length();
                    if (dist < dist_min) {
                        dist_min = dist;
                        target_stroke = &strokeVrtRight;
                        target_id = j;
                    }
                }
            }
            if (Modeler::THRESHOLD_UI_DISTANCE < dist_min)
                return;
            if (!target_stroke->isLoop() && (target_id == 0 || target_id == target_stroke->size() - 1)) return;
            size_t target_id_prev = target_id == 0 ? target_stroke->size() - 1 : target_id - 1;
            size_t target_id_next = target_id == target_stroke->size() - 1 ? 0 : target_id + 1;
            Vector2d& target_point = (*target_stroke)[target_id];
            target_point = 0.5 * target_point + 0.25 * (*target_stroke)[target_id_prev] + 0.25 * (*target_stroke)[target_id_next];
        }
        break;
    case MODE_BGIMG:
        {
            if (bgImgMode_ == BGIMGMODE_CORNER) {
                *draggedCorner_ = point2d;
            } else {
                BgImg& bgImg = modeler.bgImgVrt_;
                Vector2d* ptr[4] = { &bgImg.cornerBL_, &bgImg.cornerBR_, &bgImg.cornerTL_, &bgImg.cornerTR_ };
                if (bgImgMode_ == BGIMGMODE_ROTATE) {
                    double theta = point2d[0] - dragPrev_[0];
                    Matrix2x2d R(
                        cos(theta), -sin(theta),
                        sin(theta),  cos(theta));
                    Vector2d center;
                    for (int i = 0; i < 4; ++i) center += *ptr[i];
                    center *= 0.25;
                    for (int i = 0; i < 4; ++i)
                        *ptr[i] = R * (*ptr[i] - center) + center;
                } else {
                    Vector2d delta = point2d - dragPrev_;
                    for (int i = 0; i < 4; ++i) *ptr[i] += delta;
                }
                dragPrev_ = point2d;
            }
        }
        break;
    }
    core.ogl_.RedrawWindow();
}
void StateCsVrt::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_2D(nFlags, point); }
void StateCsVrt::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp     (nFlags, point); }
void StateCsVrt::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    switch (nChar) {
    case VK_F2:
    case VK_F3:
        Modeler::STROKE_SEGMENT_LENGTH *= nChar == VK_F2 ? (1/1.1) : 1.1;
        cout << "Modeler::STROKE_SEGMENT_LENGTH=" << Modeler::STROKE_SEGMENT_LENGTH << "\n";
        break;
    case VK_F4:
    case VK_F5:
        Modeler::THRESHOLD_UI_DISTANCE *= nChar == VK_F4 ? (1/1.1) : 1.1;
        cout << "Modeler::THRESHOLD_UI_DISTANCE=" << Modeler::THRESHOLD_UI_DISTANCE << "\n";
        core.ogl_.RedrawWindow();
        break;
    case ' ':
        if (mode_ != MODE_DRAW_GRAIN)
            return;
        if (modeler.sweepObjects_.empty())
            return;
        currentSweepObjID_ = (currentSweepObjID_ + 1) % modeler.sweepObjects_.size();
        core.ogl_.RedrawWindow();
        break;
    case 'S':
        {
            CFileDialog dlg(FALSE, "step1", "*.step1", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step1 files|*.step1||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_CsVrt(ofs);
        }
        break;
    case 'Q':
    case 'W':
    case 'E':
    case 'R':
    case 'T':
        mode_ = 
            nChar == 'Q' ? MODE_DRAW   :
            nChar == 'W' ? MODE_DEFORM :
            nChar == 'E' ? MODE_SMOOTH :
            nChar == 'R' ? MODE_BGIMG  : MODE_DRAW_GRAIN;
        if (nChar == 'T')
            currentSweepObjID_ = 0;
        core.ogl_.RedrawWindow();
        break;
    case VK_DELETE:
        if (mode_ == MODE_DRAW) {
            if (modeler.sweepObjects_.empty())
                return;
            modeler.sweepObjects_.pop_back();
            currentSweepObjID_ = -1;
        } else if (mode_ == MODE_DRAW_GRAIN && currentSweepObjID_ != -1) {
            modeler.sweepObjects_[currentSweepObjID_].hasGrain_ = false;
            modeler.sweepObjects_[currentSweepObjID_].grainObject_ = GrainObject();
        } else if (mode_ == MODE_BGIMG) {
            modeler.bgImgVrt_.fname_.clear();
        }
        core.ogl_.RedrawWindow();
        break;
    }
}
void StateCsVrt::OnDropFiles(const string& fname, const string& ext) {
    if (ext == "step1") { // load
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_CsVrt(ifs)) {
            cout << "Error occurred in Modeler::load_CsVrt()" << endl;
            return;
        }
        core.ogl_.RedrawWindow();
        return;
    }
    if (ext == "jpg" || ext == "png" || ext == "bmp") {
        BgImg& bgImg = modeler.bgImgVrt_;
        bgImg.fname_ = fname;
        bgImg.load();
        core.ogl_.RedrawWindow();
        return;
    }
}
void StateCsVrt::snapStrokeEndpoints() {
    for (size_t i = 0; i < modeler.sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        Polyline2d& strokeVrt = sweepObj.strokeVrt_;
        if (sweepObj.type_ != SweepObject::TYPE_NFOLD2) {
            if (strokeVrt.front()[0] < Modeler::THRESHOLD_UI_DISTANCE)
                strokeVrt.front()[0] = 0;
            if (strokeVrt.back ()[0] < Modeler::THRESHOLD_UI_DISTANCE)
                strokeVrt.back ()[0] = 0;
        }
        if (sweepObj.hasGrain_) {
            GrainObject& grainObj = sweepObj.grainObject_;
            Polyline2d& strokeL = grainObj.strokeVrtLeft_;
            Polyline2d& strokeR = grainObj.strokeVrtRight_;
            if (strokeL.empty() || strokeR.empty())
                continue;
            if ((strokeL.front() - strokeR.front()).length() < Modeler::THRESHOLD_UI_DISTANCE)
                strokeL.front() = strokeR.front();
            if ((strokeL.back() - strokeR.back()).length() < Modeler::THRESHOLD_UI_DISTANCE)
                strokeL.back() = strokeR.back();
        }
    }
}
