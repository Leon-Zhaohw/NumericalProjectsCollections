#pragma once
#include <GL/glew.h>
#include <KLIB/Vector.h>
#include <KLIB/GLUtil.h>

struct BgImg {  // background image
    KLIB::Vector2d cornerBL_;   // bottom left
    KLIB::Vector2d cornerBR_;   // bottom right
    KLIB::Vector2d cornerTL_;   // top left
    KLIB::Vector2d cornerTR_;   // top right
    std::string fname_;
    KLIB::TextureObject tex_;
    void gl_init();
    void gl_deinit();
    void load();
};
