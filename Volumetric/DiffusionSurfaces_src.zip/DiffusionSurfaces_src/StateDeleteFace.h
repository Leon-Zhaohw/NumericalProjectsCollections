#pragma once
#include "state.h"
#include <KLIB/Polyline.h>
#include <vector>

class StateDeleteFace : public State {
    StateDeleteFace(void)
        : currentObjectID_(0)
    {}
    ~StateDeleteFace(void) {}
public:
    static StateDeleteFace* getInstance() {
        static StateDeleteFace p;
        return &p;
    }
    std::string message() { return "Step 3: Delete unwanted surface regions"; }
    void initialize();
    bool isReady() { return true; }
    State* next();
    
    void draw();
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    int currentObjectID_;
    KLIB::Polyline2d cutStroke2D_;
    KLIB::Polyline3d cutStroke3D_;
};
