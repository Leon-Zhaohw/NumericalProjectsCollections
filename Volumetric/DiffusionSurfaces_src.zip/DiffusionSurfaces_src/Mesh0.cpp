#include "stdafx.h"
#include "Mesh0.h"
#include <KLIB/Umfpack.h>
using namespace KLIB;
using namespace std;

void Mesh0::calcAuxiliaryInfo() {
    bbox_.init();
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        Vector3d& p = point(v_it);
        bbox_.max_ = bbox_.max_.pairwiseMax(p);
        bbox_.min_ = bbox_.min_.pairwiseMin(p);
        data(v_it).isOpenEnd_ = false;
    }
    for (EIter e_it = edges_begin(); e_it != edges_end(); ++e_it)
        data(e_it).isOpenEnd_ = false;
    isClosed_ = true;
    for (HIter h_it = halfedges_begin(); h_it != halfedges_end(); ++h_it) {
        if (face_handle(h_it).idx() != -1)
            continue;
        VHandle from_vhandle = from_vertex_handle(h_it);
        VHandle to_vhandle   = to_vertex_handle  (h_it);
        EHandle ehandle      = edge_handle(h_it);
        data(from_vhandle).isOpenEnd_ = true;
        data(to_vhandle)  .isOpenEnd_ = true;
        data(ehandle)     .isOpenEnd_ = true;
        isClosed_ = false;
    }
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        VertexData& vdata = data(v_it);
        if (vdata.nfold1_flagPole_ || vdata.nfold1_mapped_vid_ != -1)
            vdata.isOpenEnd_ = false;
    }
}
void Mesh0::copyAttributes(const Mesh0& src) {
    int n = n_vertices();
    assert(n == src.n_vertices());
    vector<Vector3d> temp_points(n);
    vector<Vector3d> temp_vertex_normals(n);
    vector<Vector3d> temp_face_normals(n_faces());
    
    VIter v = vertices_begin();
    for (int i = 0; i < n; ++i, ++v) {
        temp_points[i] = point(v);
        temp_vertex_normals[i] = normal(v);
    }
    FIter f = faces_begin();
    for (int i = 0; i < n_faces(); ++i, ++f)
        temp_face_normals[i] = normal(f);
    
    *this = src;
    
    v = vertices_begin();
    for (int i = 0; i < n; ++i, ++v) {
        set_point(v, temp_points[i]);
        set_normal(v, temp_vertex_normals[i]);
    }
    f = faces_begin();
    for (int i = 0; i < n_faces(); ++i, ++f)
        set_normal(f, temp_face_normals[i]);
}
void Mesh0::calcLaplacianMatrix() {
    int n = n_vertices();
    vector<CholmodMatrix::Triplet> triplets;
    triplets.reserve(n * 10);
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        int vid = v.handle().idx();
        triplets.push_back(CholmodMatrix::Triplet(vid, vid, -1));
        vector<int> wid;
        wid.reserve(10);
        for (VVIter w = vv_iter(v); w; ++w)
            wid.push_back(w.handle().idx());
        int mapped_vid = data(v).nfold1_mapped_vid_;
        if (mapped_vid != -1) {
            VHandle mapped_v = vertex_handle(mapped_vid);
            for (VVIter w = vv_iter(mapped_v); w; ++w)
                wid.push_back(w.handle().idx());
        }
        double d = 1. / wid.size();
        for (size_t j = 0; j < wid.size(); ++j)
            triplets.push_back(CholmodMatrix::Triplet(vid, wid[j], d));
    }
    CholmodMatrix L(n, n, triplets);
    LtL_ = L.transpose() * L;
}
void Mesh0::updateColor() {
    int n = n_vertices();
    vector<CholmodMatrix::Triplet> triplets;
    
    vector<Vector3d> b;      // right hand side (color constraints)
    vector<Vector3d> x;         // solution

    const double LSQ_WEIGHT = 100.;             // weight of soft constraints in least square
    
    // front
    b.resize(n);
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        VertexData& vdata = data(v);
        if (!vdata.isConstrained_)
            continue;
        int vid = v.handle().idx();
        triplets.push_back(CholmodMatrix::Triplet(vid, vid, LSQ_WEIGHT));
        b[vid] = LSQ_WEIGHT * vdata.color_;
    }
    if (!triplets.empty()) {
        CholmodMatrix C(n, n, triplets);
        CholmodMatrix LtL_copy = LtL_ + C;
        Umfpack umfpack(n, LtL_copy.getAp(), LtL_copy.getAi(), LtL_copy.getAx());
        umfpack.solve<Vector3d, 3>(b, x);
    } else {
        x.resize(n, Vector3d(1));
    }
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        int vid = v.handle().idx();
        Vector3d color = x[vid];
        for (int i = 0; i < 3; ++i) {
            if (color[i] < 0)
                color[i] = 0;
            if (1 < color[i])
                color[i] = 1;
        }
        data(v).color_ = color;
        if (!isTwoSided_)
            data(v).back_color_ = color;
    }
    
    if (!isTwoSided_)
        return;
    
    // back
    b.clear();
    b.resize(n);
    x.clear();
    triplets.clear();
    triplets.reserve(n);
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        VertexData& vdata = data(v);
        if (!vdata.back_isConstrained_)
            continue;
        int vid = v.handle().idx();
        triplets.push_back(CholmodMatrix::Triplet(vid, vid, LSQ_WEIGHT));
        b[vid] = LSQ_WEIGHT * vdata.back_color_;
    }
    if (!triplets.empty()) {
        CholmodMatrix C(n, n, triplets);
        CholmodMatrix LtL_copy = LtL_ + C;
        Umfpack umfpack(n, LtL_copy.getAp(), LtL_copy.getAi(), LtL_copy.getAx());
        umfpack.solve<Vector3d, 3>(b, x);
    } else {
        x.resize(n, Vector3d(1));
    }
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        int vid = v.handle().idx();
        Vector3d color = x[vid];
        for (int i = 0; i < 3; ++i) {
            if (color[i] < 0)
                color[i] = 0;
            if (1 < color[i])
                color[i] = 1;
        }
        data(v).back_color_ = color;
    }
    
    // blend colors at open boundaries
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        VertexData& vdata = data(v);
        if (!vdata.isOpenEnd_)
            continue;
        Vector3d& color      = data(v).color_;
        Vector3d& back_color = data(v).back_color_;
        color = back_color = 0.5 * (color + back_color);
    }
}
void Mesh0::updateBlur() {
    int n = n_vertices();
    vector<CholmodMatrix::Triplet> triplets;
    
    vector<double> b;      // right hand side (color constraints)
    vector<double> x;         // solution

    const double LSQ_WEIGHT = 100.;             // weight of soft constraints in least square
    
    // front
    b.resize(n, 0);
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        VertexData& vdata = data(v);
        if (!vdata.isConstrained_)
            continue;
        int vid = v.handle().idx();
        triplets.push_back(CholmodMatrix::Triplet(vid, vid, LSQ_WEIGHT));
        b[vid] = LSQ_WEIGHT * vdata.blurValue_;
    }
    if (!triplets.empty()) {
        CholmodMatrix C(n, n, triplets);
        CholmodMatrix LtL_copy = LtL_ + C;
        Umfpack umfpack(n, LtL_copy.getAp(), LtL_copy.getAi(), LtL_copy.getAx());
        umfpack.solve(b, x);
        hasBlur_ = true;
    } else {
        x.resize(n, 0);
        hasBlur_ = false;
    }
    for (VIter v = vertices_begin(); v != vertices_end(); ++v)
        data(v).blurValue_ = x[v.handle().idx()];
}
