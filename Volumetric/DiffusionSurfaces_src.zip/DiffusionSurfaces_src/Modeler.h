#pragma once
#include <KLIB/PcaMorph.h>
#include <fstream>
#include "BgImg.h"
#include "SweepObject.h"

//------------------------------------------------------------------------+
// Image-guided sketch-based modeling of objects with rotational symmetry |
//------------------------------------------------------------------------+
// -- Things to be specified at each step -- BEGIN
//    [StateCsVrt] - Step 1
//        bgImgVrt_
//        SweepObject::{type_, strokeVrt_}
//        GrainObject::{strokeVrtLeft_, strokeVrtRight_, }
//    [StateCsHrz] - Step 2
//        bgImgHrz_
//        foldAngles_exemplar_
//        type_
//        SweepObject::strokeHrz_exemplar_
//        GrainObject::strokeHrz_
//    [StateDeleteFace] - Step 3
//        SweepObject::mesh0_ref_
//        GrainObject::mesh0_ref_
//    [StateGrain] - Step 4
//        Mesh0::FaceT::flagGrain_
//        GrainObject::.poissonRadius_
//        geometric modification of each GrainObject (offset, scale)
//    [StateColor] - Step 5
//        Mesh0::{isTwoSided_, isHole_}
//        Mesh0::VertexT::{color_, back_color_}
//    [StateBlur] - Step 6
//        Mesh0::hasBlur_
//        Mesh0::VertexT::blurValue_
//    (StateSynthVrt)
//    [StateSynthHrz] - Step 7
//        foldAngles_synthesis_
//        SweepObject::strokeHrz_synthesis_
// -- Things to be specified at each step -- END

template <class T>
struct VolumeObjectT;

struct Modeler {
    enum Type {
        TYPE_CYLIND,
        TYPE_NFOLD
    } type_;
    
    BgImg bgImgVrt_;
    BgImg bgImgHrz_;
    
    void gl_init();
    void gl_deinit();

    std::vector<double> foldAngles_exemplar_;
    std::vector<double> foldAngles_synthesis_;
    
    std::vector<SweepObject> sweepObjects_;
    
    KLIB::PcaMorph pcaMorphFold_;
    
    // analysis part
    void analyze_cylind();
    void analyze_nfold();
    
    // synthesis part
    template <class T>
    void synthesize_cylind(VolumeObjectT<T>& volObj);
    template <class T>
    void synthesize_nfold(VolumeObjectT<T>& volObj, int numFold);
    void synthesize_nfold_sub_foldAngles(int numFold);
    void synthesize_nfold_sub_strokeHrz_nfold(int numFold);
    
    void convert_strokeHrz_exemplar_xy_rt();     // for each SweepObject, convert strokeHrz_exemplar_xy_ to strokeHrz_exemplar_
    
    // save/load functions corresponding to each State
    void save_CsVrt     (std::ofstream& ofs);
    void save_CsHrz     (std::ofstream& ofs);
    void save_DeleteFace(std::ofstream& ofs);
    void save_Grain     (std::ofstream& ofs);
    void save_Color     (std::ofstream& ofs);
    void save_Blur      (std::ofstream& ofs);
    bool load_CsVrt     (std::ifstream& ifs);
    bool load_CsHrz     (std::ifstream& ifs);
    bool load_DeleteFace(std::ifstream& ifs);
    bool load_Grain     (std::ifstream& ifs);
    bool load_Color     (std::ifstream& ifs);
    bool load_Blur      (std::ifstream& ifs);

    static double THRESHOLD_UI_DISTANCE;
    static double STROKE_SEGMENT_LENGTH;
    static double THRESHOLD_UI_RIGID_PEEL;
};
