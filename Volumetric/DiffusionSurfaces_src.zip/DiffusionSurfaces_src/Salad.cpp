#include "StdAfx.h"
#include "Salad.h"
#include <iterator>
#include <algorithm>
using namespace std;
using namespace KLIB;

void Salad::gl_init() {
    silRenderer_.gl_init();
}
void Salad::gl_deinit() {
    for (size_t i = 0; i < pieces_.size(); ++i)
        pieces_[i].noiseWeight_.gl_deinit();
    silRenderer_.gl_deinit();
}
bool Salad::save(const char* fname) const {
    ofstream ofs;
    ofs.open(fname, ios::trunc | ios::binary);
    if (!ofs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    int n_pieces = (int)pieces_.size();
    ofs.write((char*)&n_pieces, sizeof(int));
    for (size_t i = 0; i < pieces_.size(); ++i)
        pieces_[i].save_sub(ofs);
    return true;
}

bool Salad::load(const char* fname) {
    ifstream ifs;
    ifs.open(fname, ios::binary);
    if (!ifs) {
        cout << "Couldn't open file: " << fname << endl;
        return false;
    }
    int n_pieces;
    ifs.read((char*)&n_pieces, sizeof(int));
    pieces_.clear();
    pieces_.resize(n_pieces);
    silRenderer_.clear();
    for (int i = 0; i < n_pieces; ++i)
        pieces_[i].load_sub(ifs);
    return true;
}

void Salad::calcFixedCurves() {
    silRenderer_.clear();
    for (size_t i = 0; i < pieces_.size(); ++i) {
        const Transform& t = pieces_[i].t_;
        for (size_t j = 0; j < pieces_[i].curves_.size(); ++j) {
            Polyline3d curve3d_fixed = pieces_[i].curves_[j];
            for (size_t k = 0; k < curve3d_fixed.size(); ++k)
                curve3d_fixed[k] = t.transform(curve3d_fixed[k]);
            silRenderer_.curves3d_fixed_.push_back(curve3d_fixed);
        }
    }
}
void Salad::calcSilhouetteCurves() {
    for (size_t i = 0; i < pieces_.size(); ++i)
        for (size_t j = 0; j < pieces_[i].mesh3s_.size(); ++j)
            silRenderer_.addSilhouette(pieces_[i].mesh3s_[j], pieces_[i].t_);
}
void Salad::renderSceneDepth() const {
    for (size_t i = 0; i < pieces_.size(); ++i) {
        for (size_t j = 0; j < pieces_[i].mesh3s_.size(); ++j)
            silRenderer_.renderDepth(pieces_[i].mesh3s_[j], pieces_[i].t_);
        silRenderer_.renderDepth(pieces_[i].mesh2_, pieces_[i].t_);
    }
}
