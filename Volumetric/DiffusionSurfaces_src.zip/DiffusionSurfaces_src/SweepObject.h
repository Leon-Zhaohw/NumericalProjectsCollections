#pragma once
#include "GrainObject.h"
#include <KLIB/OneDimSignalAnalSynth.h>

struct SweepObject {
    enum Type {
        TYPE_CYLIND,
        TYPE_NFOLD1,             // sweep axis is fixed at central (Y) axis
        TYPE_NFOLD2              // sweep axis is defined by a pair of strokes (available only for N-folds)
    } type_;

    KLIB::Polyline2d strokeVrt_;
    std::vector<KLIB::Polyline2d> strokeHrz_exemplar_;
    std::vector<KLIB::Polyline2d> strokeHrz_synthesis_;
    // NOTE: 2D points in strokeHrz_*_ represent polar coordinates (r, theta), instead of Cartesian coordinates (x, y).
    // NOTE: for n-fold symmetry, theta is normalized to the unit range [0, 1]. for cylindrical symmetry, theta's range is [0, 2*pi].
    
    std::vector<KLIB::Polyline2d> strokeHrz_exemplar_xy_;       // strokes in xy coordinates
    
    void analyze_strokeHrz_cylind();
    void synthesize_strokeHrz_cylind();
    KLIB::OneDimSignalAnalSynth<KLIB::Vector2d> signalProcessor_;
    
    Mesh4 mesh4_ref_;           // reference mesh created directly by sweeping
    Mesh0 mesh0_ref_;           // reference mesh after removing surface regions partially from mesh4, for storing color information (only vertex positions will be different for each fold)
    
    Mesh4 genMesh4_cylind(const KLIB::Polyline2d& strokeHrz) const;
    Mesh4 genMesh4_nfold1(const KLIB::Polyline2d& strokeHrz, double angle_begin, double angle_end) const;
    Mesh4 genMesh4_nfold2(const KLIB::Polyline2d& strokeHrz, double angle_begin, double angle_end) const;
    Mesh0 merge_nfold1(const std::vector<Mesh0>& mesh0s) const;
    
    
    // information for controlling grain distribution
    bool hasGrain_;
    GrainObject grainObject_;
    std::vector<Mesh0> distributedGrains_;
    void distributeGrains(const Mesh0& mesh0_base);
    void genGrainMesh4();
    
    SweepObject()
        : type_(TYPE_CYLIND)
        , hasGrain_(false)
    {}
};
