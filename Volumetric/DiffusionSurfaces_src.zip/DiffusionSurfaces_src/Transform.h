#pragma once
#include <KLIB/Matrix.h>
#include <GL/GL.h>

struct Transform {
    KLIB::Vector3d   translate_;
    KLIB::Matrix4x4d rotate_;
    KLIB::Matrix4x4d rotateT_;      // transpose of rotate
    double scale_;
    KLIB::Vector3d operator() (const KLIB::Vector3d& point) const {
        return rotateT_.transform(scale_ * point) + translate_;
    }
    KLIB::Vector3d transform(const KLIB::Vector3d& point) const { return operator()(point); }
    KLIB::Vector3d rotate(const KLIB::Vector3d& direction) const { return rotateT_.transform(direction); }
    void call_gl() const {
	    glTranslated(translate_[0], translate_[1], translate_[2]);
	    glScaled(scale_, scale_, scale_);
	    glMultMatrixd(rotate_.ptr());
    }
    Transform() : rotate_(KLIB::Matrix4x4d::identity()), rotateT_(KLIB::Matrix4x4d::identity()), scale_(1) {}
};
