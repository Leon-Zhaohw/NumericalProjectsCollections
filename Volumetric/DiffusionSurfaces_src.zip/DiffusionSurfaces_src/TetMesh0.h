#pragma once
#include <KLIB/Vector.h>
#include <vector>

// Tetrahedral mesh with auxiliary info constructed from Mesh0 using TetGen
struct TetMesh0 {
    struct Tetra {
        //      v0--v2
        //     / \ .|
        //    /  .\ |    face & neighbor references: the same as that of opposite vertex
        //   / .   \|
        // v1.______v3
        int vertex_  [4];
        int face_    [4];
        int neighbor_[4];
        int flag_visited_;
        Tetra() : flag_visited_(-1) {
            vertex_  [0] = vertex_  [1] = vertex_  [2] = vertex_  [3] = -1;
            face_    [0] = face_    [1] = face_    [2] = face_    [3] = -1;
            neighbor_[0] = neighbor_[1] = neighbor_[2] = neighbor_[3] = -1;
        }
    };
    enum VertexType { VERTEX_INTERIOR, VERTEX_BOUNDARY, VERTEX_BOUNDARY_SPLIT };
    struct Vertex {
        KLIB::Vector3d pos_;
        VertexType type_;
        KLIB::Vector3d color_;
        KLIB::Vector3d back_color_;
        KLIB::Vector3d normal_;
        int tetMesh1_vid_;
        int back_tetMesh1_vid_;
        std::vector<int> neighbor_tetras_;
        Vertex() : type_(VERTEX_INTERIOR), tetMesh1_vid_(-1), back_tetMesh1_vid_(-1) {}
    };
    struct Face {
        bool isTwoSided_;
        KLIB::Vector3d normal_;
        int vertex_[3];
        int tetra_[2];
        Face() {
            vertex_[0] = vertex_[1] = vertex_[2] = -1;
            tetra_ [0] = tetra_ [1] = -1;
        }
    };
    std::vector<Tetra > tetras_;
    std::vector<Vertex> vertices_;
    std::vector<Face  > faces_;
    void clear() {
        vertices_.clear();
        tetras_  .clear();
        faces_   .clear();
    }
    KLIB::Vector3d getTetraBarycenter(int tetra_id) {
        KLIB::Vector3d result;
        for (int i = 0; i < 4; ++i) {
            result += vertices_[tetras_[tetra_id].vertex_[i]].pos_;
        }
        result *= 0.25;
        return result;
    }
    KLIB::Vector3d getFaceBarycenter(int face_id) {
        KLIB::Vector3d result;
        for (int i = 0; i < 3; ++i) {
            result += vertices_[faces_[face_id].vertex_[i]].pos_;
        }
        result /= 3.0;
        return result;
    }
};
