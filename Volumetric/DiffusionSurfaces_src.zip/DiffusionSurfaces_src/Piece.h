#pragma once
#include <vector>
#include <fstream>
#include <KLIB/Polyline.h>
#include "Mesh2.h"
#include "Mesh3.h"
#include "NoiseWeight.h"
#include "Transform.h"

struct Piece {
    Mesh2 mesh2_;
    std::vector<Mesh3> mesh3s_;
    std::vector<KLIB::Polyline3d> curves_;      // feature curves used for line rendering
    NoiseWeight noiseWeight_;
    Transform t_;
    bool load(const char* fname);
    void load_sub(std::ifstream& ifs);
    bool loadDish(const char* fname);   // load .obj file as a dish
    bool save(const char* fname) const;
    void save_sub(std::ofstream& ofs) const;
};
