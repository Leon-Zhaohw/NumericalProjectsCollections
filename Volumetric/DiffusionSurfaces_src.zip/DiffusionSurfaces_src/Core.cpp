#include "StdAfx.h"
#include "Core.h"
#include "StateCsVrt.h"
#include "StateBrowse.h"
#include <KLIB/GLSLNoise.h>
using namespace std;
using namespace KLIB;

void Core::gl_init() {
    glewInit();
    cutAlgorithm_.gl_init();
    GLSLNoise::initialize();
    noiseShader_.init();    {
        ShaderObject fragMain("Noise.frag", ShaderObject::FRAGMENT_SHADER);
        ShaderObject vertMain("Noise.vert", ShaderObject::VERTEX_SHADER);
        noiseShader_.attach(GLSLNoise::fragShader());
        noiseShader_.attach(fragMain);
        noiseShader_.attach(vertMain);
        noiseShader_.link();
    }
    volObj_.gl_init();
    volObj_.noiseWeight_.setDefault();
    modeler_.gl_init();
    salad_.gl_init();
    glEnable(GL_CULL_FACE);
    state_->initialize();
}
void Core::gl_deinit() {
    GLSLNoise::finalize();
    cutAlgorithm_.gl_deinit();
    volObj_.noiseWeight_.gl_deinit();
    volObj_.silRenderer_.gl_deinit();
    modeler_.gl_deinit();
    salad_.gl_deinit();
    salad_.silRenderer_ .gl_deinit();
}

Core::Core(void)
    : app_(0)
    , view_(0)
    , mainFrm_(0)
    , state_(0)
{
    state_ = StateCsVrt::getInstance();
    //state_ = StateBrowse::getInstance();
    CholmodMatrix::start();
    srand((unsigned int)time(NULL));
}
Core::~Core(void) {
    CholmodMatrix::finish();
}
