#ifndef SETTINGS_H
#define SETTINGS_H

#define BLOCK_SIZE 8

#include <cassert>
//#define Real float
//#define SINGLE_PRECISION 1

#ifndef Real
#define Real double
#endif

#include <TIMER.h>

//#ifndef NDEBUG
//#define NDEBUG
//#endif

#endif
